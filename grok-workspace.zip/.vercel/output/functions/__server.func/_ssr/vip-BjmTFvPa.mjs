import { o as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { p as require_jsx_runtime } from "../_libs/@radix-ui/react-checkbox+[...].mjs";
import { t as Button } from "./button-D_PHfu3x.mjs";
import { a as CardTitle, i as CardHeader, n as CardContent, t as Card } from "./card-BqLLulKB.mjs";
import { h as Crown, m as CupSoda, r as Wallet, t as Zap } from "../_libs/lucide-react.mjs";
import { u as money } from "./format-ydPugZ1g.mjs";
import { u as listAvailableProducts, v as placeOrder } from "./api-DUpluZ3_.mjs";
import { n as useQuery, t as useMutation } from "../_libs/tanstack__react-query.mjs";
import { a as SelectValue, i as SelectTrigger, n as SelectContent, r as SelectItem, t as Select } from "./select-DLjEeGji.mjs";
import { o as InvoiceModal } from "./invoice-modal-DmA2m8xY.mjs";
import { t as Input } from "./input-C8FVBVyT.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { t as Checkbox } from "./checkbox-CQmSRhXi.mjs";
import { t as Label } from "./label-2J_LU4QX.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/vip-BjmTFvPa.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function VipPage() {
	const products = useQuery({
		queryKey: ["products-available"],
		queryFn: () => listAvailableProducts()
	});
	const [name, setName] = (0, import_react.useState)("");
	const [phone, setPhone] = (0, import_react.useState)("");
	const [productId, setProductId] = (0, import_react.useState)("");
	const [qty, setQty] = (0, import_react.useState)(1);
	const [terms, setTerms] = (0, import_react.useState)(false);
	const [mkt, setMkt] = (0, import_react.useState)(false);
	const [placed, setPlaced] = (0, import_react.useState)(null);
	const [invoice, setInvoice] = (0, import_react.useState)(false);
	const product = (products.data ?? []).find((p) => String(p.id) === productId);
	const total = product ? product.price * qty + 100 : 100;
	const place = useMutation({
		mutationFn: () => {
			if (!product) throw new Error("Pick a drink");
			return placeOrder({ data: {
				customerName: name,
				customerEmail: "",
				customerPhone: phone,
				items: [{
					productId: String(product.id),
					productName: product.name,
					quantity: qty,
					price: product.price,
					cupType: "standard",
					category: product.category
				}],
				paymentMethod: "card",
				isVip: true,
				consentOwnImage: true,
				consentMarketing: mkt
			} });
		},
		onSuccess(o) {
			setPlaced(o);
			setInvoice(true);
			toast.success("VIP order placed");
		},
		onError(err) {
			toast.error(err instanceof Error ? err.message : "Could not place VIP order");
		}
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "mx-auto max-w-3xl px-4 py-12",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mb-8 flex items-center gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Crown, { className: "h-6 w-6 text-accent" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "font-display text-3xl font-semibold",
					children: "VIP desk"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid gap-4 sm:grid-cols-3",
				children: [
					{
						icon: Zap,
						title: "Priority queue",
						body: "Your ticket jumps the board."
					},
					{
						icon: CupSoda,
						title: "Premium cup",
						body: "Presentation that matches the surcharge."
					},
					{
						icon: Wallet,
						title: "Paid in full",
						body: "No balance waiting at pickup."
					}
				].map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardHeader, { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(p.icon, { className: "h-4 w-4 text-accent" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardTitle, {
						className: "text-base",
						children: p.title
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-muted-foreground",
						children: p.body
					})
				] }) }, p.title))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
				className: "mt-8",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardTitle, { children: "Place VIP order" }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardContent, {
					className: "space-y-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-1.5",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Name" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								value: name,
								onChange: (e) => setName(e.target.value),
								required: true
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-1.5",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Phone" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								value: phone,
								onChange: (e) => setPhone(e.target.value)
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-1.5",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Drink" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
								value: productId,
								onValueChange: setProductId,
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, { placeholder: "Choose a drink" }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectContent, { children: (products.data ?? []).map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SelectItem, {
									value: String(p.id),
									children: [
										p.name,
										" · ",
										money(p.price)
									]
								}, p.id)) })]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-1.5",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Quantity" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								type: "number",
								min: 1,
								value: qty,
								onChange: (e) => setQty(Math.max(1, Number(e.target.value) || 1))
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-sm",
							children: [
								"VIP surcharge ",
								money(100),
								" · Total ",
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "font-medium tabular-nums",
									children: money(total)
								}),
								" paid in full"
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "flex items-start gap-2 text-sm",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Checkbox, {
								checked: terms,
								onCheckedChange: (v) => setTerms(v === true)
							}), "I accept VIP terms (priority board, paid in full, no refunds on presentation)"]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "flex items-start gap-2 text-sm",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Checkbox, {
								checked: mkt,
								onCheckedChange: (v) => setMkt(v === true)
							}), "Allow marketing usage"]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							className: "w-full",
							disabled: !name.trim() || !product || !terms || place.isPending,
							onClick: () => place.mutate(),
							children: place.isPending ? "Placing…" : "Place VIP order"
						})
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(InvoiceModal, {
				order: placed,
				open: invoice,
				onOpenChange: setInvoice
			})
		]
	});
}
//#endregion
export { VipPage as component };
