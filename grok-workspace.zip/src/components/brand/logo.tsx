import { cn } from "@/lib/utils";

export function CupifyMark({ className }: { className?: string }) {
  return (
    <svg viewBox="0 0 32 32" className={cn("text-primary", className)} aria-hidden="true">
      <rect width="32" height="32" rx="9" fill="currentColor" />
      <path
        d="M9 13.5c0-.8.6-1.5 1.4-1.5h8.4c.8 0 1.4.7 1.4 1.5v5.2c0 2.6-2.2 4.7-5 4.7h-1.2c-2.8 0-5-2.1-5-4.7v-5.2z"
        fill="hsl(var(--primary-foreground))"
      />
      <path
        d="M20.2 14.2h1.4c1.3 0 2.4 1.1 2.4 2.4s-1.1 2.4-2.4 2.4h-1.4"
        fill="none"
        stroke="hsl(var(--primary-foreground))"
        strokeWidth="1.6"
        strokeLinecap="round"
      />
      <path
        d="M12.2 8.2c.2 1.2.1 2-.4 2.6M16 7.6c.1 1.4 0 2.3-.5 3.1M19.4 8.4c.15 1.1 0 1.9-.45 2.5"
        fill="none"
        stroke="hsl(var(--primary-foreground))"
        strokeWidth="1.2"
        strokeLinecap="round"
        opacity="0.8"
      />
    </svg>
  );
}

export function CupifyWordmark({ className }: { className?: string }) {
  return (
    <span className={cn("flex items-center gap-2", className)}>
      <CupifyMark className="h-8 w-8" />
      <span className="font-display text-lg font-semibold tracking-tight text-foreground">
        Cupify <span className="text-primary">Cafe</span>
      </span>
    </span>
  );
}
