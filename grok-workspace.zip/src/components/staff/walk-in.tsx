import { useMutation, useQuery } from "@tanstack/react-query";
import { useMemo, useState } from "react";
import { toast } from "sonner";
import { listAvailableProducts, placeOrder } from "@/lib/cupify/api";
import { money, cartTotals } from "@/lib/cupify/format";
import type { Order, OrderItem, PaymentMethod, Product } from "@/lib/cupify/types";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { InvoiceModal } from "@/components/invoice/invoice-modal";

export function WalkInForm() {
  const products = useQuery({ queryKey: ["products-available"], queryFn: () => listAvailableProducts() });
  const [name, setName] = useState("");
  const [phone, setPhone] = useState("");
  const [email, setEmail] = useState("");
  const [pay, setPay] = useState<PaymentMethod>("cash");
  const [items, setItems] = useState<OrderItem[]>([]);
  const [placed, setPlaced] = useState<Order | null>(null);
  const [invoice, setInvoice] = useState(false);
  const totals = useMemo(() => cartTotals(items), [items]);

  function add(p: Product) {
    setItems((prev) => {
      const hit = prev.find((i) => i.productId === String(p.id) && i.cupType === "standard");
      if (hit) return prev.map((i) => (i === hit ? { ...i, quantity: i.quantity + 1 } : i));
      return [
        ...prev,
        {
          productId: String(p.id),
          productName: p.name,
          quantity: 1,
          price: p.price,
          cupType: "standard",
          category: p.category,
        },
      ];
    });
  }

  const place = useMutation({
    mutationFn: () =>
      placeOrder({
        data: {
          customerName: name,
          customerEmail: email,
          customerPhone: phone,
          items,
          paymentMethod: pay,
          walkIn: true,
        },
      }),
    onSuccess(o) {
      setPlaced(o);
      setInvoice(true);
      setItems([]);
      toast.success("Walk-in placed");
    },
    onError(e) {
      toast.error(e instanceof Error ? e.message : "Failed");
    },
  });

  const grouped = useMemo(() => {
    const g: Record<string, Product[]> = { coffee: [], tea: [], juice: [] };
    for (const p of products.data ?? []) g[p.category]?.push(p);
    return g;
  }, [products.data]);

  return (
    <div className="grid gap-6 lg:grid-cols-2">
      <Card>
        <CardHeader>
          <CardTitle>Customer</CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          <div className="space-y-1.5">
            <Label>Name</Label>
            <Input value={name} onChange={(e) => setName(e.target.value)} />
          </div>
          <div className="space-y-1.5">
            <Label>Phone</Label>
            <Input value={phone} onChange={(e) => setPhone(e.target.value)} />
          </div>
          <div className="space-y-1.5">
            <Label>Email</Label>
            <Input value={email} onChange={(e) => setEmail(e.target.value)} />
          </div>
          <RadioGroup value={pay} onValueChange={(v) => setPay(v as PaymentMethod)}>
            {(["cash", "card", "online"] as const).map((m) => (
              <label key={m} className="flex items-center gap-2 text-sm capitalize">
                <RadioGroupItem value={m} /> {m}
              </label>
            ))}
          </RadioGroup>
        </CardContent>
      </Card>
      <Card>
        <CardHeader>
          <CardTitle>Summary</CardTitle>
        </CardHeader>
        <CardContent>
          {items.map((it, i) => (
            <div key={i} className="flex items-center justify-between py-1 text-sm">
              <span>
                {it.productName} × {it.quantity}
              </span>
              <div className="flex gap-2">
                <Button size="sm" variant="outline" onClick={() => setItems((p) => p.map((x, idx) => (idx === i ? { ...x, quantity: x.quantity + 1 } : x)))}>
                  +
                </Button>
                <Button
                  size="sm"
                  variant="outline"
                  onClick={() =>
                    setItems((p) => p.map((x, idx) => (idx === i ? { ...x, quantity: x.quantity - 1 } : x)).filter((x) => x.quantity > 0))
                  }
                >
                  −
                </Button>
              </div>
            </div>
          ))}
          <p className="mt-3 font-medium tabular-nums">{money(totals.total)}</p>
          <Button className="mt-3 w-full" disabled={!name.trim() || !items.length || place.isPending} onClick={() => place.mutate()}>
            Place order & generate invoice
          </Button>
        </CardContent>
      </Card>
      {Object.entries(grouped).map(([cat, list]) => (
        <div key={cat} className="lg:col-span-2">
          <h3 className="mb-2 font-display text-lg capitalize">{cat}</h3>
          <div className="grid gap-2 sm:grid-cols-3">
            {list.map((p) => {
              const qty = items.find((i) => i.productId === String(p.id))?.quantity;
              return (
                <button key={p.id} type="button" onClick={() => add(p)} className="rounded-lg border border-border bg-card p-3 text-left hover:bg-secondary">
                  <p className="font-medium">{p.name}</p>
                  <p className="text-xs text-muted-foreground">{money(p.price)}</p>
                  {qty ? <p className="mt-1 text-xs">{qty} in order</p> : null}
                </button>
              );
            })}
          </div>
        </div>
      ))}
      <InvoiceModal order={placed} open={invoice} onOpenChange={setInvoice} />
    </div>
  );
}
