import { createFileRoute } from "@tanstack/react-router";
import { Mail, Instagram } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";

export const Route = createFileRoute("/_app/about")({ component: AboutPage });

function AboutPage() {
  return (
    <main className="mx-auto max-w-3xl px-4 py-12">
      <div className="animate-rise space-y-3">
        <p className="text-xs font-medium uppercase tracking-[0.2em] text-accent">Founder</p>
        <h1 className="font-display text-4xl font-semibold">Syed Meesam Abbas Sherazi</h1>
        <p className="text-muted-foreground">Cupify Cafe is a small-batch café built around a simple idea: every cup can carry a story.</p>
      </div>
      <div className="mt-10 space-y-6">
        <Card>
          <CardHeader>
            <CardTitle>About</CardTitle>
          </CardHeader>
          <CardContent className="space-y-3 text-sm leading-relaxed text-muted-foreground">
            <p>
              We roast, brew, and print under one roof. Customers order a drink, personalize the cup, and pick it up when the board says ready. Staff run the floor; admins keep the books honest.
            </p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader>
            <CardTitle>Expertise & vision</CardTitle>
          </CardHeader>
          <CardContent className="text-sm leading-relaxed text-muted-foreground">
            A cafe that feels like a studio — espresso discipline, custom print, and operations that don’t lose an order between the counter and the printer.
          </CardContent>
        </Card>
        <Card>
          <CardHeader>
            <CardTitle>Contact</CardTitle>
          </CardHeader>
          <CardContent className="space-y-2 text-sm">
            <p className="flex items-center gap-2">
              <Mail className="h-4 w-4 text-accent" />
              <a className="hover:underline" href="mailto:hello@cupify.cafe">
                hello@cupify.cafe
              </a>
            </p>
            <p className="flex items-center gap-2">
              <Instagram className="h-4 w-4 text-accent" />
              <span>@meesam4079</span>
            </p>
          </CardContent>
        </Card>
      </div>
    </main>
  );
}
