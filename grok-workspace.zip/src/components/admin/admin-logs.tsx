import { useQuery } from "@tanstack/react-query";
import { useMemo, useState } from "react";
import { listLogs } from "@/lib/cupify/api";
import { when } from "@/lib/cupify/format";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

export function AdminLogsTab() {
  const logs = useQuery({ queryKey: ["logs"], queryFn: () => listLogs() });
  const [q, setQ] = useState("");
  const [role, setRole] = useState("all");
  const [entity, setEntity] = useState("all");
  const rows = useMemo(() => {
    return (logs.data ?? []).filter((l) => {
      if (role !== "all" && l.userRole !== role) return false;
      if (entity !== "all" && l.entityType !== entity) return false;
      const s = q.trim().toLowerCase();
      if (s && !`${l.userName} ${l.action}`.toLowerCase().includes(s)) return false;
      return true;
    });
  }, [logs.data, q, role, entity]);

  return (
    <div className="space-y-3">
      <div className="flex flex-wrap gap-2">
        <Input placeholder="Search user or action" value={q} onChange={(e) => setQ(e.target.value)} className="max-w-xs" />
        <Select value={role} onValueChange={setRole}>
          <SelectTrigger className="w-32">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All roles</SelectItem>
            <SelectItem value="admin">Admin</SelectItem>
            <SelectItem value="staff">Staff</SelectItem>
            <SelectItem value="customer">Customer</SelectItem>
          </SelectContent>
        </Select>
        <Select value={entity} onValueChange={setEntity}>
          <SelectTrigger className="w-32">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All entities</SelectItem>
            <SelectItem value="order">Order</SelectItem>
            <SelectItem value="product">Product</SelectItem>
            <SelectItem value="user">User</SelectItem>
          </SelectContent>
        </Select>
      </div>
      <div className="max-h-[70vh] overflow-y-auto">
        <table className="w-full text-left text-sm">
          <thead>
            <tr className="border-b text-muted-foreground">
              <th className="py-2">When</th>
              <th>Who</th>
              <th>Action</th>
              <th>Entity</th>
            </tr>
          </thead>
          <tbody>
            {rows.map((l) => (
              <tr key={l.id} className="border-b border-border/50">
                <td className="py-2 whitespace-nowrap text-xs">{when(l.createdAt)}</td>
                <td>
                  {l.userName} <Badge variant="secondary">{l.userRole}</Badge>
                </td>
                <td>{l.action}</td>
                <td className="text-xs text-muted-foreground">
                  {l.entityType} {l.entityId}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
