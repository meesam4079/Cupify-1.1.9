import type {
  ActivityLog,
  Order,
  OrderItem,
  OrderStatus,
  PaymentMethod,
  Product,
  ProductCategory,
  Profile,
  RefundRequest,
  Remark,
  UserRole,
} from "./types";

function str(v: unknown, fallback = "") {
  return v == null ? fallback : String(v);
}
function num(v: unknown, fallback = 0) {
  const n = typeof v === "number" ? v : Number(v);
  return Number.isFinite(n) ? n : fallback;
}
function bool(v: unknown) {
  return v === true || v === "t" || v === "true" || v === 1;
}
function iso(v: unknown) {
  if (!v) return "";
  if (v instanceof Date) return v.toISOString();
  return String(v);
}

function items(v: unknown): OrderItem[] {
  let raw: unknown = v;
  if (typeof raw === "string") {
    try {
      raw = JSON.parse(raw);
    } catch {
      return [];
    }
  }
  if (!Array.isArray(raw)) return [];
  return raw.map((it) => {
    const o = (it ?? {}) as Record<string, unknown>;
    return {
      productId: str(o.productId ?? o.product_id),
      productName: str(o.productName ?? o.product_name),
      quantity: num(o.quantity, 1),
      price: num(o.price),
      cupType: str(o.cupType ?? o.cup_type, "standard") as OrderItem["cupType"],
      category: (o.category ? str(o.category) : undefined) as ProductCategory | undefined,
      customCupName: o.customCupName || o.custom_cup_name ? str(o.customCupName ?? o.custom_cup_name) : undefined,
      customCupMessage: o.customCupMessage || o.custom_cup_message ? str(o.customCupMessage ?? o.custom_cup_message) : undefined,
      customCupImageUrl: o.customCupImageUrl || o.custom_cup_image_url ? str(o.customCupImageUrl ?? o.custom_cup_image_url) : undefined,
      customCupCharge: o.customCupCharge != null || o.custom_cup_charge != null ? num(o.customCupCharge ?? o.custom_cup_charge) : undefined,
    };
  });
}

export function mapProfile(row: Record<string, unknown>): Profile {
  return {
    userId: str(row.user_id),
    email: str(row.email),
    displayName: str(row.display_name),
    role: (str(row.role, "user") as UserRole) || "user",
    isActive: bool(row.is_active),
    createdAt: iso(row.created_at),
  };
}

export function mapProduct(row: Record<string, unknown>): Product {
  return {
    id: num(row.id),
    name: str(row.name),
    category: str(row.category) as ProductCategory,
    price: num(row.price),
    description: str(row.description),
    imageUrl: str(row.image_url),
    isAvailable: bool(row.is_available),
    customCupCharge: num(row.custom_cup_charge),
  };
}

export function mapOrder(row: Record<string, unknown>): Order {
  return {
    id: num(row.id),
    userId: row.user_id ? str(row.user_id) : null,
    orderNumber: str(row.order_number),
    customerName: str(row.customer_name),
    customerEmail: str(row.customer_email),
    customerPhone: str(row.customer_phone),
    items: items(row.items),
    subtotal: num(row.subtotal),
    customCharges: num(row.custom_charges),
    total: num(row.total),
    advancePaid: num(row.advance_paid),
    balanceDue: num(row.balance_due),
    isVip: bool(row.is_vip),
    walkIn: bool(row.walk_in),
    status: str(row.status, "received") as OrderStatus,
    consentOwnImage: bool(row.consent_own_image),
    consentMarketing: bool(row.consent_marketing),
    assignedStaffId: row.assigned_staff_id ? str(row.assigned_staff_id) : null,
    assignedStaffName: row.assigned_staff_name ? str(row.assigned_staff_name) : null,
    paymentMethod: str(row.payment_method, "cash") as PaymentMethod,
    notes: str(row.notes),
    lockedByStaffId: row.locked_by_staff_id ? str(row.locked_by_staff_id) : null,
    lockedByStaffName: row.locked_by_staff_name ? str(row.locked_by_staff_name) : null,
    lockedAt: row.locked_at ? iso(row.locked_at) : null,
    previousStatus: row.previous_status ? (str(row.previous_status) as OrderStatus) : null,
    createdAt: iso(row.created_at),
    updatedAt: iso(row.updated_at),
  };
}

export function mapRefund(row: Record<string, unknown>): RefundRequest {
  return {
    id: num(row.id),
    orderId: num(row.order_id),
    orderNumber: str(row.order_number),
    customerName: str(row.customer_name),
    requestType: str(row.request_type) as RefundRequest["requestType"],
    reason: str(row.reason),
    status: str(row.status) as RefundRequest["status"],
    requestedById: str(row.requested_by_id),
    requestedByName: str(row.requested_by_name),
    reviewedById: row.reviewed_by_id ? str(row.reviewed_by_id) : null,
    reviewedByName: row.reviewed_by_name ? str(row.reviewed_by_name) : null,
    adminNote: str(row.admin_note),
    amount: num(row.amount),
    createdAt: iso(row.created_at),
  };
}

export function mapRemark(row: Record<string, unknown>): Remark {
  return {
    id: num(row.id),
    orderId: num(row.order_id),
    orderNumber: str(row.order_number),
    customerName: str(row.customer_name),
    staffId: str(row.staff_id),
    staffName: str(row.staff_name),
    content: str(row.content),
    createdAt: iso(row.created_at),
  };
}

export function mapLog(row: Record<string, unknown>): ActivityLog {
  return {
    id: num(row.id),
    userName: str(row.user_name),
    userRole: str(row.user_role),
    action: str(row.action),
    entityType: str(row.entity_type),
    entityId: str(row.entity_id),
    createdAt: iso(row.created_at),
  };
}

export function mapStaff(row: Record<string, unknown>): Profile {
  return mapProfile(row);
}
