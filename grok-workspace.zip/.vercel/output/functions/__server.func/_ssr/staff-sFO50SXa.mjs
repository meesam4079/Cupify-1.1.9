import { o as __toESM } from "../_runtime.mjs";
import { t as cn } from "./utils-C_uf36nf.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { p as require_jsx_runtime } from "../_libs/@radix-ui/react-checkbox+[...].mjs";
import { t as Button } from "./button-D_PHfu3x.mjs";
import { a as CardTitle, i as CardHeader, n as CardContent, t as Card } from "./card-BqLLulKB.mjs";
import { m as when, r as cartTotals, u as money } from "./format-ydPugZ1g.mjs";
import { _ as lockOrder, a as dashboardStats, b as requestCancel, g as listStaffOrders, i as cancelItems, m as listRemarks, s as getMyProfile, t as addRemark, u as listAvailableProducts, v as placeOrder } from "./api-DUpluZ3_.mjs";
import { i as useQueryClient, n as useQuery, t as useMutation } from "../_libs/tanstack__react-query.mjs";
import { t as Protected } from "./protected-CvCgsFxJ.mjs";
import { i as TabsTrigger, n as TabsContent, r as TabsList, t as Tabs } from "./tabs-DQHqT2d-.mjs";
import { n as StatusBadge, t as Badge } from "./status-badge-CypCGZWh.mjs";
import { o as InvoiceModal } from "./invoice-modal-DmA2m8xY.mjs";
import { t as Textarea } from "./textarea-flI-r2o4.mjs";
import { t as Input } from "./input-C8FVBVyT.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { n as InquiryTab, r as OrderDetailPanel, t as DateOrdersTab } from "./inquiry-tab-Dp5kp2Qt.mjs";
import { t as Label } from "./label-2J_LU4QX.mjs";
import { t as Skeleton } from "./skeleton-cOr9hq3l.mjs";
import { n as RadioGroupItem, t as RadioGroup } from "./radio-group-D_XWRx-p.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/staff-sFO50SXa.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function StaffDashboard() {
	const q = useQuery({
		queryKey: ["dash"],
		queryFn: () => dashboardStats(),
		refetchInterval: 5e3
	});
	if (q.isPending) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "mt-4 h-40" });
	const d = q.data;
	if (!d) return null;
	const cards = [
		["New orders", d.byStatus.received ?? 0],
		["In progress", (d.byStatus.designing ?? 0) + (d.byStatus.printing ?? 0)],
		["Ready", d.byStatus.ready ?? 0],
		["Delivered", d.byStatus.delivered ?? 0],
		["Refund requests", d.pendingRefunds],
		["Cancel requests", d.byStatus.cancel_requested ?? 0],
		["Remarks today", d.remarksToday],
		["Total active", (d.byStatus.received ?? 0) + (d.byStatus.designing ?? 0) + (d.byStatus.printing ?? 0) + (d.byStatus.ready ?? 0)]
	];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-4",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "grid gap-3 sm:grid-cols-2 lg:grid-cols-4",
			children: cards.map(([label, n]) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardHeader, {
				className: "pb-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs uppercase tracking-wide text-muted-foreground",
					children: label
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardTitle, {
					className: "text-2xl tabular-nums",
					children: n
				})]
			}) }, label))
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardTitle, {
			className: "text-base",
			children: "Today"
		}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardContent, {
			className: "text-sm text-muted-foreground",
			children: [
				d.todayOrders,
				" orders · ",
				d.pendingRefunds,
				" pending approvals · ",
				d.remarksToday,
				" remarks"
			]
		})] })]
	});
}
function OrdersSplit() {
	const me = useQuery({
		queryKey: ["me"],
		queryFn: () => getMyProfile()
	});
	const orders = useQuery({
		queryKey: ["staff-orders"],
		queryFn: () => listStaffOrders(),
		refetchInterval: 4e3
	});
	const [selected, setSelected] = (0, import_react.useState)(null);
	const [q, setQ] = (0, import_react.useState)("");
	const [channel, setChannel] = (0, import_react.useState)("all");
	const [cat, setCat] = (0, import_react.useState)("all");
	const lock = useMutation({ mutationFn: (id) => lockOrder({ data: { id } }) });
	(0, import_react.useEffect)(() => {
		lock.mutate(selected);
		return () => {
			lock.mutate(null);
		};
	}, [selected]);
	const list = (0, import_react.useMemo)(() => {
		let rows = orders.data ?? [];
		if (channel === "walk") rows = rows.filter((o) => o.walkIn);
		if (channel === "online") rows = rows.filter((o) => !o.walkIn);
		if (cat !== "all") rows = rows.filter((o) => o.items.some((i) => i.category === cat));
		const s = q.trim().toLowerCase();
		if (s) rows = rows.filter((o) => o.orderNumber.toLowerCase().includes(s) || o.customerName.toLowerCase().includes(s) || o.customerPhone.toLowerCase().includes(s) || o.items.some((i) => i.productName.toLowerCase().includes(s)));
		return rows;
	}, [
		orders.data,
		q,
		channel,
		cat
	]);
	const current = list.find((o) => o.id === selected) ?? (orders.data ?? []).find((o) => o.id === selected);
	const counts = {
		all: (orders.data ?? []).length,
		coffee: (orders.data ?? []).filter((o) => o.items.some((i) => i.category === "coffee")).length,
		tea: (orders.data ?? []).filter((o) => o.items.some((i) => i.category === "tea")).length,
		juice: (orders.data ?? []).filter((o) => o.items.some((i) => i.category === "juice")).length
	};
	function banner(o) {
		if (!o.lockedByStaffId || o.lockedByStaffId === me.data?.userId) return null;
		if (o.lockedAt && Date.now() - new Date(o.lockedAt).getTime() > 12e4) return null;
		return `${o.lockedByStaffName} is currently viewing this order`;
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "grid gap-4 lg:grid-cols-[320px_1fr]",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "space-y-3",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					placeholder: "Search order, name, phone, drink",
					value: q,
					onChange: (e) => setQ(e.target.value)
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex flex-wrap gap-2",
					children: [
						"all",
						"walk",
						"online"
					].map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => setChannel(c),
						className: cn("rounded-full border px-3 py-1 text-xs", channel === c ? "bg-secondary" : "border-border"),
						children: c === "all" ? "All" : c === "walk" ? "Walk-in" : "Online"
					}, c))
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-xs text-muted-foreground",
					children: [list.length, " records"]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tabs, {
					value: cat,
					onValueChange: (v) => setCat(v),
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TabsList, {
						className: "h-auto flex-wrap",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TabsTrigger, {
								value: "all",
								children: ["All ", counts.all]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TabsTrigger, {
								value: "coffee",
								children: ["Coffee ", counts.coffee]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TabsTrigger, {
								value: "tea",
								children: ["Tea ", counts.tea]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TabsTrigger, {
								value: "juice",
								children: ["Juice ", counts.juice]
							})
						]
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "max-h-[70vh] space-y-2 overflow-y-auto",
					children: list.map((o) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => setSelected(o.id),
						className: cn("w-full rounded-lg border p-3 text-left", selected === o.id ? "border-primary bg-secondary" : "border-border bg-card hover:bg-secondary/50"),
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-2",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "grid h-8 w-8 place-items-center rounded-full bg-primary text-xs text-primary-foreground",
									children: o.customerName.charAt(0).toUpperCase()
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "min-w-0 flex-1",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-center gap-2",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "truncate text-sm font-medium",
												children: o.orderNumber
											}),
											o.walkIn && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
												variant: "secondary",
												children: "W"
											}),
											o.isVip && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
												variant: "accent",
												children: "VIP"
											})
										]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "truncate text-xs text-muted-foreground",
										children: o.customerName
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatusBadge, { status: o.status })
							]
						})
					}, o.id))
				})
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "rounded-xl border border-border bg-card p-5",
			children: current ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(OrderDetailPanel, {
				order: current,
				lockBanner: banner(current)
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "py-16 text-center text-sm text-muted-foreground",
				children: "Select an order"
			})
		})]
	});
}
function CancelRefundTab() {
	const qc = useQueryClient();
	const orders = useQuery({
		queryKey: ["staff-orders"],
		queryFn: () => listStaffOrders()
	});
	const received = (orders.data ?? []).filter((o) => o.status === "received");
	const inprod = (orders.data ?? []).filter((o) => [
		"designing",
		"printing",
		"ready"
	].includes(o.status));
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Tabs, {
		defaultValue: "direct",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TabsList, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsTrigger, {
				value: "direct",
				children: "Direct cancel"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsTrigger, {
				value: "request",
				children: "Request cancellation"
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsContent, {
				value: "direct",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CancelList, {
					orders: received,
					onSubmit: (o, qty, reason, full) => cancelItems({ data: {
						orderId: o.id,
						quantities: qty,
						reason,
						full
					} }).then(() => {
						toast.success("Updated");
						qc.invalidateQueries({ queryKey: ["staff-orders"] });
					})
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsContent, {
				value: "request",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CancelList, {
					orders: inprod,
					requestOnly: true,
					onSubmit: (o, _qty, reason) => requestCancel({ data: {
						orderId: o.id,
						reason
					} }).then(() => {
						toast.success("Request sent");
						qc.invalidateQueries({ queryKey: ["staff-orders"] });
					})
				})
			})
		]
	});
}
function CancelList({ orders, onSubmit, requestOnly }) {
	const [open, setOpen] = (0, import_react.useState)(null);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-3",
		children: [orders.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-sm text-muted-foreground",
			children: "No matching orders."
		}), orders.map((o) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "rounded-xl border border-border bg-card p-4",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				type: "button",
				className: "flex w-full items-center justify-between text-left",
				onClick: () => setOpen(open === o.id ? null : o.id),
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "font-medium",
					children: [
						o.orderNumber,
						" · ",
						o.customerName
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-sm tabular-nums",
					children: money(o.total)
				})]
			}), open === o.id && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CancelForm, {
				order: o,
				requestOnly,
				onSubmit
			})]
		}, o.id))]
	});
}
function CancelForm({ order, requestOnly, onSubmit }) {
	const [qty, setQty] = (0, import_react.useState)({});
	const [reason, setReason] = (0, import_react.useState)("");
	const mut = useMutation({
		mutationFn: (full) => onSubmit(order, qty, reason, full),
		onError(e) {
			toast.error(e instanceof Error ? e.message : "Failed");
		}
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mt-3 space-y-3",
		children: [
			!requestOnly && order.items.map((it, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center justify-between text-sm",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
					it.productName,
					" (",
					it.quantity,
					")"
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					type: "number",
					min: 0,
					max: it.quantity,
					className: "h-9 w-20 rounded-md border border-input bg-card px-2 text-sm",
					value: qty[i] ?? 0,
					onChange: (e) => setQty({
						...qty,
						[i]: Number(e.target.value)
					})
				})]
			}, i)),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
				placeholder: "Reason (required)",
				value: reason,
				onChange: (e) => setReason(e.target.value)
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex gap-2",
				children: [!requestOnly && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "outline",
					disabled: !reason.trim() || mut.isPending,
					onClick: () => mut.mutate(false),
					children: "Partial cancel"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "destructive",
					disabled: !reason.trim() || mut.isPending,
					onClick: () => mut.mutate(true),
					children: "Full cancel"
				})] }), requestOnly && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					disabled: !reason.trim() || mut.isPending,
					onClick: () => mut.mutate(false),
					children: "Request cancellation"
				})]
			})
		]
	});
}
function RemarksTab() {
	const qc = useQueryClient();
	const orders = useQuery({
		queryKey: ["staff-orders"],
		queryFn: () => listStaffOrders()
	});
	const remarks = useQuery({
		queryKey: ["remarks-all"],
		queryFn: () => listRemarks({ data: {} })
	});
	const [q, setQ] = (0, import_react.useState)("");
	const [picked, setPicked] = (0, import_react.useState)(null);
	const [content, setContent] = (0, import_react.useState)("");
	const matches = (0, import_react.useMemo)(() => {
		const s = q.trim().toLowerCase();
		if (!s) return [];
		return (orders.data ?? []).filter((o) => o.orderNumber.toLowerCase().includes(s) || o.customerName.toLowerCase().includes(s)).slice(0, 8);
	}, [orders.data, q]);
	const mut = useMutation({
		mutationFn: () => addRemark({ data: {
			orderId: picked,
			content
		} }),
		onSuccess() {
			setContent("");
			toast.success("Saved");
			qc.invalidateQueries({ queryKey: ["remarks-all"] });
		}
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "grid gap-6 lg:grid-cols-2",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "space-y-3",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					placeholder: "Search order number or name",
					value: q,
					onChange: (e) => setQ(e.target.value)
				}),
				matches.map((o) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					onClick: () => {
						setPicked(o.id);
						setQ(o.orderNumber);
					},
					className: "block w-full rounded-md border border-border px-3 py-2 text-left text-sm hover:bg-secondary",
					children: [
						o.orderNumber,
						" · ",
						o.customerName
					]
				}, o.id)),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
					value: content,
					onChange: (e) => setContent(e.target.value),
					placeholder: "Remark"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					disabled: !picked || !content.trim() || mut.isPending,
					onClick: () => mut.mutate(),
					children: "Add remark"
				})
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "max-h-[70vh] space-y-2 overflow-y-auto",
			children: (remarks.data ?? []).map((r) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "rounded-lg border border-border bg-card p-3 text-sm",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "font-medium",
						children: [
							r.orderNumber,
							" · ",
							r.customerName
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1",
						children: r.content
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-1 text-xs text-muted-foreground",
						children: [
							r.staffName,
							" · ",
							when(r.createdAt)
						]
					})
				]
			}, r.id))
		})]
	});
}
function WalkInForm() {
	const products = useQuery({
		queryKey: ["products-available"],
		queryFn: () => listAvailableProducts()
	});
	const [name, setName] = (0, import_react.useState)("");
	const [phone, setPhone] = (0, import_react.useState)("");
	const [email, setEmail] = (0, import_react.useState)("");
	const [pay, setPay] = (0, import_react.useState)("cash");
	const [items, setItems] = (0, import_react.useState)([]);
	const [placed, setPlaced] = (0, import_react.useState)(null);
	const [invoice, setInvoice] = (0, import_react.useState)(false);
	const totals = (0, import_react.useMemo)(() => cartTotals(items), [items]);
	function add(p) {
		setItems((prev) => {
			const hit = prev.find((i) => i.productId === String(p.id) && i.cupType === "standard");
			if (hit) return prev.map((i) => i === hit ? {
				...i,
				quantity: i.quantity + 1
			} : i);
			return [...prev, {
				productId: String(p.id),
				productName: p.name,
				quantity: 1,
				price: p.price,
				cupType: "standard",
				category: p.category
			}];
		});
	}
	const place = useMutation({
		mutationFn: () => placeOrder({ data: {
			customerName: name,
			customerEmail: email,
			customerPhone: phone,
			items,
			paymentMethod: pay,
			walkIn: true
		} }),
		onSuccess(o) {
			setPlaced(o);
			setInvoice(true);
			setItems([]);
			toast.success("Walk-in placed");
		},
		onError(e) {
			toast.error(e instanceof Error ? e.message : "Failed");
		}
	});
	const grouped = (0, import_react.useMemo)(() => {
		const g = {
			coffee: [],
			tea: [],
			juice: []
		};
		for (const p of products.data ?? []) g[p.category]?.push(p);
		return g;
	}, [products.data]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "grid gap-6 lg:grid-cols-2",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardTitle, { children: "Customer" }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardContent, {
				className: "space-y-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-1.5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Name" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							value: name,
							onChange: (e) => setName(e.target.value)
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-1.5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Phone" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							value: phone,
							onChange: (e) => setPhone(e.target.value)
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-1.5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Email" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							value: email,
							onChange: (e) => setEmail(e.target.value)
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RadioGroup, {
						value: pay,
						onValueChange: (v) => setPay(v),
						children: [
							"cash",
							"card",
							"online"
						].map((m) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "flex items-center gap-2 text-sm capitalize",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RadioGroupItem, { value: m }),
								" ",
								m
							]
						}, m))
					})
				]
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardTitle, { children: "Summary" }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardContent, { children: [
				items.map((it, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center justify-between py-1 text-sm",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
						it.productName,
						" × ",
						it.quantity
					] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							size: "sm",
							variant: "outline",
							onClick: () => setItems((p) => p.map((x, idx) => idx === i ? {
								...x,
								quantity: x.quantity + 1
							} : x)),
							children: "+"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							size: "sm",
							variant: "outline",
							onClick: () => setItems((p) => p.map((x, idx) => idx === i ? {
								...x,
								quantity: x.quantity - 1
							} : x).filter((x) => x.quantity > 0)),
							children: "−"
						})]
					})]
				}, i)),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-3 font-medium tabular-nums",
					children: money(totals.total)
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					className: "mt-3 w-full",
					disabled: !name.trim() || !items.length || place.isPending,
					onClick: () => place.mutate(),
					children: "Place order & generate invoice"
				})
			] })] }),
			Object.entries(grouped).map(([cat, list]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "lg:col-span-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
					className: "mb-2 font-display text-lg capitalize",
					children: cat
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "grid gap-2 sm:grid-cols-3",
					children: list.map((p) => {
						const qty = items.find((i) => i.productId === String(p.id))?.quantity;
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							onClick: () => add(p),
							className: "rounded-lg border border-border bg-card p-3 text-left hover:bg-secondary",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "font-medium",
									children: p.name
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-xs text-muted-foreground",
									children: money(p.price)
								}),
								qty ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "mt-1 text-xs",
									children: [qty, " in order"]
								}) : null
							]
						}, p.id);
					})
				})]
			}, cat)),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(InvoiceModal, {
				order: placed,
				open: invoice,
				onOpenChange: setInvoice
			})
		]
	});
}
function StaffRoute() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Protected, {
		roles: ["staff", "admin"],
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StaffPage, {})
	});
}
function StaffPage() {
	const me = useQuery({
		queryKey: ["me"],
		queryFn: () => getMyProfile()
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "mx-auto max-w-6xl px-4 py-8",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "font-display text-3xl font-semibold",
				children: "Staff panel"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-1 text-sm text-muted-foreground",
				children: [
					"Welcome",
					me.data?.displayName ? `, ${me.data.displayName}` : "",
					". Keep the board moving."
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Tabs, {
				defaultValue: "dashboard",
				className: "mt-6",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TabsList, {
						className: "h-auto w-full flex-wrap justify-start overflow-x-auto",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsTrigger, {
								value: "dashboard",
								children: "Dashboard"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsTrigger, {
								value: "orders",
								children: "Orders"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsTrigger, {
								value: "date",
								children: "By date"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsTrigger, {
								value: "cancel",
								children: "Cancel / refund"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsTrigger, {
								value: "remarks",
								children: "Remarks"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsTrigger, {
								value: "inquiry",
								children: "Inquiry"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsTrigger, {
								value: "walkin",
								children: "Walk-in"
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsContent, {
						value: "dashboard",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StaffDashboard, {})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsContent, {
						value: "orders",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(OrdersSplit, {})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsContent, {
						value: "date",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DateOrdersTab, {})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsContent, {
						value: "cancel",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CancelRefundTab, {})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsContent, {
						value: "remarks",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RemarksTab, {})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsContent, {
						value: "inquiry",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(InquiryTab, {})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsContent, {
						value: "walkin",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(WalkInForm, {})
					})
				]
			})
		]
	});
}
//#endregion
export { StaffRoute as component };
