import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { useMutation } from "@tanstack/react-query";
import { getOrderByNumber, searchInvoices } from "@/lib/cupify/api";
import { money, statusLabel, TIMELINE, when } from "@/lib/cupify/format";
import type { Order, OrderStatus } from "@/lib/cupify/types";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { StatusBadge } from "@/components/shared/status-badge";
import { InvoiceModal } from "@/components/invoice/invoice-modal";
import { Badge } from "@/components/ui/badge";
import { Check } from "lucide-react";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/_app/track")({ component: TrackPage });

function TrackPage() {
  const [num, setNum] = useState("");
  const [q, setQ] = useState("");
  const [order, setOrder] = useState<Order | null>(null);
  const [matches, setMatches] = useState<Order[]>([]);
  const [invoice, setInvoice] = useState(false);

  const byNumber = useMutation({
    mutationFn: () => getOrderByNumber({ data: { orderNumber: num } }),
    onSuccess(o) {
      setOrder(o);
    },
  });
  const search = useMutation({
    mutationFn: () => searchInvoices({ data: { q } }),
    onSuccess(list) {
      setMatches(list);
    },
  });

  return (
    <main className="mx-auto max-w-3xl px-4 py-10">
      <h1 className="font-display text-3xl font-semibold">Track</h1>
      <Tabs defaultValue="order" className="mt-6">
        <TabsList>
          <TabsTrigger value="order">Track order</TabsTrigger>
          <TabsTrigger value="invoice">Track invoice</TabsTrigger>
        </TabsList>
        <TabsContent value="order">
          <form
            className="flex gap-2"
            onSubmit={(e) => {
              e.preventDefault();
              byNumber.mutate();
            }}
          >
            <Input placeholder="CUP-000001" value={num} onChange={(e) => setNum(e.target.value)} />
            <Button type="submit" disabled={byNumber.isPending}>
              Search
            </Button>
          </form>
          {byNumber.isSuccess && !order && <p className="mt-4 text-sm text-muted-foreground">No order with that number.</p>}
          {order && <OrderResult order={order} onInvoice={() => setInvoice(true)} />}
        </TabsContent>
        <TabsContent value="invoice">
          <form
            className="flex gap-2"
            onSubmit={(e) => {
              e.preventDefault();
              search.mutate();
            }}
          >
            <Input placeholder="Phone, email, name, or order #" value={q} onChange={(e) => setQ(e.target.value)} />
            <Button type="submit" disabled={search.isPending}>
              Search
            </Button>
          </form>
          <div className="mt-4 space-y-2">
            {matches.map((o) => (
              <button
                key={o.id}
                type="button"
                className="w-full rounded-lg border border-border bg-card p-3 text-left hover:bg-secondary/60"
                onClick={() => {
                  setOrder(o);
                  setInvoice(true);
                }}
              >
                <div className="flex items-center justify-between">
                  <span className="font-medium">{o.orderNumber}</span>
                  <span className="text-sm tabular-nums">{money(o.total)}</span>
                </div>
                <p className="text-xs text-muted-foreground">{o.customerName}</p>
              </button>
            ))}
          </div>
        </TabsContent>
      </Tabs>
      <InvoiceModal order={order} open={invoice} onOpenChange={setInvoice} />
    </main>
  );
}

function OrderResult({ order, onInvoice }: { order: Order; onInvoice: () => void }) {
  const idx = TIMELINE.indexOf(order.status as (typeof TIMELINE)[number]);
  return (
    <Card className="mt-6">
      <CardHeader>
        <div className="flex flex-wrap items-center gap-2">
          <CardTitle>{order.orderNumber}</CardTitle>
          {order.isVip && <Badge variant="accent">VIP</Badge>}
          <Badge variant="secondary">{order.walkIn ? "Walk-in" : "Online"}</Badge>
          <StatusBadge status={order.status} />
        </div>
        <p className="text-sm text-muted-foreground">{when(order.createdAt)}</p>
      </CardHeader>
      <CardContent className="space-y-6">
        {order.status === "cancelled" ? (
          <p className="text-sm text-destructive">This order was cancelled.</p>
        ) : (
          <ol className="flex items-center gap-1">
            {TIMELINE.map((s, i) => {
              const done = idx >= i && order.status !== "cancel_requested";
              const current = order.status === s;
              return (
                <li key={s} className="flex flex-1 flex-col items-center gap-1 text-center">
                  <span
                    className={cn(
                      "flex h-7 w-7 items-center justify-center rounded-full border text-xs",
                      done || current ? "border-primary bg-primary text-primary-foreground" : "border-border text-muted-foreground",
                    )}
                  >
                    {done && !current ? <Check className="h-3.5 w-3.5" /> : i + 1}
                  </span>
                  <span className="text-[10px] text-muted-foreground">{statusLabel(s as OrderStatus)}</span>
                </li>
              );
            })}
          </ol>
        )}
        <ul className="space-y-1 text-sm">
          {order.items.map((it, i) => (
            <li key={i} className="flex justify-between">
              <span>
                {it.quantity}× {it.productName}
              </span>
              <span className="tabular-nums">{money(it.price * it.quantity)}</span>
            </li>
          ))}
        </ul>
        <div className="flex justify-between font-medium">
          <span>Total</span>
          <span className="tabular-nums">{money(order.total)}</span>
        </div>
        <Button onClick={onInvoice}>View invoice</Button>
      </CardContent>
    </Card>
  );
}
