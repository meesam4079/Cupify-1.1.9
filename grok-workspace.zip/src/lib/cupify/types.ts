export type UserRole = "admin" | "staff" | "user";

export type OrderStatus =
  | "received"
  | "designing"
  | "printing"
  | "ready"
  | "delivered"
  | "cancelled"
  | "cancel_requested";

export type PaymentMethod = "cash" | "card" | "online";
export type ProductCategory = "coffee" | "tea" | "juice";
export type CupType = "standard" | "custom";

export const ADVANCE_RATE = 0.3;
export const VIP_SURCHARGE = 100;
export const LOCK_MS = 2 * 60 * 1000;

export type Profile = {
  userId: string;
  email: string;
  displayName: string;
  role: UserRole;
  isActive: boolean;
  createdAt: string;
};

export type Product = {
  id: number;
  name: string;
  category: ProductCategory;
  price: number;
  description: string;
  imageUrl: string;
  isAvailable: boolean;
  customCupCharge: number;
};

export type OrderItem = {
  productId: string;
  productName: string;
  quantity: number;
  price: number;
  cupType: CupType;
  category?: ProductCategory;
  customCupName?: string;
  customCupMessage?: string;
  customCupImageUrl?: string;
  customCupCharge?: number;
};

export type CartLine = OrderItem & { cartId: string };

export type Order = {
  id: number;
  userId: string | null;
  orderNumber: string;
  customerName: string;
  customerEmail: string;
  customerPhone: string;
  items: OrderItem[];
  subtotal: number;
  customCharges: number;
  total: number;
  advancePaid: number;
  balanceDue: number;
  isVip: boolean;
  walkIn: boolean;
  status: OrderStatus;
  consentOwnImage: boolean;
  consentMarketing: boolean;
  assignedStaffId: string | null;
  assignedStaffName: string | null;
  paymentMethod: PaymentMethod;
  notes: string;
  lockedByStaffId: string | null;
  lockedByStaffName: string | null;
  lockedAt: string | null;
  previousStatus: OrderStatus | null;
  createdAt: string;
  updatedAt: string;
};

export type RefundRequest = {
  id: number;
  orderId: number;
  orderNumber: string;
  customerName: string;
  requestType: "refund" | "cancellation";
  reason: string;
  status: "pending" | "approved" | "rejected";
  requestedById: string;
  requestedByName: string;
  reviewedById: string | null;
  reviewedByName: string | null;
  adminNote: string;
  amount: number;
  createdAt: string;
};

export type Remark = {
  id: number;
  orderId: number;
  orderNumber: string;
  customerName: string;
  staffId: string;
  staffName: string;
  content: string;
  createdAt: string;
};

export type ActivityLog = {
  id: number;
  userName: string;
  userRole: string;
  action: string;
  entityType: string;
  entityId: string;
  createdAt: string;
};

export type PlaceOrderInput = {
  customerName: string;
  customerEmail: string;
  customerPhone: string;
  items: OrderItem[];
  paymentMethod: PaymentMethod;
  notes?: string;
  consentOwnImage?: boolean;
  consentMarketing?: boolean;
  isVip?: boolean;
  walkIn?: boolean;
};
