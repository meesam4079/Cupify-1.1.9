import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { money } from "@/lib/cupify/format";
import type { Product } from "@/lib/cupify/types";

const fallback: Record<string, string> = {
  coffee: "https://images.unsplash.com/photo-1495474472287-4d71bcdd2085?w=800&q=80",
  tea: "https://images.unsplash.com/photo-1556679343-c7306c197c0b?w=800&q=80",
  juice: "https://images.unsplash.com/photo-1600271886742-f049cd451bba?w=800&q=80",
};

export function MenuCard({
  product,
  onAdd,
  compact,
}: {
  product: Product;
  onAdd?: (p: Product) => void;
  compact?: boolean;
}) {
  const src = product.imageUrl || fallback[product.category] || fallback.coffee;
  return (
    <Card className="overflow-hidden transition-shadow hover:shadow-md">
      <div className="aspect-[4/3] overflow-hidden bg-secondary">
        <img
          src={src}
          alt={product.name}
          className="h-full w-full object-cover transition-transform duration-300 hover:scale-105"
        />
      </div>
      <div className="space-y-2 p-4">
        <div className="flex items-start justify-between gap-2">
          <div>
            <h3 className="font-medium leading-tight">{product.name}</h3>
            <p className="text-xs capitalize text-muted-foreground">{product.category}</p>
          </div>
          <p className="font-medium tabular-nums">{money(product.price)}</p>
        </div>
        {!compact && <p className="line-clamp-2 text-sm text-muted-foreground">{product.description}</p>}
        {onAdd && (
          <Button className="w-full" size="sm" onClick={() => onAdd(product)}>
            Add to order
          </Button>
        )}
      </div>
    </Card>
  );
}
