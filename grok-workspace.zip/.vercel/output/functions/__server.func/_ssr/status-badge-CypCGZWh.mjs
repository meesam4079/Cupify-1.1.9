import { t as cva } from "../_libs/class-variance-authority+clsx.mjs";
import { t as cn } from "./utils-C_uf36nf.mjs";
import { p as require_jsx_runtime } from "../_libs/@radix-ui/react-checkbox+[...].mjs";
import { p as statusLabel } from "./format-ydPugZ1g.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/status-badge-CypCGZWh.js
var import_jsx_runtime = require_jsx_runtime();
var badgeVariants = cva("inline-flex items-center rounded-full border px-2.5 py-0.5 text-xs font-medium", {
	variants: { variant: {
		default: "border-transparent bg-primary text-primary-foreground",
		secondary: "border-transparent bg-secondary text-secondary-foreground",
		outline: "text-foreground",
		accent: "border-transparent bg-accent text-accent-foreground",
		destructive: "border-transparent bg-destructive text-destructive-foreground"
	} },
	defaultVariants: { variant: "default" }
});
function Badge({ className, variant, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: cn(badgeVariants({ variant }), className),
		...props
	});
}
var tone = {
	received: "secondary",
	designing: "outline",
	printing: "default",
	ready: "accent",
	delivered: "default",
	cancelled: "destructive",
	cancel_requested: "destructive"
};
function StatusBadge({ status }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
		variant: tone[status],
		children: statusLabel(status)
	});
}
//#endregion
export { StatusBadge as n, Badge as t };
