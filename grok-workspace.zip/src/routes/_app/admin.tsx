import { createFileRoute } from "@tanstack/react-router";
import { Protected } from "@/components/layout/protected";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { AdminDashboardTab } from "@/components/admin/admin-dashboard";
import { AdminOrdersTab } from "@/components/admin/admin-orders";
import { DateOrdersTab } from "@/components/staff/date-tab";
import { AdminProductsTab } from "@/components/admin/admin-products";
import { AdminStaffTab } from "@/components/admin/admin-staff";
import { AdminRefundsTab } from "@/components/admin/admin-refunds";
import { AdminReportsTab } from "@/components/admin/admin-reports";
import { AdminLogsTab } from "@/components/admin/admin-logs";
import { InquiryTab } from "@/components/staff/inquiry-tab";

export const Route = createFileRoute("/_app/admin")({ component: AdminRoute });

function AdminRoute() {
  return (
    <Protected roles={["admin"]}>
      <AdminPage />
    </Protected>
  );
}

function AdminPage() {
  return (
    <main className="mx-auto max-w-6xl px-4 py-8">
      <h1 className="font-display text-3xl font-semibold">Admin panel</h1>
      <p className="mt-1 text-sm text-muted-foreground">Manage your Cupify Cafe.</p>
      <Tabs defaultValue="dashboard" className="mt-6">
        <TabsList className="h-auto w-full flex-wrap justify-start overflow-x-auto">
          <TabsTrigger value="dashboard">Dashboard</TabsTrigger>
          <TabsTrigger value="orders">Orders</TabsTrigger>
          <TabsTrigger value="date">By date</TabsTrigger>
          <TabsTrigger value="products">Products</TabsTrigger>
          <TabsTrigger value="staff">Staff</TabsTrigger>
          <TabsTrigger value="refunds">Refunds</TabsTrigger>
          <TabsTrigger value="reports">Reports</TabsTrigger>
          <TabsTrigger value="logs">Logs</TabsTrigger>
          <TabsTrigger value="inquiry">Inquiry</TabsTrigger>
        </TabsList>
        <TabsContent value="dashboard">
          <AdminDashboardTab />
        </TabsContent>
        <TabsContent value="orders">
          <AdminOrdersTab />
        </TabsContent>
        <TabsContent value="date">
          <DateOrdersTab admin />
        </TabsContent>
        <TabsContent value="products">
          <AdminProductsTab />
        </TabsContent>
        <TabsContent value="staff">
          <AdminStaffTab />
        </TabsContent>
        <TabsContent value="refunds">
          <AdminRefundsTab />
        </TabsContent>
        <TabsContent value="reports">
          <AdminReportsTab />
        </TabsContent>
        <TabsContent value="logs">
          <AdminLogsTab />
        </TabsContent>
        <TabsContent value="inquiry">
          <InquiryTab />
        </TabsContent>
      </Tabs>
    </main>
  );
}
