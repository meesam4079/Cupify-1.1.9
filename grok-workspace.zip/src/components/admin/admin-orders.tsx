import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useState } from "react";
import { toast } from "sonner";
import { assignStaff, bulkUpdateStatus, listStaff, listStaffOrders, lockOrder, updateOrderStatus } from "@/lib/cupify/api";
import { money, when } from "@/lib/cupify/format";
import type { OrderStatus } from "@/lib/cupify/types";
import { OrderDetailPanel } from "@/components/shared/order-detail-panel";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Checkbox } from "@/components/ui/checkbox";

const ALL: OrderStatus[] = ["received", "designing", "printing", "ready", "delivered", "cancelled", "cancel_requested"];

export function AdminOrdersTab() {
  const qc = useQueryClient();
  const orders = useQuery({ queryKey: ["staff-orders"], queryFn: () => listStaffOrders(), refetchInterval: 4000 });
  const staff = useQuery({ queryKey: ["staff"], queryFn: () => listStaff() });
  const [selected, setSelected] = useState<number | null>(null);
  const [checked, setChecked] = useState<number[]>([]);
  const [bulk, setBulk] = useState<OrderStatus>("received");

  const current = (orders.data ?? []).find((o) => o.id === selected);

  const bulkMut = useMutation({
    mutationFn: () => bulkUpdateStatus({ data: { ids: checked, status: bulk } }),
    onSuccess() {
      setChecked([]);
      void qc.invalidateQueries({ queryKey: ["staff-orders"] });
      toast.success("Updated");
    },
  });

  return (
    <div className="grid gap-4 lg:grid-cols-[1fr_340px]">
      <div className="overflow-x-auto">
        <div className="mb-3 flex flex-wrap items-center gap-2">
          <Button size="sm" variant="outline" onClick={() => setChecked((orders.data ?? []).map((o) => o.id))}>
            Select all
          </Button>
          <Select value={bulk} onValueChange={(v) => setBulk(v as OrderStatus)}>
            <SelectTrigger className="w-40">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              {ALL.map((s) => (
                <SelectItem key={s} value={s}>
                  {s}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
          <Button size="sm" disabled={!checked.length || bulkMut.isPending} onClick={() => bulkMut.mutate()}>
            Apply
          </Button>
        </div>
        <table className="w-full min-w-[720px] text-left text-sm">
          <thead>
            <tr className="border-b text-muted-foreground">
              <th className="py-2" />
              <th>Order</th>
              <th>Customer</th>
              <th>Items</th>
              <th>Total</th>
              <th>Status</th>
              <th>Staff</th>
              <th>Date</th>
            </tr>
          </thead>
          <tbody>
            {(orders.data ?? []).map((o) => (
              <tr
                key={o.id}
                className="cursor-pointer border-b border-border/60 hover:bg-secondary/40"
                onClick={() => {
                  setSelected(o.id);
                  void lockOrder({ data: { id: o.id } });
                }}
              >
                <td className="py-2" onClick={(e) => e.stopPropagation()}>
                  <Checkbox
                    checked={checked.includes(o.id)}
                    onCheckedChange={(v) => setChecked((c) => (v === true ? [...c, o.id] : c.filter((id) => id !== o.id)))}
                  />
                </td>
                <td className="py-2 font-medium">
                  {o.orderNumber} {o.isVip && <Badge variant="accent">VIP</Badge>}
                  {o.status === "cancel_requested" && <Badge variant="destructive">Cancel</Badge>}
                </td>
                <td>{o.customerName}</td>
                <td className="max-w-[140px] truncate">{o.items.map((i) => i.productName).join(", ")}</td>
                <td className="tabular-nums">{money(o.total)}</td>
                <td onClick={(e) => e.stopPropagation()}>
                  <Select
                    value={o.status}
                    onValueChange={(v) =>
                      updateOrderStatus({ data: { id: o.id, status: v as OrderStatus } }).then(() => qc.invalidateQueries({ queryKey: ["staff-orders"] }))
                    }
                  >
                    <SelectTrigger className="h-8 w-36">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {ALL.map((s) => (
                        <SelectItem key={s} value={s}>
                          {s}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </td>
                <td onClick={(e) => e.stopPropagation()}>
                  <Select
                    value={o.assignedStaffId ?? ""}
                    onValueChange={(v) => {
                      const s = (staff.data ?? []).find((x) => x.userId === v);
                      if (!s) return;
                      void assignStaff({ data: { orderId: o.id, staffId: s.userId, staffName: s.displayName } }).then(() =>
                        qc.invalidateQueries({ queryKey: ["staff-orders"] }),
                      );
                    }}
                  >
                    <SelectTrigger className="h-8 w-36">
                      <SelectValue placeholder="Assign" />
                    </SelectTrigger>
                    <SelectContent>
                      {(staff.data ?? []).map((s) => (
                        <SelectItem key={s.userId} value={s.userId}>
                          {s.displayName || s.email}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </td>
                <td className="whitespace-nowrap text-xs text-muted-foreground">{when(o.createdAt)}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      <div className="rounded-xl border border-border bg-card p-4">
        {current ? <OrderDetailPanel order={current} /> : <p className="py-10 text-center text-sm text-muted-foreground">Select a row</p>}
      </div>
    </div>
  );
}
