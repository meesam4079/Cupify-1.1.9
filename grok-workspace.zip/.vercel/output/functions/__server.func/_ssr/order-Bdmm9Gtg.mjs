import { o as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { p as require_jsx_runtime } from "../_libs/@radix-ui/react-checkbox+[...].mjs";
import { t as Button } from "./button-D_PHfu3x.mjs";
import { a as CardTitle, i as CardHeader, n as CardContent, t as Card } from "./card-BqLLulKB.mjs";
import { a as Trash2, c as Plus, u as Minus } from "../_libs/lucide-react.mjs";
import { t as useCurrentUser } from "./use-current-user-DG6UNzh9.mjs";
import { l as lineTotal, u as money } from "./format-ydPugZ1g.mjs";
import { u as listAvailableProducts, v as placeOrder } from "./api-DUpluZ3_.mjs";
import { n as useQuery, t as useMutation } from "../_libs/tanstack__react-query.mjs";
import { a as DialogTitle, i as DialogHeader, n as DialogContent, o as InvoiceModal, r as DialogDescription, t as Dialog } from "./invoice-modal-DmA2m8xY.mjs";
import { t as Textarea } from "./textarea-flI-r2o4.mjs";
import { t as Input } from "./input-C8FVBVyT.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { t as Checkbox } from "./checkbox-CQmSRhXi.mjs";
import { t as Label } from "./label-2J_LU4QX.mjs";
import { n as useCart } from "./router-D-yFOGtu.mjs";
import { n as RadioGroupItem, t as RadioGroup } from "./radio-group-D_XWRx-p.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/order-Bdmm9Gtg.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function CartItemRow({ item, onQty, onRemove }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex items-start justify-between gap-3 border-b border-border/60 py-3 last:border-0",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "min-w-0",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "truncate font-medium",
					children: item.productName
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-xs text-muted-foreground",
					children: [
						item.cupType === "custom" ? `Custom · ${item.customCupName ?? "named cup"}` : "Standard",
						" · ",
						money(item.price),
						item.cupType === "custom" && item.customCupCharge ? ` + ${money(item.customCupCharge)}` : ""
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-2 flex items-center gap-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							size: "icon",
							variant: "outline",
							className: "h-8 w-8",
							onClick: () => onQty(item.quantity - 1),
							"aria-label": "Decrease",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Minus, { className: "h-3 w-3" })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "w-6 text-center text-sm tabular-nums",
							children: item.quantity
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							size: "icon",
							variant: "outline",
							className: "h-8 w-8",
							onClick: () => onQty(item.quantity + 1),
							"aria-label": "Increase",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "h-3 w-3" })
						})
					]
				})
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex flex-col items-end gap-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm font-medium tabular-nums",
				children: money(lineTotal(item))
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				size: "icon",
				variant: "ghost",
				className: "h-8 w-8",
				onClick: onRemove,
				"aria-label": "Remove",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "h-4 w-4" })
			})]
		})]
	});
}
function CustomCupForm({ product, onAdd, onClose }) {
	const [name, setName] = (0, import_react.useState)("");
	const [message, setMessage] = (0, import_react.useState)("");
	const [preview, setPreview] = (0, import_react.useState)();
	const [soon, setSoon] = (0, import_react.useState)(false);
	function onFile(file) {
		if (!file) return;
		const reader = new FileReader();
		reader.onload = () => setPreview(String(reader.result));
		reader.readAsDataURL(file);
		setSoon(true);
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-4 rounded-xl border border-border bg-card p-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-start justify-between",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h3", {
					className: "font-display text-lg font-semibold",
					children: ["Custom ", product.name]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-xs text-muted-foreground",
					children: ["Print charge ", money(product.customCupCharge)]
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "ghost",
					size: "sm",
					onClick: onClose,
					children: "Close"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-4 md:grid-cols-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "space-y-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-1.5",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
								htmlFor: "cup-name",
								children: "Name on cup"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								id: "cup-name",
								value: name,
								onChange: (e) => setName(e.target.value),
								required: true
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-1.5",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
								htmlFor: "cup-msg",
								children: "Message"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
								id: "cup-msg",
								value: message,
								onChange: (e) => setMessage(e.target.value)
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-1.5",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
								htmlFor: "cup-photo",
								children: "Photo"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								id: "cup-photo",
								type: "file",
								accept: "image/*",
								onChange: (e) => onFile(e.target.files?.[0])
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							className: "w-full",
							disabled: !name.trim(),
							onClick: () => onAdd({
								customCupName: name.trim(),
								customCupMessage: message.trim() || void 0,
								customCupImageUrl: preview
							}),
							children: "Add custom cup"
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "relative flex min-h-48 items-center justify-center overflow-hidden rounded-xl bg-primary text-primary-foreground",
					children: [preview ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
						src: preview,
						alt: "",
						className: "absolute inset-0 h-full w-full object-cover opacity-40"
					}) : null, /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "relative z-10 px-4 text-center",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-[10px] uppercase tracking-[0.25em] opacity-70",
								children: "Cupify"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-2 font-display text-2xl",
								children: name || "Your name"
							}),
							message ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-1 text-sm opacity-80",
								children: message
							}) : null
						]
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
				open: soon,
				onOpenChange: setSoon,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogContent, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogHeader, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, { children: "Cloud upload coming soon" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogDescription, { children: "Your photo is previewed locally and saved with the order. Hosted storage ships next." })] }) })
			})
		]
	});
}
function OrderPage() {
	const products = useQuery({
		queryKey: ["products-available"],
		queryFn: () => listAvailableProducts()
	});
	const cart = useCart();
	const user = useCurrentUser();
	const [step, setStep] = (0, import_react.useState)("cart");
	const [customFor, setCustomFor] = (0, import_react.useState)(null);
	const [name, setName] = (0, import_react.useState)(user?.displayName ?? "");
	const [email, setEmail] = (0, import_react.useState)(user?.primaryEmail ?? "");
	const [phone, setPhone] = (0, import_react.useState)("");
	const [pay, setPay] = (0, import_react.useState)("cash");
	const [own, setOwn] = (0, import_react.useState)(false);
	const [mkt, setMkt] = (0, import_react.useState)(false);
	const [placed, setPlaced] = (0, import_react.useState)(null);
	const [invoice, setInvoice] = (0, import_react.useState)(false);
	const place = useMutation({
		mutationFn: () => placeOrder({ data: {
			customerName: name,
			customerEmail: email,
			customerPhone: phone,
			items: cart.items,
			paymentMethod: pay,
			consentOwnImage: own,
			consentMarketing: mkt
		} }),
		onSuccess(order) {
			setPlaced(order);
			cart.clear();
			setStep("done");
			setInvoice(true);
			toast.success("Order placed");
		},
		onError(err) {
			toast.error(err instanceof Error ? err.message : "Could not place order");
		}
	});
	const hasCustom = cart.items.some((i) => i.cupType === "custom");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "mx-auto max-w-6xl px-4 py-10",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "font-display text-3xl font-semibold",
				children: "Order"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 text-sm text-muted-foreground",
				children: "Cart → details → invoice. 30% advance, balance at pickup."
			}),
			step === "cart" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-6 grid gap-6 lg:grid-cols-[1fr_360px]",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "space-y-4",
					children: [customFor && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CustomCupForm, {
						product: customFor,
						onClose: () => setCustomFor(null),
						onAdd: (extra) => {
							cart.addCustom(customFor, extra);
							toast.success(`${customFor.name} added to cart`);
							setCustomFor(null);
						}
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "grid gap-3 sm:grid-cols-2",
						children: (products.data ?? []).map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardHeader, {
							className: "p-4 pb-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardTitle, {
								className: "text-base",
								children: p.name
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-sm text-muted-foreground",
								children: money(p.price)
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardContent, {
							className: "flex gap-2 p-4 pt-0",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								size: "sm",
								className: "flex-1",
								onClick: () => {
									cart.addStandard(p);
									toast.success(`${p.name} added to cart`);
								},
								children: "Standard"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								size: "sm",
								variant: "outline",
								className: "flex-1",
								onClick: () => setCustomFor(p),
								children: "Custom"
							})]
						})] }, p.id))
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
					className: "h-fit",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardTitle, { children: "Cart" }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardContent, { children: cart.items.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-muted-foreground",
						children: "Empty — add a drink to begin."
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
						cart.items.map((i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CartItemRow, {
							item: i,
							onQty: (n) => cart.updateQuantity(i.cartId, n),
							onRemove: () => cart.remove(i.cartId)
						}, i.cartId)),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-4 space-y-1 text-sm",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex justify-between",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Subtotal" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "tabular-nums",
										children: money(cart.totals.subtotal)
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex justify-between",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Custom charges" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "tabular-nums",
										children: money(cart.totals.customCharges)
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex justify-between font-medium",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Total" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "tabular-nums",
										children: money(cart.totals.total)
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex justify-between text-muted-foreground",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Advance (30%)" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "tabular-nums",
										children: money(cart.totals.advancePaid)
									})]
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							className: "mt-4 w-full",
							onClick: () => setStep("details"),
							children: "Continue to details"
						})
					] }) })]
				})]
			}),
			step === "details" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
				className: "mx-auto mt-6 max-w-lg",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardTitle, { children: "Your details" }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardContent, {
					className: "space-y-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-1.5",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
								htmlFor: "n",
								children: "Name"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								id: "n",
								value: name,
								onChange: (e) => setName(e.target.value),
								required: true
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-1.5",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
								htmlFor: "e",
								children: "Email"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								id: "e",
								type: "email",
								value: email,
								onChange: (e) => setEmail(e.target.value)
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-1.5",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
								htmlFor: "p",
								children: "Phone"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								id: "p",
								value: phone,
								onChange: (e) => setPhone(e.target.value)
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Payment" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RadioGroup, {
								value: pay,
								onValueChange: (v) => setPay(v),
								children: [
									"cash",
									"card",
									"online"
								].map((m) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
									className: "flex items-center gap-2 text-sm capitalize",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RadioGroupItem, { value: m }),
										" ",
										m === "online" ? "Online transfer" : m
									]
								}, m))
							})]
						}),
						hasCustom && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "flex items-start gap-2 text-sm",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Checkbox, {
									checked: own,
									onCheckedChange: (v) => setOwn(v === true)
								}), "I own the image rights"]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "flex items-start gap-2 text-sm",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Checkbox, {
									checked: mkt,
									onCheckedChange: (v) => setMkt(v === true)
								}), "Allow marketing usage"]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "rounded-lg bg-secondary p-3 text-sm",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex justify-between",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Total" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "tabular-nums",
										children: money(cart.totals.total)
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex justify-between text-muted-foreground",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Advance now" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "tabular-nums",
										children: money(cart.totals.advancePaid)
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex justify-between text-muted-foreground",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Balance at pickup" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "tabular-nums",
										children: money(cart.totals.balanceDue)
									})]
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								variant: "outline",
								className: "flex-1",
								onClick: () => setStep("cart"),
								children: "Back"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								className: "flex-1",
								disabled: place.isPending || !name.trim() || hasCustom && !own,
								onClick: () => place.mutate(),
								children: place.isPending ? "Placing…" : "Place order"
							})]
						})
					]
				})]
			}),
			step === "done" && placed && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-auto mt-10 max-w-md space-y-4 text-center",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-display text-3xl font-semibold",
						children: "Order placed"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-muted-foreground",
						children: [placed.orderNumber, " is on the board. We’ll have it when the timeline says ready."]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex justify-center gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							onClick: () => setInvoice(true),
							children: "View invoice"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "outline",
							onClick: () => {
								setPlaced(null);
								setStep("cart");
							},
							children: "New order"
						})]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(InvoiceModal, {
				order: placed,
				open: invoice,
				onOpenChange: setInvoice
			})
		]
	});
}
//#endregion
export { OrderPage as component };
