import { createFileRoute, Outlet } from "@tanstack/react-router";
import { Navbar } from "@/components/layout/navbar";
import { Protected } from "@/components/layout/protected";

export const Route = createFileRoute("/_app")({
  component: AppLayout,
});

function AppLayout() {
  return (
    <Protected>
      <div className="flex min-h-screen flex-col paper-grain">
        <Navbar />
        <div className="flex-1">
          <Outlet />
        </div>
      </div>
    </Protected>
  );
}
