create table if not exists profiles (
  user_id text primary key,
  email text not null default '',
  display_name text not null default '',
  role text not null default 'user',
  is_active boolean not null default true,
  created_at timestamptz not null default now()
);
create index if not exists profiles_role_idx on profiles (role);

create table if not exists staff_invites (
  id serial primary key,
  email text not null,
  role text not null default 'staff',
  created_at timestamptz not null default now()
);
create unique index if not exists staff_invites_email_idx on staff_invites (lower(email));

create table if not exists products (
  id serial primary key,
  name text not null,
  category text not null,
  price double precision not null,
  description text not null default '',
  image_url text not null default '',
  is_available boolean not null default true,
  custom_cup_charge double precision not null default 80
);

create table if not exists orders (
  id serial primary key,
  user_id text,
  order_number text not null unique,
  customer_name text not null,
  customer_email text not null default '',
  customer_phone text not null default '',
  items jsonb not null default '[]'::jsonb,
  subtotal double precision not null default 0,
  custom_charges double precision not null default 0,
  total double precision not null default 0,
  advance_paid double precision not null default 0,
  balance_due double precision not null default 0,
  is_vip boolean not null default false,
  walk_in boolean not null default false,
  status text not null default 'received',
  consent_own_image boolean not null default false,
  consent_marketing boolean not null default false,
  assigned_staff_id text,
  assigned_staff_name text,
  payment_method text not null default 'cash',
  notes text not null default '',
  locked_by_staff_id text,
  locked_by_staff_name text,
  locked_at timestamptz,
  previous_status text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index if not exists orders_status_idx on orders (status);
create index if not exists orders_user_id_idx on orders (user_id);
create index if not exists orders_created_at_idx on orders (created_at desc);

create table if not exists refund_requests (
  id serial primary key,
  order_id integer not null references orders(id) on delete cascade,
  order_number text not null,
  customer_name text not null,
  request_type text not null,
  reason text not null default '',
  status text not null default 'pending',
  requested_by_id text not null default '',
  requested_by_name text not null default '',
  reviewed_by_id text,
  reviewed_by_name text,
  admin_note text not null default '',
  amount double precision not null default 0,
  created_at timestamptz not null default now()
);

create table if not exists remarks (
  id serial primary key,
  order_id integer not null references orders(id) on delete cascade,
  order_number text not null,
  customer_name text not null,
  staff_id text not null,
  staff_name text not null,
  content text not null,
  created_at timestamptz not null default now()
);

create table if not exists activity_logs (
  id serial primary key,
  user_name text not null,
  user_role text not null,
  action text not null,
  entity_type text not null,
  entity_id text not null default '',
  created_at timestamptz not null default now()
);
create index if not exists activity_logs_created_at_idx on activity_logs (created_at desc);

create table if not exists counters (
  name text primary key,
  value integer not null default 0
);

insert into counters (name, value) values ('cup', 0), ('vip', 0)
on conflict (name) do nothing;

insert into products (name, category, price, description, image_url, custom_cup_charge)
select * from (values
  ('Espresso', 'coffee', 250::float8, 'A concentrated shot with a golden crema.', 'https://images.unsplash.com/photo-1510591509098-f4fdc6d0ff04?w=800&q=80', 80::float8),
  ('Americano', 'coffee', 320, 'Espresso stretched with hot water — clean and bold.', 'https://images.unsplash.com/photo-1514432324607-a09d9b4aefdd?w=800&q=80', 80),
  ('Cappuccino', 'coffee', 420, 'Equal parts espresso, steamed milk, and foam.', 'https://images.unsplash.com/photo-1572442388796-11668a67e53d?w=800&q=80', 90),
  ('Cafe Latte', 'coffee', 450, 'Silky steamed milk over a double espresso.', 'https://images.unsplash.com/photo-1561882468-9110e03e0f78?w=800&q=80', 90),
  ('Mocha', 'coffee', 480, 'Espresso, dark chocolate, and steamed milk.', 'https://images.unsplash.com/photo-1578374173703-0e68d0d6c1d0?w=800&q=80', 90),
  ('Cold Brew', 'coffee', 430, 'Steeped overnight, served over ice.', 'https://images.unsplash.com/photo-1461023058943-07fcbe16d735?w=800&q=80', 80),
  ('Masala Chai', 'tea', 280, 'Black tea simmered with cardamom, ginger, and clove.', 'https://images.unsplash.com/photo-1571934811356-5cc061b6821f?w=800&q=80', 70),
  ('Green Tea', 'tea', 260, 'Light, grassy, and calming.', 'https://images.unsplash.com/photo-1627435601361-ec25f5b1d0e0?w=800&q=80', 70),
  ('Earl Grey', 'tea', 270, 'Bergamot-scented black tea, served with lemon.', 'https://images.unsplash.com/photo-1594631252845-29fc4cc8cde9?w=800&q=80', 70),
  ('Kashmiri Kahwa', 'tea', 340, 'Saffron, almonds, and green tea — a mountain classic.', 'https://images.unsplash.com/photo-1564890369478-c89ca6d9cde9?w=800&q=80', 80),
  ('Mango Cooler', 'juice', 380, 'Alphonso mango, crushed ice, a squeeze of lime.', 'https://images.unsplash.com/photo-1546173159-315724a31696?w=800&q=80', 80),
  ('Fresh Orange', 'juice', 320, 'Pressed to order, no concentrate.', 'https://images.unsplash.com/photo-1600271886742-f049cd451bba?w=800&q=80', 70),
  ('Berry Blend', 'juice', 360, 'Strawberry, blueberry, and a hint of mint.', 'https://images.unsplash.com/photo-1505252585461-04c1f96a3268?w=800&q=80', 80),
  ('Watermelon Mint', 'juice', 300, 'Chilled watermelon with garden mint.', 'https://images.unsplash.com/photo-1568909344668-6f14a07b56a0?w=800&q=80', 70)
) as v(name, category, price, description, image_url, custom_cup_charge)
where not exists (select 1 from products limit 1);
