import { createFileRoute, Link } from "@tanstack/react-router";
import { Button } from "@/components/ui/button";
import { CupifyWordmark } from "@/components/brand/logo";

export const Route = createFileRoute("/$")({ component: NotFound });

function NotFound() {
  return (
    <main className="grid min-h-screen place-items-center bg-background px-6 paper-grain">
      <div className="space-y-4 text-center">
        <CupifyWordmark className="justify-center" />
        <h1 className="font-display text-3xl font-semibold">Page not found</h1>
        <p className="text-sm text-muted-foreground">That table doesn’t exist. Let’s get you back to the cafe.</p>
        <Button asChild>
          <Link to="/">Home</Link>
        </Button>
      </div>
    </main>
  );
}
