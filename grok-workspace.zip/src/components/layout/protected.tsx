import type { ReactNode } from "react";
import { Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { RedirectToSignIn } from "@/lib/auth/gates";
import { useCurrentUserState } from "@/lib/auth/use-current-user";
import { signOut } from "@/lib/auth/client";
import { getMyProfile } from "@/lib/cupify/api";
import type { UserRole } from "@/lib/cupify/types";
import { Button } from "@/components/ui/button";
import { CupifyWordmark } from "@/components/brand/logo";

type ProtectedProps = {
  children: ReactNode;
  roles?: UserRole[];
};

function CafeFrame({ children }: { children: ReactNode }) {
  return (
    <div className="flex min-h-screen flex-col items-center justify-center gap-4 bg-background px-6 text-center paper-grain">
      <CupifyWordmark />
      {children}
    </div>
  );
}

export function Protected({ children, roles }: ProtectedProps) {
  const { user, isPending } = useCurrentUserState();
  const profile = useQuery({
    queryKey: ["me"],
    queryFn: () => getMyProfile(),
    enabled: Boolean(user),
    retry: 1,
  });

  if (isPending) {
    return (
      <CafeFrame>
        <p className="text-sm text-muted-foreground">Loading the cafe…</p>
      </CafeFrame>
    );
  }

  if (!user) {
    return <RedirectToSignIn />;
  }

  if (profile.isPending) {
    return (
      <CafeFrame>
        <p className="text-sm text-muted-foreground">Setting your table…</p>
      </CafeFrame>
    );
  }

  if (profile.isError || !profile.data) {
    return (
      <CafeFrame>
        <h1 className="font-display text-2xl font-semibold">Couldn’t load your profile</h1>
        <p className="max-w-sm text-sm text-muted-foreground">
          {profile.error instanceof Error ? profile.error.message : "Please try again in a moment."}
        </p>
        <Button onClick={() => void profile.refetch()}>Retry</Button>
      </CafeFrame>
    );
  }

  if (!profile.data.isActive) {
    return (
      <CafeFrame>
        <h1 className="font-display text-2xl font-semibold">Account deactivated</h1>
        <p className="max-w-sm text-sm text-muted-foreground">
          This account is no longer active. Contact the cafe if you think that’s a mistake.
        </p>
        <Button variant="outline" onClick={() => void signOut("/login")}>
          Sign out
        </Button>
      </CafeFrame>
    );
  }

  if (roles && roles.length > 0 && !roles.includes(profile.data.role)) {
    return (
      <CafeFrame>
        <h1 className="font-display text-2xl font-semibold">Staff only</h1>
        <p className="max-w-sm text-sm text-muted-foreground">You don’t have access to this area of Cupify Cafe.</p>
        <Button asChild>
          <Link to="/">Back to home</Link>
        </Button>
      </CafeFrame>
    );
  }

  return <>{children}</>;
}
