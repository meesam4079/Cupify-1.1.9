import type { OrderItem, OrderStatus, ProductCategory } from "./types";
import { ADVANCE_RATE } from "./types";

export function money(n: number) {
  return `Rs ${Math.round(n).toLocaleString("en-PK")}`;
}

export function padOrder(prefix: string, n: number) {
  return `${prefix}-${String(n).padStart(6, "0")}`;
}

export function lineTotal(item: OrderItem) {
  const extra = item.cupType === "custom" ? item.customCupCharge ?? 0 : 0;
  return (item.price + extra) * item.quantity;
}

export function cartTotals(items: OrderItem[]) {
  let subtotal = 0;
  let customCharges = 0;
  for (const it of items) {
    subtotal += it.price * it.quantity;
    if (it.cupType === "custom") customCharges += (it.customCupCharge ?? 0) * it.quantity;
  }
  const total = subtotal + customCharges;
  const advancePaid = Math.round(total * ADVANCE_RATE);
  return { subtotal, customCharges, total, advancePaid, balanceDue: total - advancePaid };
}

export function statusLabel(s: OrderStatus) {
  const map: Record<OrderStatus, string> = {
    received: "Received",
    designing: "Designing",
    printing: "Printing",
    ready: "Ready",
    delivered: "Delivered",
    cancelled: "Cancelled",
    cancel_requested: "Cancel requested",
  };
  return map[s] ?? s;
}

export function categoryLabel(c: ProductCategory) {
  return c.charAt(0).toUpperCase() + c.slice(1);
}

export function when(iso: string) {
  const d = new Date(iso);
  if (!Number.isFinite(d.getTime())) return iso;
  return d.toLocaleString(undefined, { dateStyle: "medium", timeStyle: "short" });
}

export function dayKey(iso: string) {
  return iso.slice(0, 10);
}

export function dayLabel(key: string) {
  const today = new Date().toISOString().slice(0, 10);
  const y = new Date();
  y.setDate(y.getDate() - 1);
  const yesterday = y.toISOString().slice(0, 10);
  if (key === today) return "Today";
  if (key === yesterday) return "Yesterday";
  return new Date(key + "T00:00:00").toLocaleDateString(undefined, {
    weekday: "short",
    month: "short",
    day: "numeric",
    year: "numeric",
  });
}

export const TIMELINE: OrderStatus[] = ["received", "designing", "printing", "ready", "delivered"];

export function nextStatuses(current: OrderStatus): OrderStatus[] {
  if (current === "cancelled" || current === "delivered") return [current];
  if (current === "cancel_requested") return ["cancel_requested"];
  if (current === "received") return ["received", "designing", "cancelled"];
  if (current === "designing") return ["designing", "printing", "cancel_requested"];
  if (current === "printing") return ["printing", "ready", "delivered", "cancelled", "cancel_requested"];
  if (current === "ready") return ["ready", "delivered", "cancel_requested"];
  return [current];
}
