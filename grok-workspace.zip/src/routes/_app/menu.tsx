import { createFileRoute } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { useState } from "react";
import { toast } from "sonner";
import { listAvailableProducts } from "@/lib/cupify/api";
import { useCart } from "@/lib/cupify/cart-context";
import { MenuCard } from "@/components/menu/menu-card";
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Skeleton } from "@/components/ui/skeleton";
import type { Product, ProductCategory } from "@/lib/cupify/types";

export const Route = createFileRoute("/_app/menu")({ component: MenuPage });

function MenuPage() {
  const { data, isPending } = useQuery({ queryKey: ["products-available"], queryFn: () => listAvailableProducts() });
  const { addStandard } = useCart();
  const [cat, setCat] = useState<"all" | ProductCategory>("all");
  const products = (data ?? []).filter((p) => cat === "all" || p.category === cat);

  function add(p: Product) {
    addStandard(p);
    toast.success(`${p.name} added to cart`);
  }

  return (
    <main className="mx-auto max-w-6xl px-4 py-10">
      <h1 className="font-display text-3xl font-semibold">Menu</h1>
      <p className="mt-1 text-sm text-muted-foreground">Coffee, tea, juice — add a standard cup or custom-print on Order.</p>
      <Tabs value={cat} onValueChange={(v) => setCat(v as typeof cat)} className="mt-6">
        <TabsList>
          <TabsTrigger value="all">All</TabsTrigger>
          <TabsTrigger value="coffee">Coffee</TabsTrigger>
          <TabsTrigger value="tea">Tea</TabsTrigger>
          <TabsTrigger value="juice">Juice</TabsTrigger>
        </TabsList>
      </Tabs>
      {isPending ? (
        <div className="mt-6 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          {Array.from({ length: 8 }).map((_, i) => (
            <Skeleton key={i} className="h-64" />
          ))}
        </div>
      ) : products.length === 0 ? (
        <p className="mt-10 text-sm text-muted-foreground">Nothing on the board in this category yet.</p>
      ) : (
        <div className="mt-6 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          {products.map((p) => (
            <MenuCard key={p.id} product={p} onAdd={add} />
          ))}
        </div>
      )}
    </main>
  );
}
