import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useState } from "react";
import { toast } from "sonner";
import { deleteProduct, listProducts, saveProduct } from "@/lib/cupify/api";
import { money } from "@/lib/cupify/format";
import type { Product, ProductCategory } from "@/lib/cupify/types";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

export function AdminProductsTab() {
  const qc = useQueryClient();
  const products = useQuery({ queryKey: ["products-all"], queryFn: () => listProducts() });
  const [edit, setEdit] = useState<Partial<Product> | null>(null);

  const save = useMutation({
    mutationFn: () =>
      saveProduct({
        data: {
          id: edit?.id,
          name: edit?.name ?? "",
          category: (edit?.category ?? "coffee") as ProductCategory,
          price: Number(edit?.price ?? 0),
          description: edit?.description ?? "",
          imageUrl: edit?.imageUrl ?? "",
          isAvailable: edit?.isAvailable !== false,
          customCupCharge: Number(edit?.customCupCharge ?? 0),
        },
      }),
    onSuccess() {
      setEdit(null);
      void qc.invalidateQueries({ queryKey: ["products-all"] });
      void qc.invalidateQueries({ queryKey: ["products-available"] });
      toast.success("Saved");
    },
  });
  const del = useMutation({
    mutationFn: (id: number) => deleteProduct({ data: { id } }),
    onSuccess() {
      void qc.invalidateQueries({ queryKey: ["products-all"] });
      toast.success("Deleted");
    },
  });

  return (
    <div>
      <Button className="mb-4" onClick={() => setEdit({ name: "", category: "coffee", price: 0, customCupCharge: 80, isAvailable: true, description: "", imageUrl: "" })}>
        Add product
      </Button>
      <div className="overflow-x-auto">
        <table className="w-full text-left text-sm">
          <thead>
            <tr className="border-b text-muted-foreground">
              <th className="py-2">Name</th>
              <th>Category</th>
              <th>Price</th>
              <th>Custom</th>
              <th>Available</th>
              <th />
            </tr>
          </thead>
          <tbody>
            {(products.data ?? []).map((p) => (
              <tr key={p.id} className="border-b border-border/60">
                <td className="py-2">{p.name}</td>
                <td className="capitalize">{p.category}</td>
                <td className="tabular-nums">{money(p.price)}</td>
                <td className="tabular-nums">{money(p.customCupCharge)}</td>
                <td>{p.isAvailable ? "Yes" : "No"}</td>
                <td className="space-x-2">
                  <Button size="sm" variant="outline" onClick={() => setEdit(p)}>
                    Edit
                  </Button>
                  <Button size="sm" variant="destructive" onClick={() => del.mutate(p.id)}>
                    Delete
                  </Button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      <Dialog open={Boolean(edit)} onOpenChange={(o) => !o && setEdit(null)}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>{edit?.id ? "Edit product" : "New product"}</DialogTitle>
          </DialogHeader>
          {edit && (
            <div className="space-y-3">
              <div className="space-y-1.5">
                <Label>Name</Label>
                <Input value={edit.name ?? ""} onChange={(e) => setEdit({ ...edit, name: e.target.value })} />
              </div>
              <div className="space-y-1.5">
                <Label>Category</Label>
                <Select value={edit.category} onValueChange={(v) => setEdit({ ...edit, category: v as ProductCategory })}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="coffee">Coffee</SelectItem>
                    <SelectItem value="tea">Tea</SelectItem>
                    <SelectItem value="juice">Juice</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-1.5">
                <Label>Price</Label>
                <Input type="number" value={edit.price ?? 0} onChange={(e) => setEdit({ ...edit, price: Number(e.target.value) })} />
              </div>
              <div className="space-y-1.5">
                <Label>Custom cup charge</Label>
                <Input type="number" value={edit.customCupCharge ?? 0} onChange={(e) => setEdit({ ...edit, customCupCharge: Number(e.target.value) })} />
              </div>
              <div className="space-y-1.5">
                <Label>Description</Label>
                <Input value={edit.description ?? ""} onChange={(e) => setEdit({ ...edit, description: e.target.value })} />
              </div>
              <label className="flex items-center gap-2 text-sm">
                <Switch checked={edit.isAvailable !== false} onCheckedChange={(v) => setEdit({ ...edit, isAvailable: v })} />
                Available
              </label>
              <Button className="w-full" disabled={save.isPending} onClick={() => save.mutate()}>
                Save
              </Button>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}
