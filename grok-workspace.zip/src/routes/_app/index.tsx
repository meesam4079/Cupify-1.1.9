import { createFileRoute, Link } from "@tanstack/react-router";
import { Coffee, CupSoda, Share2, Crown } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";

export const Route = createFileRoute("/_app/")({ component: HomePage });

function HomePage() {
  return (
    <main>
      <section className="mx-auto grid max-w-6xl gap-10 px-4 py-16 md:grid-cols-2 md:items-center md:py-24">
        <div className="animate-rise space-y-5">
          <p className="text-xs font-medium uppercase tracking-[0.2em] text-accent">Sip your story</p>
          <h1 className="font-display text-4xl font-semibold leading-[1.1] md:text-6xl">Cupify Cafe</h1>
          <p className="max-w-md text-muted-foreground">
            Specialty drinks, cups printed with your name and moment, and a staff floor that actually keeps up.
          </p>
          <div className="flex flex-wrap gap-3">
            <Button asChild size="lg">
              <Link to="/menu">Explore menu</Link>
            </Button>
            <Button asChild size="lg" variant="outline">
              <Link to="/order">Custom cup</Link>
            </Button>
          </div>
        </div>
        <div className="animate-rise-2 relative overflow-hidden rounded-2xl border border-border/70 bg-card p-8 shadow-sm">
          <div className="absolute -right-8 -top-8 h-40 w-40 rounded-full bg-accent/15" />
          <p className="font-display text-2xl">A cup with your name on it.</p>
          <p className="mt-2 max-w-sm text-sm text-muted-foreground">
            Order a latte, add a photo and a line, pick it up when the board says ready.
          </p>
          <div className="mt-8 grid grid-cols-3 gap-3 text-center">
            {["Received", "Printing", "Ready"].map((s) => (
              <div key={s} className="rounded-lg bg-secondary px-2 py-4 text-xs font-medium">
                {s}
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="mx-auto grid max-w-6xl gap-4 px-4 pb-16 sm:grid-cols-3">
        {[
          { icon: Coffee, title: "Premium drinks", body: "Espresso, chai, and juice — pulled or pressed to order." },
          { icon: CupSoda, title: "Custom cups", body: "Name, message, and a photo printed on the sleeve." },
          { icon: Share2, title: "Share moments", body: "Walk out with something worth posting — and a receipt that matches." },
        ].map((f, i) => (
          <Card key={f.title} className={i === 1 ? "animate-rise-2" : "animate-rise"}>
            <CardHeader>
              <f.icon className="h-5 w-5 text-accent" />
              <CardTitle className="text-lg">{f.title}</CardTitle>
              <CardDescription>{f.body}</CardDescription>
            </CardHeader>
          </Card>
        ))}
      </section>

      <section className="mx-auto max-w-6xl px-4 pb-20">
        <Card className="overflow-hidden border-0 bg-primary text-primary-foreground">
          <CardContent className="flex flex-col items-start gap-4 p-8 md:flex-row md:items-center md:justify-between">
            <div>
              <div className="mb-2 flex items-center gap-2 text-accent">
                <Crown className="h-4 w-4" />
                <span className="text-xs font-medium uppercase tracking-widest">VIP desk</span>
              </div>
              <h2 className="font-display text-2xl font-semibold">Skip the queue. Pay in full. Leave with the cup.</h2>
              <p className="mt-1 max-w-xl text-sm text-primary-foreground/75">Priority board, premium presentation, no balance at pickup.</p>
            </div>
            <Button asChild variant="secondary" size="lg">
              <Link to="/vip">Join VIP</Link>
            </Button>
          </CardContent>
        </Card>
      </section>

      <footer className="border-t border-border/60 py-8 text-center text-sm text-muted-foreground">
        © 2026 Cupify Cafe — Sip Your Story. #CupifyMoments
      </footer>
    </main>
  );
}
