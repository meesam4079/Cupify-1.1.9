import { useQuery } from "@tanstack/react-query";
import { dashboardStats } from "@/lib/cupify/api";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";

export function StaffDashboard() {
  const q = useQuery({ queryKey: ["dash"], queryFn: () => dashboardStats(), refetchInterval: 5000 });
  if (q.isPending) return <Skeleton className="mt-4 h-40" />;
  const d = q.data;
  if (!d) return null;
  const cards = [
    ["New orders", d.byStatus.received ?? 0],
    ["In progress", (d.byStatus.designing ?? 0) + (d.byStatus.printing ?? 0)],
    ["Ready", d.byStatus.ready ?? 0],
    ["Delivered", d.byStatus.delivered ?? 0],
    ["Refund requests", d.pendingRefunds],
    ["Cancel requests", d.byStatus.cancel_requested ?? 0],
    ["Remarks today", d.remarksToday],
    ["Total active", (d.byStatus.received ?? 0) + (d.byStatus.designing ?? 0) + (d.byStatus.printing ?? 0) + (d.byStatus.ready ?? 0)],
  ] as const;
  return (
    <div className="space-y-4">
      <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
        {cards.map(([label, n]) => (
          <Card key={label}>
            <CardHeader className="pb-2">
              <p className="text-xs uppercase tracking-wide text-muted-foreground">{label}</p>
              <CardTitle className="text-2xl tabular-nums">{n}</CardTitle>
            </CardHeader>
          </Card>
        ))}
      </div>
      <Card>
        <CardHeader>
          <CardTitle className="text-base">Today</CardTitle>
        </CardHeader>
        <CardContent className="text-sm text-muted-foreground">
          {d.todayOrders} orders · {d.pendingRefunds} pending approvals · {d.remarksToday} remarks
        </CardContent>
      </Card>
    </div>
  );
}
