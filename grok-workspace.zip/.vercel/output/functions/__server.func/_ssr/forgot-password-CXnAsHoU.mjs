import { p as require_jsx_runtime } from "../_libs/@radix-ui/react-checkbox+[...].mjs";
import { t as Button } from "./button-D_PHfu3x.mjs";
import { t as CupifyWordmark } from "./logo-DhQH1Ggo.mjs";
import { v as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as CardTitle, i as CardHeader, n as CardContent, r as CardDescription, t as Card } from "./card-BqLLulKB.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/forgot-password-CXnAsHoU.js
var import_jsx_runtime = require_jsx_runtime();
function ForgotPage() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
		className: "grid min-h-screen place-items-center bg-background px-4 paper-grain",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
			className: "w-full max-w-md animate-rise",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardHeader, {
				className: "items-center text-center",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CupifyWordmark, {}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardTitle, {
						className: "pt-2",
						children: "Reset password"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardDescription, { children: "Password reset email isn’t enabled on this cafe yet. Sign in with Google or X, or create a new email account." })
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardContent, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				asChild: true,
				className: "w-full",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/login",
					children: "Back to sign in"
				})
			}) })]
		})
	});
}
//#endregion
export { ForgotPage as component };
