import { useMutation } from "@tanstack/react-query";
import { useState } from "react";
import { searchInvoices, listLogs, listRemarks } from "@/lib/cupify/api";
import { money, when } from "@/lib/cupify/format";
import type { ActivityLog, Order, Remark } from "@/lib/cupify/types";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { CupifyWordmark } from "@/components/brand/logo";

export function InquiryTab() {
  const [q, setQ] = useState("");
  const [order, setOrder] = useState<Order | null>(null);
  const [logs, setLogs] = useState<ActivityLog[]>([]);
  const [remarks, setRemarks] = useState<Remark[]>([]);

  const search = useMutation({
    mutationFn: () => searchInvoices({ data: { q } }),
  });

  async function pick(o: Order) {
    setOrder(o);
    const [l, r] = await Promise.all([listLogs(), listRemarks({ data: { orderId: o.id } })]);
    setLogs(l.filter((x) => x.entityId === String(o.id) || x.action.includes(o.orderNumber)));
    setRemarks(r);
  }

  return (
    <div className="space-y-4">
      <form
        className="flex gap-2"
        onSubmit={(e) => {
          e.preventDefault();
          search.mutate();
        }}
      >
        <Input placeholder="Phone, order #, name, email" value={q} onChange={(e) => setQ(e.target.value)} />
        <Button type="submit">Search</Button>
      </form>
      <div className="space-y-2">
        {(search.data ?? []).map((o) => (
          <button key={o.id} type="button" className="w-full rounded-md border border-border p-3 text-left text-sm" onClick={() => void pick(o)}>
            {o.orderNumber} · {o.customerName}
          </button>
        ))}
      </div>
      {order && (
        <Card className="inquiry-sheet">
          <CardHeader className="bg-primary text-primary-foreground">
            <CupifyWordmark className="text-primary-foreground" />
            <CardTitle className="text-primary-foreground">Inquiry · {order.orderNumber}</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4 pt-6 text-sm">
            <p>
              {order.customerName} · {order.customerPhone} · {order.customerEmail} · {order.paymentMethod}
            </p>
            <ul>
              {order.items.map((it, i) => (
                <li key={i}>
                  {it.quantity}× {it.productName}
                </li>
              ))}
            </ul>
            <p className="font-medium tabular-nums">{money(order.total)}</p>
            <div>
              <p className="mb-2 font-medium">Activity</p>
              {logs.map((l) => (
                <div key={l.id} className="flex items-start gap-2 border-l border-border py-1 pl-3">
                  <Badge variant="secondary">{l.userRole}</Badge>
                  <span>
                    {l.action} · {when(l.createdAt)}
                  </span>
                </div>
              ))}
            </div>
            <div>
              <p className="mb-2 font-medium">Remarks</p>
              {remarks.map((r) => (
                <p key={r.id} className="text-muted-foreground">
                  {r.staffName}: {r.content}
                </p>
              ))}
            </div>
            <Button className="no-print" onClick={() => window.print()}>
              Download inquiry PDF
            </Button>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
