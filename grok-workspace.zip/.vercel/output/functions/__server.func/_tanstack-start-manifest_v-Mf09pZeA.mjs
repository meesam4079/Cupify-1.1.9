//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-Mf09pZeA.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: [
			"/$",
			"/_app",
			"/forgot-password",
			"/login",
			"/register",
			"/api/auth/$"
		],
		preloads: [
			"/assets/index-CPmWvA3p.js",
			"/assets/react-SIfiwpqq.js",
			"/assets/invariant-DVltax7q.js"
		],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-CPmWvA3p.js"
		} }]
	},
	"/$": {
		filePath: "/workspace/src/routes/$.tsx",
		children: void 0,
		preloads: [
			"/assets/_-nU6Cm_4P.js",
			"/assets/button-CCJpNv3a.js",
			"/assets/logo-BqQJenso.js"
		]
	},
	"/_app": {
		filePath: "/workspace/src/routes/_app.tsx",
		children: [
			"/_app/about",
			"/_app/admin",
			"/_app/menu",
			"/_app/order",
			"/_app/staff",
			"/_app/track",
			"/_app/vip",
			"/_app/"
		],
		preloads: [
			"/assets/_app-C-G5xR9f.js",
			"/assets/api-DFxodfHY.js",
			"/assets/x-C24F43kv.js",
			"/assets/useQuery-BDVT49hG.js",
			"/assets/button-CCJpNv3a.js",
			"/assets/utils-DojpP95n.js",
			"/assets/logo-BqQJenso.js",
			"/assets/protected-DlsPDW_F.js",
			"/assets/use-current-user-C4dygdOb.js"
		]
	},
	"/forgot-password": {
		filePath: "/workspace/src/routes/forgot-password.tsx",
		children: void 0,
		preloads: [
			"/assets/forgot-password-BC8WNKdR.js",
			"/assets/button-CCJpNv3a.js",
			"/assets/logo-BqQJenso.js",
			"/assets/card-8Nmoemy5.js"
		]
	},
	"/login": {
		filePath: "/workspace/src/routes/login.tsx",
		children: void 0,
		preloads: [
			"/assets/login-C-fZGAoc.js",
			"/assets/client-C85fcJ4s.js",
			"/assets/separator-BlL43kil.js",
			"/assets/button-CCJpNv3a.js",
			"/assets/logo-BqQJenso.js",
			"/assets/use-current-user-C4dygdOb.js",
			"/assets/card-8Nmoemy5.js",
			"/assets/input-CT8n5iKV.js",
			"/assets/label-cb0gCIlh.js"
		]
	},
	"/register": {
		filePath: "/workspace/src/routes/register.tsx",
		children: void 0,
		preloads: [
			"/assets/register-LXHhqXfG.js",
			"/assets/client-C85fcJ4s.js",
			"/assets/separator-BlL43kil.js",
			"/assets/button-CCJpNv3a.js",
			"/assets/logo-BqQJenso.js",
			"/assets/use-current-user-C4dygdOb.js",
			"/assets/card-8Nmoemy5.js",
			"/assets/input-CT8n5iKV.js",
			"/assets/label-cb0gCIlh.js"
		]
	},
	"/_app/about": {
		filePath: "/workspace/src/routes/_app/about.tsx",
		children: void 0,
		preloads: ["/assets/about-D4xPdry5.js", "/assets/card-8Nmoemy5.js"]
	},
	"/_app/admin": {
		filePath: "/workspace/src/routes/_app/admin.tsx",
		children: void 0,
		preloads: [
			"/assets/admin-Cbi-ipT8.js",
			"/assets/invoice-modal-DAdM1VRm.js",
			"/assets/select-BC-u9zSf.js",
			"/assets/card-8Nmoemy5.js",
			"/assets/dist-pPAi5uEN.js",
			"/assets/dist-BqYkvy0n.js",
			"/assets/tabs-CZExYYpV.js",
			"/assets/status-badge-BpSLzOBl.js",
			"/assets/dist-BnDYiImT.js",
			"/assets/inquiry-tab-D6MuHIzf.js",
			"/assets/checkbox-D96-PN9D.js",
			"/assets/input-CT8n5iKV.js",
			"/assets/label-cb0gCIlh.js"
		]
	},
	"/_app/menu": {
		filePath: "/workspace/src/routes/_app/menu.tsx",
		children: void 0,
		preloads: [
			"/assets/menu-CU-skRA4.js",
			"/assets/card-8Nmoemy5.js",
			"/assets/tabs-CZExYYpV.js",
			"/assets/skeleton-CCKe3tbg.js"
		]
	},
	"/_app/order": {
		filePath: "/workspace/src/routes/_app/order.tsx",
		children: void 0,
		preloads: [
			"/assets/order-BscacnGH.js",
			"/assets/invoice-modal-DAdM1VRm.js",
			"/assets/radio-group-D7k1FnJM.js",
			"/assets/card-8Nmoemy5.js",
			"/assets/textarea-BRQv4wO1.js",
			"/assets/checkbox-D96-PN9D.js",
			"/assets/input-CT8n5iKV.js",
			"/assets/label-cb0gCIlh.js"
		]
	},
	"/_app/staff": {
		filePath: "/workspace/src/routes/_app/staff.tsx",
		children: void 0,
		preloads: [
			"/assets/staff-Cb_m6qjz.js",
			"/assets/invoice-modal-DAdM1VRm.js",
			"/assets/radio-group-D7k1FnJM.js",
			"/assets/card-8Nmoemy5.js",
			"/assets/tabs-CZExYYpV.js",
			"/assets/status-badge-BpSLzOBl.js",
			"/assets/textarea-BRQv4wO1.js",
			"/assets/inquiry-tab-D6MuHIzf.js",
			"/assets/input-CT8n5iKV.js",
			"/assets/label-cb0gCIlh.js",
			"/assets/skeleton-CCKe3tbg.js"
		]
	},
	"/_app/track": {
		filePath: "/workspace/src/routes/_app/track.tsx",
		children: void 0,
		preloads: [
			"/assets/track-dHmToMOX.js",
			"/assets/invoice-modal-DAdM1VRm.js",
			"/assets/card-8Nmoemy5.js",
			"/assets/tabs-CZExYYpV.js",
			"/assets/status-badge-BpSLzOBl.js",
			"/assets/input-CT8n5iKV.js"
		]
	},
	"/_app/vip": {
		filePath: "/workspace/src/routes/_app/vip.tsx",
		children: void 0,
		preloads: [
			"/assets/vip-B-xg2dR8.js",
			"/assets/invoice-modal-DAdM1VRm.js",
			"/assets/select-BC-u9zSf.js",
			"/assets/cup-soda-Biyrjq3_.js",
			"/assets/card-8Nmoemy5.js",
			"/assets/checkbox-D96-PN9D.js",
			"/assets/input-CT8n5iKV.js",
			"/assets/label-cb0gCIlh.js"
		]
	},
	"/_app/": {
		filePath: "/workspace/src/routes/_app/index.tsx",
		children: void 0,
		preloads: [
			"/assets/_app-DVOuO2lL.js",
			"/assets/cup-soda-Biyrjq3_.js",
			"/assets/card-8Nmoemy5.js"
		]
	}
} });
//#endregion
export { tsrStartManifest };
