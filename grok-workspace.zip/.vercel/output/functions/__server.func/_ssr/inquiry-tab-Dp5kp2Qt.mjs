import { o as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { p as require_jsx_runtime } from "../_libs/@radix-ui/react-checkbox+[...].mjs";
import { t as Button } from "./button-D_PHfu3x.mjs";
import { t as CupifyWordmark } from "./logo-DhQH1Ggo.mjs";
import { a as CardTitle, i as CardHeader, n as CardContent, t as Card } from "./card-BqLLulKB.mjs";
import { a as dayLabel, d as nextStatuses, i as dayKey, m as when, u as money } from "./format-ydPugZ1g.mjs";
import { C as searchInvoices, E as updateOrderStatus, d as listLogs, g as listStaffOrders, m as listRemarks, t as addRemark } from "./api-DUpluZ3_.mjs";
import { i as useQueryClient, n as useQuery, t as useMutation } from "../_libs/tanstack__react-query.mjs";
import { i as TabsTrigger, n as TabsContent, r as TabsList, t as Tabs } from "./tabs-DQHqT2d-.mjs";
import { n as StatusBadge, t as Badge } from "./status-badge-CypCGZWh.mjs";
import { a as SelectValue, i as SelectTrigger, n as SelectContent, r as SelectItem, t as Select } from "./select-DLjEeGji.mjs";
import { o as InvoiceModal } from "./invoice-modal-DmA2m8xY.mjs";
import { t as Textarea } from "./textarea-flI-r2o4.mjs";
import { t as Input } from "./input-C8FVBVyT.mjs";
import { n as toast } from "../_libs/sonner.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/inquiry-tab-Dp5kp2Qt.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function OrderDetailPanel({ order, canEdit = true, lockBanner }) {
	const qc = useQueryClient();
	const remarks = useQuery({
		queryKey: ["remarks", order.id],
		queryFn: () => listRemarks({ data: { orderId: order.id } })
	});
	const [note, setNote] = (0, import_react.useState)("");
	const [invoice, setInvoice] = (0, import_react.useState)(false);
	const statusMut = useMutation({
		mutationFn: (status) => updateOrderStatus({ data: {
			id: order.id,
			status
		} }),
		onSuccess() {
			qc.invalidateQueries({ queryKey: ["staff-orders"] });
			toast.success("Status updated");
		},
		onError(e) {
			toast.error(e instanceof Error ? e.message : "Failed");
		}
	});
	const remarkMut = useMutation({
		mutationFn: () => addRemark({ data: {
			orderId: order.id,
			content: note
		} }),
		onSuccess() {
			setNote("");
			qc.invalidateQueries({ queryKey: ["remarks", order.id] });
			toast.success("Remark added");
		}
	});
	const allowed = nextStatuses(order.status);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-4",
		children: [
			lockBanner && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "rounded-md border border-accent/40 bg-accent/10 px-3 py-2 text-sm",
				children: lockBanner
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap items-center gap-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-display text-xl font-semibold",
						children: order.orderNumber
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatusBadge, { status: order.status }),
					order.walkIn && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
						variant: "secondary",
						children: "Walk-in"
					}),
					order.isVip && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
						variant: "accent",
						children: "VIP"
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-sm",
				children: [
					order.customerName,
					" · ",
					order.customerPhone || order.customerEmail || "no contact"
				]
			}),
			canEdit && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
				value: order.status,
				onValueChange: (v) => statusMut.mutate(v),
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, {
					className: "max-w-xs",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, {})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectContent, { children: allowed.map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
					value: s,
					children: s.replace("_", " ")
				}, s)) })]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Tabs, {
				defaultValue: "details",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TabsList, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsTrigger, {
						value: "details",
						children: "Details & remarks"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsTrigger, {
						value: "invoice",
						children: "Invoice"
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TabsContent, {
						value: "details",
						className: "space-y-4",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
								className: "text-sm",
								children: order.items.map((it, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
									className: "flex justify-between py-1",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
										it.quantity,
										"× ",
										it.productName,
										it.cupType === "custom" ? ` (${it.customCupName})` : ""
									] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "tabular-nums",
										children: money(it.price * it.quantity)
									})]
								}, i))
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "text-sm",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex justify-between",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Total" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "tabular-nums",
											children: money(order.total)
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex justify-between text-muted-foreground",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Advance / balance" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
											className: "tabular-nums",
											children: [
												money(order.advancePaid),
												" / ",
												money(order.balanceDue)
											]
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
										className: "mt-1 text-muted-foreground",
										children: [
											order.paymentMethod,
											" · ",
											when(order.createdAt),
											order.assignedStaffName ? ` · ${order.assignedStaffName}` : ""
										]
									}),
									order.notes ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "mt-2",
										children: order.notes
									}) : null
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "space-y-2",
								children: [(remarks.data ?? []).map((r) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "rounded-md bg-secondary p-3 text-sm",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: r.content }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
										className: "mt-1 text-xs text-muted-foreground",
										children: [
											r.staffName,
											" · ",
											when(r.createdAt)
										]
									})]
								}, r.id)), canEdit && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
										value: note,
										onChange: (e) => setNote(e.target.value),
										placeholder: "Add a remark"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
										disabled: !note.trim() || remarkMut.isPending,
										onClick: () => remarkMut.mutate(),
										children: "Add"
									})]
								})]
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsContent, {
						value: "invoice",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							onClick: () => setInvoice(true),
							children: "Open invoice"
						})
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(InvoiceModal, {
				order,
				open: invoice,
				onOpenChange: setInvoice
			})
		]
	});
}
function DateOrdersTab({ admin }) {
	const orders = useQuery({
		queryKey: ["staff-orders"],
		queryFn: () => listStaffOrders()
	});
	const [open, setOpen] = (0, import_react.useState)(null);
	const [selected, setSelected] = (0, import_react.useState)(null);
	const groups = (0, import_react.useMemo)(() => {
		const map = /* @__PURE__ */ new Map();
		for (const o of orders.data ?? []) {
			const k = dayKey(o.createdAt);
			const arr = map.get(k) ?? [];
			arr.push(o);
			map.set(k, arr);
		}
		return [...map.entries()].sort((a, b) => a[0] < b[0] ? 1 : -1);
	}, [orders.data]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: admin ? "grid gap-4 lg:grid-cols-[1fr_360px]" : "space-y-3",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "space-y-3",
			children: groups.map(([k, list]) => {
				const total = list.reduce((s, o) => s + (o.status === "cancelled" ? 0 : o.total), 0);
				const expanded = open === k;
				return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "rounded-xl border border-border bg-card",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						className: "flex w-full items-center justify-between p-4 text-left",
						onClick: () => setOpen(expanded ? null : k),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "font-medium",
							children: dayLabel(k)
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "text-sm text-muted-foreground",
							children: [
								list.length,
								" · ",
								money(total)
							]
						})]
					}), expanded && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "space-y-2 border-t border-border p-3",
						children: list.map((o) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							className: "block w-full rounded-md bg-secondary/50 p-3 text-left text-sm",
							onClick: () => setSelected(o),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex flex-wrap items-center gap-2",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "font-medium",
										children: o.orderNumber
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatusBadge, { status: o.status }),
									o.isVip && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
										variant: "accent",
										children: "VIP"
									}),
									o.walkIn && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
										variant: "secondary",
										children: "Walk-in"
									})
								]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "mt-1 text-muted-foreground",
								children: [
									o.customerName,
									" · ",
									o.customerPhone,
									" · ",
									money(o.total),
									" · ",
									when(o.createdAt),
									o.assignedStaffName ? ` · ${o.assignedStaffName}` : ""
								]
							})]
						}, o.id))
					})]
				}, k);
			})
		}), admin && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "rounded-xl border border-border bg-card p-4",
			children: selected ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(OrderDetailPanel, { order: selected }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "py-10 text-center text-sm text-muted-foreground",
				children: "Select an order"
			})
		})]
	});
}
function InquiryTab() {
	const [q, setQ] = (0, import_react.useState)("");
	const [order, setOrder] = (0, import_react.useState)(null);
	const [logs, setLogs] = (0, import_react.useState)([]);
	const [remarks, setRemarks] = (0, import_react.useState)([]);
	const search = useMutation({ mutationFn: () => searchInvoices({ data: { q } }) });
	async function pick(o) {
		setOrder(o);
		const [l, r] = await Promise.all([listLogs(), listRemarks({ data: { orderId: o.id } })]);
		setLogs(l.filter((x) => x.entityId === String(o.id) || x.action.includes(o.orderNumber)));
		setRemarks(r);
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				className: "flex gap-2",
				onSubmit: (e) => {
					e.preventDefault();
					search.mutate();
				},
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					placeholder: "Phone, order #, name, email",
					value: q,
					onChange: (e) => setQ(e.target.value)
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					type: "submit",
					children: "Search"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "space-y-2",
				children: (search.data ?? []).map((o) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					className: "w-full rounded-md border border-border p-3 text-left text-sm",
					onClick: () => void pick(o),
					children: [
						o.orderNumber,
						" · ",
						o.customerName
					]
				}, o.id))
			}),
			order && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
				className: "inquiry-sheet",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardHeader, {
					className: "bg-primary text-primary-foreground",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CupifyWordmark, { className: "text-primary-foreground" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardTitle, {
						className: "text-primary-foreground",
						children: ["Inquiry · ", order.orderNumber]
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardContent, {
					className: "space-y-4 pt-6 text-sm",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
							order.customerName,
							" · ",
							order.customerPhone,
							" · ",
							order.customerEmail,
							" · ",
							order.paymentMethod
						] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", { children: order.items.map((it, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [
							it.quantity,
							"× ",
							it.productName
						] }, i)) }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-medium tabular-nums",
							children: money(order.total)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mb-2 font-medium",
							children: "Activity"
						}), logs.map((l) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-start gap-2 border-l border-border py-1 pl-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
								variant: "secondary",
								children: l.userRole
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
								l.action,
								" · ",
								when(l.createdAt)
							] })]
						}, l.id))] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mb-2 font-medium",
							children: "Remarks"
						}), remarks.map((r) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-muted-foreground",
							children: [
								r.staffName,
								": ",
								r.content
							]
						}, r.id))] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							className: "no-print",
							onClick: () => window.print(),
							children: "Download inquiry PDF"
						})
					]
				})]
			})
		]
	});
}
//#endregion
export { InquiryTab as n, OrderDetailPanel as r, DateOrdersTab as t };
