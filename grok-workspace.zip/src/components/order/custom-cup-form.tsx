import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import type { Product } from "@/lib/cupify/types";
import { money } from "@/lib/cupify/format";

export function CustomCupForm({
  product,
  onAdd,
  onClose,
}: {
  product: Product;
  onAdd: (extra: { customCupName: string; customCupMessage?: string; customCupImageUrl?: string }) => void;
  onClose: () => void;
}) {
  const [name, setName] = useState("");
  const [message, setMessage] = useState("");
  const [preview, setPreview] = useState<string | undefined>();
  const [soon, setSoon] = useState(false);

  function onFile(file?: File) {
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => setPreview(String(reader.result));
    reader.readAsDataURL(file);
    setSoon(true);
  }

  return (
    <div className="space-y-4 rounded-xl border border-border bg-card p-4">
      <div className="flex items-start justify-between">
        <div>
          <h3 className="font-display text-lg font-semibold">Custom {product.name}</h3>
          <p className="text-xs text-muted-foreground">Print charge {money(product.customCupCharge)}</p>
        </div>
        <Button variant="ghost" size="sm" onClick={onClose}>
          Close
        </Button>
      </div>
      <div className="grid gap-4 md:grid-cols-2">
        <div className="space-y-3">
          <div className="space-y-1.5">
            <Label htmlFor="cup-name">Name on cup</Label>
            <Input id="cup-name" value={name} onChange={(e) => setName(e.target.value)} required />
          </div>
          <div className="space-y-1.5">
            <Label htmlFor="cup-msg">Message</Label>
            <Textarea id="cup-msg" value={message} onChange={(e) => setMessage(e.target.value)} />
          </div>
          <div className="space-y-1.5">
            <Label htmlFor="cup-photo">Photo</Label>
            <Input id="cup-photo" type="file" accept="image/*" onChange={(e) => onFile(e.target.files?.[0])} />
          </div>
          <Button
            className="w-full"
            disabled={!name.trim()}
            onClick={() =>
              onAdd({ customCupName: name.trim(), customCupMessage: message.trim() || undefined, customCupImageUrl: preview })
            }
          >
            Add custom cup
          </Button>
        </div>
        <div className="relative flex min-h-48 items-center justify-center overflow-hidden rounded-xl bg-primary text-primary-foreground">
          {preview ? (
            <img src={preview} alt="" className="absolute inset-0 h-full w-full object-cover opacity-40" />
          ) : null}
          <div className="relative z-10 px-4 text-center">
            <p className="text-[10px] uppercase tracking-[0.25em] opacity-70">Cupify</p>
            <p className="mt-2 font-display text-2xl">{name || "Your name"}</p>
            {message ? <p className="mt-1 text-sm opacity-80">{message}</p> : null}
          </div>
        </div>
      </div>
      <Dialog open={soon} onOpenChange={setSoon}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Cloud upload coming soon</DialogTitle>
            <DialogDescription>Your photo is previewed locally and saved with the order. Hosted storage ships next.</DialogDescription>
          </DialogHeader>
        </DialogContent>
      </Dialog>
    </div>
  );
}
