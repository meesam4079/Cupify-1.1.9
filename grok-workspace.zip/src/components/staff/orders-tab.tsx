import { useMutation, useQuery } from "@tanstack/react-query";
import { useEffect, useMemo, useState } from "react";
import { getMyProfile, listStaffOrders, lockOrder } from "@/lib/cupify/api";
import { LOCK_MS } from "@/lib/cupify/types";
import type { Order, ProductCategory } from "@/lib/cupify/types";
import { StatusBadge } from "@/components/shared/status-badge";
import { OrderDetailPanel } from "@/components/shared/order-detail-panel";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { cn } from "@/lib/utils";

export function OrdersSplit() {
  const me = useQuery({ queryKey: ["me"], queryFn: () => getMyProfile() });
  const orders = useQuery({ queryKey: ["staff-orders"], queryFn: () => listStaffOrders(), refetchInterval: 4000 });
  const [selected, setSelected] = useState<number | null>(null);
  const [q, setQ] = useState("");
  const [channel, setChannel] = useState<"all" | "walk" | "online">("all");
  const [cat, setCat] = useState<"all" | ProductCategory>("all");

  const lock = useMutation({ mutationFn: (id: number | null) => lockOrder({ data: { id } }) });

  useEffect(() => {
    lock.mutate(selected);
    return () => {
      lock.mutate(null);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [selected]);

  const list = useMemo(() => {
    let rows = orders.data ?? [];
    if (channel === "walk") rows = rows.filter((o) => o.walkIn);
    if (channel === "online") rows = rows.filter((o) => !o.walkIn);
    if (cat !== "all") rows = rows.filter((o) => o.items.some((i) => i.category === cat));
    const s = q.trim().toLowerCase();
    if (s) {
      rows = rows.filter(
        (o) =>
          o.orderNumber.toLowerCase().includes(s) ||
          o.customerName.toLowerCase().includes(s) ||
          o.customerPhone.toLowerCase().includes(s) ||
          o.items.some((i) => i.productName.toLowerCase().includes(s)),
      );
    }
    return rows;
  }, [orders.data, q, channel, cat]);

  const current = list.find((o) => o.id === selected) ?? (orders.data ?? []).find((o) => o.id === selected);
  const counts = {
    all: (orders.data ?? []).length,
    coffee: (orders.data ?? []).filter((o) => o.items.some((i) => i.category === "coffee")).length,
    tea: (orders.data ?? []).filter((o) => o.items.some((i) => i.category === "tea")).length,
    juice: (orders.data ?? []).filter((o) => o.items.some((i) => i.category === "juice")).length,
  };

  function banner(o: Order) {
    if (!o.lockedByStaffId || o.lockedByStaffId === me.data?.userId) return null;
    if (o.lockedAt && Date.now() - new Date(o.lockedAt).getTime() > LOCK_MS) return null;
    return `${o.lockedByStaffName} is currently viewing this order`;
  }

  return (
    <div className="grid gap-4 lg:grid-cols-[320px_1fr]">
      <div className="space-y-3">
        <Input placeholder="Search order, name, phone, drink" value={q} onChange={(e) => setQ(e.target.value)} />
        <div className="flex flex-wrap gap-2">
          {(["all", "walk", "online"] as const).map((c) => (
            <button
              key={c}
              type="button"
              onClick={() => setChannel(c)}
              className={cn("rounded-full border px-3 py-1 text-xs", channel === c ? "bg-secondary" : "border-border")}
            >
              {c === "all" ? "All" : c === "walk" ? "Walk-in" : "Online"}
            </button>
          ))}
        </div>
        <p className="text-xs text-muted-foreground">{list.length} records</p>
        <Tabs value={cat} onValueChange={(v) => setCat(v as typeof cat)}>
          <TabsList className="h-auto flex-wrap">
            <TabsTrigger value="all">All {counts.all}</TabsTrigger>
            <TabsTrigger value="coffee">Coffee {counts.coffee}</TabsTrigger>
            <TabsTrigger value="tea">Tea {counts.tea}</TabsTrigger>
            <TabsTrigger value="juice">Juice {counts.juice}</TabsTrigger>
          </TabsList>
        </Tabs>
        <div className="max-h-[70vh] space-y-2 overflow-y-auto">
          {list.map((o) => (
            <button
              key={o.id}
              type="button"
              onClick={() => setSelected(o.id)}
              className={cn(
                "w-full rounded-lg border p-3 text-left",
                selected === o.id ? "border-primary bg-secondary" : "border-border bg-card hover:bg-secondary/50",
              )}
            >
              <div className="flex items-center gap-2">
                <span className="grid h-8 w-8 place-items-center rounded-full bg-primary text-xs text-primary-foreground">
                  {o.customerName.charAt(0).toUpperCase()}
                </span>
                <div className="min-w-0 flex-1">
                  <div className="flex items-center gap-2">
                    <span className="truncate text-sm font-medium">{o.orderNumber}</span>
                    {o.walkIn && <Badge variant="secondary">W</Badge>}
                    {o.isVip && <Badge variant="accent">VIP</Badge>}
                  </div>
                  <p className="truncate text-xs text-muted-foreground">{o.customerName}</p>
                </div>
                <StatusBadge status={o.status} />
              </div>
            </button>
          ))}
        </div>
      </div>
      <div className="rounded-xl border border-border bg-card p-5">
        {current ? (
          <OrderDetailPanel order={current} lockBanner={banner(current)} />
        ) : (
          <p className="py-16 text-center text-sm text-muted-foreground">Select an order</p>
        )}
      </div>
    </div>
  );
}
