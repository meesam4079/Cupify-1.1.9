import { createFileRoute } from "@tanstack/react-router";
import { Protected } from "@/components/layout/protected";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { StaffDashboard } from "@/components/staff/dashboard";
import { OrdersSplit } from "@/components/staff/orders-tab";
import { DateOrdersTab } from "@/components/staff/date-tab";
import { CancelRefundTab } from "@/components/staff/cancel-tab";
import { RemarksTab } from "@/components/staff/remarks-tab";
import { InquiryTab } from "@/components/staff/inquiry-tab";
import { WalkInForm } from "@/components/staff/walk-in";
import { useQuery } from "@tanstack/react-query";
import { getMyProfile } from "@/lib/cupify/api";

export const Route = createFileRoute("/_app/staff")({ component: StaffRoute });

function StaffRoute() {
  return (
    <Protected roles={["staff", "admin"]}>
      <StaffPage />
    </Protected>
  );
}

function StaffPage() {
  const me = useQuery({ queryKey: ["me"], queryFn: () => getMyProfile() });
  return (
    <main className="mx-auto max-w-6xl px-4 py-8">
      <h1 className="font-display text-3xl font-semibold">Staff panel</h1>
      <p className="mt-1 text-sm text-muted-foreground">
        Welcome{me.data?.displayName ? `, ${me.data.displayName}` : ""}. Keep the board moving.
      </p>
      <Tabs defaultValue="dashboard" className="mt-6">
        <TabsList className="h-auto w-full flex-wrap justify-start overflow-x-auto">
          <TabsTrigger value="dashboard">Dashboard</TabsTrigger>
          <TabsTrigger value="orders">Orders</TabsTrigger>
          <TabsTrigger value="date">By date</TabsTrigger>
          <TabsTrigger value="cancel">Cancel / refund</TabsTrigger>
          <TabsTrigger value="remarks">Remarks</TabsTrigger>
          <TabsTrigger value="inquiry">Inquiry</TabsTrigger>
          <TabsTrigger value="walkin">Walk-in</TabsTrigger>
        </TabsList>
        <TabsContent value="dashboard">
          <StaffDashboard />
        </TabsContent>
        <TabsContent value="orders">
          <OrdersSplit />
        </TabsContent>
        <TabsContent value="date">
          <DateOrdersTab />
        </TabsContent>
        <TabsContent value="cancel">
          <CancelRefundTab />
        </TabsContent>
        <TabsContent value="remarks">
          <RemarksTab />
        </TabsContent>
        <TabsContent value="inquiry">
          <InquiryTab />
        </TabsContent>
        <TabsContent value="walkin">
          <WalkInForm />
        </TabsContent>
      </Tabs>
    </main>
  );
}
