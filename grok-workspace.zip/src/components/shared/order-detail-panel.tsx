import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useState } from "react";
import { toast } from "sonner";
import { addRemark, listRemarks, updateOrderStatus } from "@/lib/cupify/api";
import { money, nextStatuses, when } from "@/lib/cupify/format";
import type { Order, OrderStatus } from "@/lib/cupify/types";
import { StatusBadge } from "./status-badge";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { InvoiceModal } from "@/components/invoice/invoice-modal";

export function OrderDetailPanel({
  order,
  canEdit = true,
  lockBanner,
}: {
  order: Order;
  canEdit?: boolean;
  lockBanner?: string | null;
}) {
  const qc = useQueryClient();
  const remarks = useQuery({
    queryKey: ["remarks", order.id],
    queryFn: () => listRemarks({ data: { orderId: order.id } }),
  });
  const [note, setNote] = useState("");
  const [invoice, setInvoice] = useState(false);

  const statusMut = useMutation({
    mutationFn: (status: OrderStatus) => updateOrderStatus({ data: { id: order.id, status } }),
    onSuccess() {
      void qc.invalidateQueries({ queryKey: ["staff-orders"] });
      toast.success("Status updated");
    },
    onError(e) {
      toast.error(e instanceof Error ? e.message : "Failed");
    },
  });
  const remarkMut = useMutation({
    mutationFn: () => addRemark({ data: { orderId: order.id, content: note } }),
    onSuccess() {
      setNote("");
      void qc.invalidateQueries({ queryKey: ["remarks", order.id] });
      toast.success("Remark added");
    },
  });

  const allowed = nextStatuses(order.status);

  return (
    <div className="space-y-4">
      {lockBanner && (
        <div className="rounded-md border border-accent/40 bg-accent/10 px-3 py-2 text-sm">{lockBanner}</div>
      )}
      <div className="flex flex-wrap items-center gap-2">
        <h2 className="font-display text-xl font-semibold">{order.orderNumber}</h2>
        <StatusBadge status={order.status} />
        {order.walkIn && <Badge variant="secondary">Walk-in</Badge>}
        {order.isVip && <Badge variant="accent">VIP</Badge>}
      </div>
      <p className="text-sm">
        {order.customerName} · {order.customerPhone || order.customerEmail || "no contact"}
      </p>
      {canEdit && (
        <Select value={order.status} onValueChange={(v) => statusMut.mutate(v as OrderStatus)}>
          <SelectTrigger className="max-w-xs">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            {allowed.map((s) => (
              <SelectItem key={s} value={s}>
                {s.replace("_", " ")}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      )}
      <Tabs defaultValue="details">
        <TabsList>
          <TabsTrigger value="details">Details & remarks</TabsTrigger>
          <TabsTrigger value="invoice">Invoice</TabsTrigger>
        </TabsList>
        <TabsContent value="details" className="space-y-4">
          <ul className="text-sm">
            {order.items.map((it, i) => (
              <li key={i} className="flex justify-between py-1">
                <span>
                  {it.quantity}× {it.productName}
                  {it.cupType === "custom" ? ` (${it.customCupName})` : ""}
                </span>
                <span className="tabular-nums">{money(it.price * it.quantity)}</span>
              </li>
            ))}
          </ul>
          <div className="text-sm">
            <div className="flex justify-between">
              <span>Total</span>
              <span className="tabular-nums">{money(order.total)}</span>
            </div>
            <div className="flex justify-between text-muted-foreground">
              <span>Advance / balance</span>
              <span className="tabular-nums">
                {money(order.advancePaid)} / {money(order.balanceDue)}
              </span>
            </div>
            <p className="mt-1 text-muted-foreground">
              {order.paymentMethod} · {when(order.createdAt)}
              {order.assignedStaffName ? ` · ${order.assignedStaffName}` : ""}
            </p>
            {order.notes ? <p className="mt-2">{order.notes}</p> : null}
          </div>
          <div className="space-y-2">
            {(remarks.data ?? []).map((r) => (
              <div key={r.id} className="rounded-md bg-secondary p-3 text-sm">
                <p>{r.content}</p>
                <p className="mt-1 text-xs text-muted-foreground">
                  {r.staffName} · {when(r.createdAt)}
                </p>
              </div>
            ))}
            {canEdit && (
              <div className="flex gap-2">
                <Textarea value={note} onChange={(e) => setNote(e.target.value)} placeholder="Add a remark" />
                <Button disabled={!note.trim() || remarkMut.isPending} onClick={() => remarkMut.mutate()}>
                  Add
                </Button>
              </div>
            )}
          </div>
        </TabsContent>
        <TabsContent value="invoice">
          <Button onClick={() => setInvoice(true)}>Open invoice</Button>
        </TabsContent>
      </Tabs>
      <InvoiceModal order={order} open={invoice} onOpenChange={setInvoice} />
    </div>
  );
}
