import { useQuery } from "@tanstack/react-query";
import { useMemo, useState } from "react";
import { listStaffOrders } from "@/lib/cupify/api";
import { dayKey, dayLabel, money, when } from "@/lib/cupify/format";
import { StatusBadge } from "@/components/shared/status-badge";
import { Badge } from "@/components/ui/badge";
import { OrderDetailPanel } from "@/components/shared/order-detail-panel";
import type { Order } from "@/lib/cupify/types";

export function DateOrdersTab({ admin }: { admin?: boolean }) {
  const orders = useQuery({ queryKey: ["staff-orders"], queryFn: () => listStaffOrders() });
  const [open, setOpen] = useState<string | null>(null);
  const [selected, setSelected] = useState<Order | null>(null);

  const groups = useMemo(() => {
    const map = new Map<string, Order[]>();
    for (const o of orders.data ?? []) {
      const k = dayKey(o.createdAt);
      const arr = map.get(k) ?? [];
      arr.push(o);
      map.set(k, arr);
    }
    return [...map.entries()].sort((a, b) => (a[0] < b[0] ? 1 : -1));
  }, [orders.data]);

  return (
    <div className={admin ? "grid gap-4 lg:grid-cols-[1fr_360px]" : "space-y-3"}>
      <div className="space-y-3">
        {groups.map(([k, list]) => {
          const total = list.reduce((s, o) => s + (o.status === "cancelled" ? 0 : o.total), 0);
          const expanded = open === k;
          return (
            <div key={k} className="rounded-xl border border-border bg-card">
              <button type="button" className="flex w-full items-center justify-between p-4 text-left" onClick={() => setOpen(expanded ? null : k)}>
                <span className="font-medium">{dayLabel(k)}</span>
                <span className="text-sm text-muted-foreground">
                  {list.length} · {money(total)}
                </span>
              </button>
              {expanded && (
                <div className="space-y-2 border-t border-border p-3">
                  {list.map((o) => (
                    <button
                      key={o.id}
                      type="button"
                      className="block w-full rounded-md bg-secondary/50 p-3 text-left text-sm"
                      onClick={() => setSelected(o)}
                    >
                      <div className="flex flex-wrap items-center gap-2">
                        <span className="font-medium">{o.orderNumber}</span>
                        <StatusBadge status={o.status} />
                        {o.isVip && <Badge variant="accent">VIP</Badge>}
                        {o.walkIn && <Badge variant="secondary">Walk-in</Badge>}
                      </div>
                      <p className="mt-1 text-muted-foreground">
                        {o.customerName} · {o.customerPhone} · {money(o.total)} · {when(o.createdAt)}
                        {o.assignedStaffName ? ` · ${o.assignedStaffName}` : ""}
                      </p>
                    </button>
                  ))}
                </div>
              )}
            </div>
          );
        })}
      </div>
      {admin && (
        <div className="rounded-xl border border-border bg-card p-4">
          {selected ? <OrderDetailPanel order={selected} /> : <p className="py-10 text-center text-sm text-muted-foreground">Select an order</p>}
        </div>
      )}
    </div>
  );
}
