import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useState } from "react";
import { toast } from "sonner";
import { listRefunds, reviewRefund } from "@/lib/cupify/api";
import { money, when } from "@/lib/cupify/format";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";

export function AdminRefundsTab() {
  const qc = useQueryClient();
  const refunds = useQuery({ queryKey: ["refunds"], queryFn: () => listRefunds() });
  const [note, setNote] = useState("");
  const [filter, setFilter] = useState<"all" | "refund" | "cancellation">("all");
  const pending = (refunds.data ?? []).filter((r) => r.status === "pending");
  const resolved = (refunds.data ?? []).filter((r) => r.status !== "pending" && (filter === "all" || r.requestType === filter));

  const mut = useMutation({
    mutationFn: (input: { id: number; approve: boolean }) => reviewRefund({ data: { ...input, note } }),
    onSuccess() {
      setNote("");
      void qc.invalidateQueries({ queryKey: ["refunds"] });
      void qc.invalidateQueries({ queryKey: ["staff-orders"] });
      toast.success("Recorded");
    },
    onError(e) {
      toast.error(e instanceof Error ? e.message : "Failed");
    },
  });

  return (
    <div className="space-y-8">
      <div className="space-y-3">
        <h3 className="font-display text-lg">Pending</h3>
        {pending.length === 0 && <p className="text-sm text-muted-foreground">No pending requests.</p>}
        {pending.map((r) => (
          <div key={r.id} className="rounded-xl border border-accent/40 bg-accent/10 p-4 text-sm">
            <div className="flex flex-wrap items-center gap-2">
              <span className="font-medium">{r.orderNumber}</span>
              <Badge>{r.requestType}</Badge>
              <span>{r.customerName}</span>
              <span className="tabular-nums">{money(r.amount)}</span>
            </div>
            <p className="mt-2">{r.reason}</p>
            <p className="mt-1 text-xs text-muted-foreground">
              {r.requestedByName} · {when(r.createdAt)}
            </p>
            <Input className="mt-3" placeholder="Admin note" value={note} onChange={(e) => setNote(e.target.value)} />
            <div className="mt-2 flex gap-2">
              <Button size="sm" onClick={() => mut.mutate({ id: r.id, approve: true })}>
                Approve
              </Button>
              <Button size="sm" variant="destructive" onClick={() => mut.mutate({ id: r.id, approve: false })}>
                Reject
              </Button>
            </div>
          </div>
        ))}
      </div>
      <div>
        <div className="mb-3 flex items-center justify-between">
          <h3 className="font-display text-lg">History</h3>
          <Tabs value={filter} onValueChange={(v) => setFilter(v as typeof filter)}>
            <TabsList>
              <TabsTrigger value="all">All</TabsTrigger>
              <TabsTrigger value="refund">Refund</TabsTrigger>
              <TabsTrigger value="cancellation">Cancel</TabsTrigger>
            </TabsList>
          </Tabs>
        </div>
        <div className="space-y-2">
          {resolved.map((r) => (
            <div key={r.id} className="rounded-lg border border-border p-3 text-sm">
              <div className="flex flex-wrap gap-2">
                <span className="font-medium">{r.orderNumber}</span>
                <Badge variant={r.status === "approved" ? "default" : "destructive"}>{r.status}</Badge>
                <Badge variant="secondary">{r.requestType}</Badge>
              </div>
              <p className="text-xs text-muted-foreground">
                {r.reviewedByName} · {when(r.createdAt)}
              </p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
