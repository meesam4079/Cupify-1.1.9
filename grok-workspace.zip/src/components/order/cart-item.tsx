import { Minus, Plus, Trash2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { money, lineTotal } from "@/lib/cupify/format";
import type { CartLine } from "@/lib/cupify/types";

export function CartItemRow({
  item,
  onQty,
  onRemove,
}: {
  item: CartLine;
  onQty: (n: number) => void;
  onRemove: () => void;
}) {
  return (
    <div className="flex items-start justify-between gap-3 border-b border-border/60 py-3 last:border-0">
      <div className="min-w-0">
        <p className="truncate font-medium">{item.productName}</p>
        <p className="text-xs text-muted-foreground">
          {item.cupType === "custom" ? `Custom · ${item.customCupName ?? "named cup"}` : "Standard"} · {money(item.price)}
          {item.cupType === "custom" && item.customCupCharge ? ` + ${money(item.customCupCharge)}` : ""}
        </p>
        <div className="mt-2 flex items-center gap-2">
          <Button size="icon" variant="outline" className="h-8 w-8" onClick={() => onQty(item.quantity - 1)} aria-label="Decrease">
            <Minus className="h-3 w-3" />
          </Button>
          <span className="w-6 text-center text-sm tabular-nums">{item.quantity}</span>
          <Button size="icon" variant="outline" className="h-8 w-8" onClick={() => onQty(item.quantity + 1)} aria-label="Increase">
            <Plus className="h-3 w-3" />
          </Button>
        </div>
      </div>
      <div className="flex flex-col items-end gap-2">
        <p className="text-sm font-medium tabular-nums">{money(lineTotal(item))}</p>
        <Button size="icon" variant="ghost" className="h-8 w-8" onClick={onRemove} aria-label="Remove">
          <Trash2 className="h-4 w-4" />
        </Button>
      </div>
    </div>
  );
}
