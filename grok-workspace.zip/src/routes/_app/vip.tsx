import { createFileRoute } from "@tanstack/react-router";
import { useMutation, useQuery } from "@tanstack/react-query";
import { useState } from "react";
import { Crown, Zap, CupSoda, Wallet } from "lucide-react";
import { toast } from "sonner";
import { listAvailableProducts, placeOrder } from "@/lib/cupify/api";
import { money } from "@/lib/cupify/format";
import { VIP_SURCHARGE } from "@/lib/cupify/types";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { InvoiceModal } from "@/components/invoice/invoice-modal";
import type { Order } from "@/lib/cupify/types";

export const Route = createFileRoute("/_app/vip")({ component: VipPage });

function VipPage() {
  const products = useQuery({ queryKey: ["products-available"], queryFn: () => listAvailableProducts() });
  const [name, setName] = useState("");
  const [phone, setPhone] = useState("");
  const [productId, setProductId] = useState<string>("");
  const [qty, setQty] = useState(1);
  const [terms, setTerms] = useState(false);
  const [mkt, setMkt] = useState(false);
  const [placed, setPlaced] = useState<Order | null>(null);
  const [invoice, setInvoice] = useState(false);

  const product = (products.data ?? []).find((p) => String(p.id) === productId);
  const total = product ? product.price * qty + VIP_SURCHARGE : VIP_SURCHARGE;

  const place = useMutation({
    mutationFn: () => {
      if (!product) throw new Error("Pick a drink");
      return placeOrder({
        data: {
          customerName: name,
          customerEmail: "",
          customerPhone: phone,
          items: [
            {
              productId: String(product.id),
              productName: product.name,
              quantity: qty,
              price: product.price,
              cupType: "standard",
              category: product.category,
            },
          ],
          paymentMethod: "card",
          isVip: true,
          consentOwnImage: true,
          consentMarketing: mkt,
        },
      });
    },
    onSuccess(o) {
      setPlaced(o);
      setInvoice(true);
      toast.success("VIP order placed");
    },
    onError(err) {
      toast.error(err instanceof Error ? err.message : "Could not place VIP order");
    },
  });

  return (
    <main className="mx-auto max-w-3xl px-4 py-12">
      <div className="mb-8 flex items-center gap-3">
        <Crown className="h-6 w-6 text-accent" />
        <h1 className="font-display text-3xl font-semibold">VIP desk</h1>
      </div>
      <div className="grid gap-4 sm:grid-cols-3">
        {[
          { icon: Zap, title: "Priority queue", body: "Your ticket jumps the board." },
          { icon: CupSoda, title: "Premium cup", body: "Presentation that matches the surcharge." },
          { icon: Wallet, title: "Paid in full", body: "No balance waiting at pickup." },
        ].map((p) => (
          <Card key={p.title}>
            <CardHeader>
              <p.icon className="h-4 w-4 text-accent" />
              <CardTitle className="text-base">{p.title}</CardTitle>
              <p className="text-sm text-muted-foreground">{p.body}</p>
            </CardHeader>
          </Card>
        ))}
      </div>
      <Card className="mt-8">
        <CardHeader>
          <CardTitle>Place VIP order</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-1.5">
            <Label>Name</Label>
            <Input value={name} onChange={(e) => setName(e.target.value)} required />
          </div>
          <div className="space-y-1.5">
            <Label>Phone</Label>
            <Input value={phone} onChange={(e) => setPhone(e.target.value)} />
          </div>
          <div className="space-y-1.5">
            <Label>Drink</Label>
            <Select value={productId} onValueChange={setProductId}>
              <SelectTrigger>
                <SelectValue placeholder="Choose a drink" />
              </SelectTrigger>
              <SelectContent>
                {(products.data ?? []).map((p) => (
                  <SelectItem key={p.id} value={String(p.id)}>
                    {p.name} · {money(p.price)}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div className="space-y-1.5">
            <Label>Quantity</Label>
            <Input type="number" min={1} value={qty} onChange={(e) => setQty(Math.max(1, Number(e.target.value) || 1))} />
          </div>
          <p className="text-sm">
            VIP surcharge {money(VIP_SURCHARGE)} · Total <span className="font-medium tabular-nums">{money(total)}</span> paid in full
          </p>
          <label className="flex items-start gap-2 text-sm">
            <Checkbox checked={terms} onCheckedChange={(v) => setTerms(v === true)} />
            I accept VIP terms (priority board, paid in full, no refunds on presentation)
          </label>
          <label className="flex items-start gap-2 text-sm">
            <Checkbox checked={mkt} onCheckedChange={(v) => setMkt(v === true)} />
            Allow marketing usage
          </label>
          <Button className="w-full" disabled={!name.trim() || !product || !terms || place.isPending} onClick={() => place.mutate()}>
            {place.isPending ? "Placing…" : "Place VIP order"}
          </Button>
        </CardContent>
      </Card>
      <InvoiceModal order={placed} open={invoice} onOpenChange={setInvoice} />
    </main>
  );
}
