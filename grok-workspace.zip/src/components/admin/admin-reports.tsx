import { useMutation } from "@tanstack/react-query";
import { useMemo, useState } from "react";
import { reportRange } from "@/lib/cupify/api";
import { money } from "@/lib/cupify/format";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";

function iso(d: Date) {
  return d.toISOString().slice(0, 10);
}

export function AdminReportsTab() {
  const today = iso(new Date());
  const [from, setFrom] = useState(today);
  const [to, setTo] = useState(today);
  const run = useMutation({ mutationFn: () => reportRange({ data: { from, to } }) });
  const d = run.data;

  const preset = (kind: "today" | "week" | "month") => {
    const now = new Date();
    if (kind === "today") {
      setFrom(today);
      setTo(today);
    } else if (kind === "week") {
      const s = new Date(now);
      s.setDate(now.getDate() - now.getDay());
      setFrom(iso(s));
      setTo(today);
    } else {
      setFrom(`${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, "0")}-01`);
      setTo(today);
    }
  };

  const csv = useMemo(() => {
    if (!d) return "";
    const rows = [["Product", "Qty", "Revenue"], ...d.top.map((p) => [p.name, String(p.qty), String(p.revenue)])];
    return rows.map((r) => r.join(",")).join("\n");
  }, [d]);

  function download() {
    const blob = new Blob([csv], { type: "text/csv" });
    const a = document.createElement("a");
    a.href = URL.createObjectURL(blob);
    a.download = `cupify-report-${from}-${to}.csv`;
    a.click();
  }

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-end gap-2">
        <Button size="sm" variant="outline" onClick={() => preset("today")}>
          Today
        </Button>
        <Button size="sm" variant="outline" onClick={() => preset("week")}>
          This week
        </Button>
        <Button size="sm" variant="outline" onClick={() => preset("month")}>
          This month
        </Button>
        <Input type="date" className="w-40" value={from} onChange={(e) => setFrom(e.target.value)} />
        <Input type="date" className="w-40" value={to} onChange={(e) => setTo(e.target.value)} />
        <Button onClick={() => run.mutate()}>Run</Button>
        {d && (
          <Button variant="outline" onClick={download}>
            Export CSV
          </Button>
        )}
      </div>
      {d && (
        <>
          <div className="grid gap-3 sm:grid-cols-5">
            {[
              ["Orders", String(d.totalOrders)],
              ["Revenue", money(d.revenue)],
              ["Average", money(d.average)],
              ["Custom cups", `${d.customPct.toFixed(0)}%`],
              ["VIP", `${d.vipPct.toFixed(0)}%`],
            ].map(([l, v]) => (
              <Card key={l}>
                <CardHeader className="pb-2">
                  <p className="text-xs text-muted-foreground">{l}</p>
                  <CardTitle className="text-lg tabular-nums">{v}</CardTitle>
                </CardHeader>
              </Card>
            ))}
          </div>
          <div className="grid gap-4 md:grid-cols-2">
            <Card>
              <CardHeader>
                <CardTitle className="text-base">By category</CardTitle>
              </CardHeader>
              <CardContent className="space-y-1 text-sm">
                {Object.entries(d.byCat).map(([k, v]) => (
                  <div key={k} className="flex justify-between capitalize">
                    <span>{k}</span>
                    <span className="tabular-nums">{money(v)}</span>
                  </div>
                ))}
              </CardContent>
            </Card>
            <Card>
              <CardHeader>
                <CardTitle className="text-base">By payment</CardTitle>
              </CardHeader>
              <CardContent className="space-y-1 text-sm">
                {Object.entries(d.byPay).map(([k, v]) => (
                  <div key={k} className="flex justify-between capitalize">
                    <span>{k}</span>
                    <span className="tabular-nums">{money(v)}</span>
                  </div>
                ))}
              </CardContent>
            </Card>
          </div>
          <Card>
            <CardHeader>
              <CardTitle className="text-base">Top products</CardTitle>
            </CardHeader>
            <CardContent className="text-sm">
              {d.top.map((p) => (
                <div key={p.name} className="flex justify-between py-1">
                  <span>
                    {p.name} × {p.qty}
                  </span>
                  <span className="tabular-nums">{money(p.revenue)}</span>
                </div>
              ))}
            </CardContent>
          </Card>
          <Card>
            <CardHeader>
              <CardTitle className="text-base">Staff</CardTitle>
            </CardHeader>
            <CardContent className="text-sm">
              {d.staff.map((s) => (
                <div key={s.name} className="flex justify-between py-1">
                  <span>
                    {s.name} · {s.orders} orders
                  </span>
                  <span className="tabular-nums">{money(s.revenue)}</span>
                </div>
              ))}
              {d.staff.length === 0 && <p className="text-muted-foreground">No assigned orders in range.</p>}
            </CardContent>
          </Card>
        </>
      )}
    </div>
  );
}
