import { o as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { p as require_jsx_runtime } from "../_libs/@radix-ui/react-checkbox+[...].mjs";
import { t as Button } from "./button-D_PHfu3x.mjs";
import { t as Card } from "./card-BqLLulKB.mjs";
import { u as money } from "./format-ydPugZ1g.mjs";
import { u as listAvailableProducts } from "./api-DUpluZ3_.mjs";
import { n as useQuery } from "../_libs/tanstack__react-query.mjs";
import { i as TabsTrigger, r as TabsList, t as Tabs } from "./tabs-DQHqT2d-.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { n as useCart } from "./router-D-yFOGtu.mjs";
import { t as Skeleton } from "./skeleton-cOr9hq3l.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/menu-B7rrq2Sn.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var fallback = {
	coffee: "https://images.unsplash.com/photo-1495474472287-4d71bcdd2085?w=800&q=80",
	tea: "https://images.unsplash.com/photo-1556679343-c7306c197c0b?w=800&q=80",
	juice: "https://images.unsplash.com/photo-1600271886742-f049cd451bba?w=800&q=80"
};
function MenuCard({ product, onAdd, compact }) {
	const src = product.imageUrl || fallback[product.category] || fallback.coffee;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
		className: "overflow-hidden transition-shadow hover:shadow-md",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "aspect-[4/3] overflow-hidden bg-secondary",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
				src,
				alt: product.name,
				className: "h-full w-full object-cover transition-transform duration-300 hover:scale-105"
			})
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "space-y-2 p-4",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-start justify-between gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
						className: "font-medium leading-tight",
						children: product.name
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs capitalize text-muted-foreground",
						children: product.category
					})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-medium tabular-nums",
						children: money(product.price)
					})]
				}),
				!compact && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "line-clamp-2 text-sm text-muted-foreground",
					children: product.description
				}),
				onAdd && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					className: "w-full",
					size: "sm",
					onClick: () => onAdd(product),
					children: "Add to order"
				})
			]
		})]
	});
}
function MenuPage() {
	const { data, isPending } = useQuery({
		queryKey: ["products-available"],
		queryFn: () => listAvailableProducts()
	});
	const { addStandard } = useCart();
	const [cat, setCat] = (0, import_react.useState)("all");
	const products = (data ?? []).filter((p) => cat === "all" || p.category === cat);
	function add(p) {
		addStandard(p);
		toast.success(`${p.name} added to cart`);
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "mx-auto max-w-6xl px-4 py-10",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "font-display text-3xl font-semibold",
				children: "Menu"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 text-sm text-muted-foreground",
				children: "Coffee, tea, juice — add a standard cup or custom-print on Order."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tabs, {
				value: cat,
				onValueChange: (v) => setCat(v),
				className: "mt-6",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TabsList, { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsTrigger, {
						value: "all",
						children: "All"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsTrigger, {
						value: "coffee",
						children: "Coffee"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsTrigger, {
						value: "tea",
						children: "Tea"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsTrigger, {
						value: "juice",
						children: "Juice"
					})
				] })
			}),
			isPending ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-6 grid gap-4 sm:grid-cols-2 lg:grid-cols-4",
				children: Array.from({ length: 8 }).map((_, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-64" }, i))
			}) : products.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-10 text-sm text-muted-foreground",
				children: "Nothing on the board in this category yet."
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-6 grid gap-4 sm:grid-cols-2 lg:grid-cols-4",
				children: products.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MenuCard, {
					product: p,
					onAdd: add
				}, p.id))
			})
		]
	});
}
//#endregion
export { MenuPage as component };
