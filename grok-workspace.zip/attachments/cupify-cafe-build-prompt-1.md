# 🍯 Cupify Cafe — Complete Application Build Prompt

## 📖 App Overview

A fully-featured **café order management system** called "Cupify Cafe." Customers can order drinks, personalize their own cups, and track orders in real time. Staff run day-to-day order operations; admins manage products, staff, refunds, reports, and system logs. Includes VIP ordering, authentication, custom-cup personalization, and a branded invoice/PDF system.

**Stack**: React + Vite + Tailwind CSS + shadcn/ui + Framer Motion + Base44 BaaS (database, auth, email, file storage).

---

## 🎨 Design System

### Color Tokens
```css
:root {
  --background: 30 25% 97%;      /* warm cream */
  --foreground: 25 30% 10%;      /* dark brown */
  --card: 30 20% 99%;
  --primary: 25 65% 28%;         /* deep brown #582d16 */
  --secondary: 30 30% 92%;
  --accent: 35 80% 52%;          /* golden #d49b50 */
  --destructive: 0 84% 60%;
  --border: 30 15% 88%;
  --radius: 0.75rem;
}
.dark {
  --background: 25 20% 7%;
  --primary: 35 80% 52%;         /* golden in dark */
  --foreground: 30 15% 93%;
}
```

### Fonts
- **Headings/Display**: `Playfair Display` (serif)
- **Body**: `DM Sans` + `Inter` fallback
- Import both via Google Fonts at the top of the global CSS.

### UI Architecture
- Split-screen pattern for management panels (left list + right detail)
- Fully responsive: mobile stacks, desktop shows side-by-side panels
- Tailwind utility conventions: `rounded-xl`, `shadow-lg`, `border-border/50`
- Framer Motion for entrance animation (fade-in, slide-up, hover scale)
- shadcn/ui components throughout (Dialog, Tabs, Select, Badge, Card, Button, etc.)

---

## 👥 Users & Roles

Three roles:

| Role | Access |
|------|--------|
| `admin` | Full access — every tab, reports, staff management, refunds, logs |
| `staff` | Staff dashboard, order management, walk-in orders, remarks/inquiry |
| `user` | Menu browsing, ordering, order tracking, VIP ordering |

### Auth Flow
- Pages: Login, Register, ForgotPassword, ResetPassword
- Google OAuth login
- Email + password login
- Registration includes **email-based OTP verification only** (no SMS OTP — this avoids the cost of a paid SMS gateway API). The OTP code is sent to the user's email via Base44's built-in email sending; the user enters the code on the Register page to verify their account before login is allowed.
- `ProtectedRoute` wrapper: only authenticated users can access protected pages
- `/admin` and `/staff` are role-gated with redirect if unauthorized

---

## 📄 Routing

```
/login              → Login
/register           → Register (OTP flow)
/forgot-password    → ForgotPassword
/reset-password     → ResetPassword (?token=)
/                   → Home (protected)
/menu               → MenuPage (protected)
/order              → OrderPage (protected)
/track              → TrackPage (protected)
/vip                → VipPage (protected)
/admin              → AdminPage (admin only)
/staff              → StaffPage (staff + admin)
/about              → AboutPage (protected)
*                   → PageNotFound
```

- All authenticated routes are wrapped in `<ProtectedRoute>` + `<AppLayout>`.
- `AppLayout` renders `<Navbar />` + `<Outlet />`.
- `Navbar`: sticky top, blurred background, mobile hamburger menu.
  - Links: Home, Menu, Order, Track, VIP, About
  - Role-gated links: Admin (admin only), Staff (staff/admin)
  - Active-link highlighting

---

## 🗄️ Entities (Database Schema)

### 1. `Order`
```json
{
  "order_number": "string",          // CUP-000001 or VIP-XXXXXX
  "customer_name": "string",
  "customer_email": "string",
  "customer_phone": "string",
  "items": [{
    "product_id": "string",
    "product_name": "string",
    "quantity": "number",
    "price": "number",
    "cup_type": "string",            // "standard" | "custom"
    "custom_cup_name": "string",
    "custom_cup_message": "string",
    "custom_cup_image_url": "string",
    "custom_cup_charge": "number"
  }],
  "subtotal": "number",
  "custom_charges": "number",
  "total": "number",
  "advance_paid": "number",
  "balance_due": "number",
  "is_vip": "boolean (default false)",
  "walk_in": "boolean (default false)",
  "status": "string",               // received | designing | printing | ready | delivered | cancelled | cancel_requested
  "consent_own_image": "boolean",
  "consent_marketing": "boolean",
  "assigned_staff_id": "string",
  "assigned_staff_name": "string",
  "payment_method": "string",       // cash | card | online
  "notes": "string"
}
```

### 2. `Product`
```json
{
  "name": "string",
  "category": "string",             // coffee | tea | juice
  "price": "number",
  "description": "string",
  "image_url": "string",
  "is_available": "boolean (default true)",
  "custom_cup_charge": "number (default 0)"
}
```

### 3. `RefundRequest`
```json
{
  "order_id": "string",
  "order_number": "string",
  "customer_name": "string",
  "request_type": "string",         // refund | cancellation
  "reason": "string",
  "status": "string",               // pending | approved | rejected
  "requested_by_id": "string",
  "requested_by_name": "string",
  "reviewed_by_id": "string",
  "reviewed_by_name": "string",
  "admin_note": "string",
  "amount": "number"
}
```

### 4. `Remark`
```json
{
  "order_id": "string",
  "order_number": "string",
  "customer_name": "string",
  "staff_id": "string",
  "staff_name": "string",
  "content": "string"
}
```

### 5. `ActivityLog`
```json
{
  "user_name": "string",
  "user_role": "string",            // admin | staff | customer
  "action": "string",
  "entity_type": "string",          // order | product | user
  "entity_id": "string"
}
```

### 6. `User` (built-in)
- Built-in Base44 entity — editable `role` field (admin/staff/user)
- Cannot create records directly — invite via `base44.users.inviteUser(email, role)`

---

## 🏪 Page-by-Page Details

### 1. Home (`/`)
- **Hero**: animated entrance, cafe branding "☕ Cupify Cafe", tagline "Sip Your Story", CTA buttons (Explore Menu, Custom Cup)
- **Features grid** (3 cards): Premium Drinks, Custom Cups, Share Moments — icon + title + description each
- **VIP CTA section**: gradient brown card with "Join VIP" button
- **Footer**: "© 2026 Cupify Cafe ☕📸 — Sip Your Story. #CupifyMoments"

### 2. Menu Page (`/menu`)
- Product grid, responsive 1→4 columns
- Category tabs: All / Coffee / Tea / Juice (with icons)
- `MenuCard` component:
  - Product image (Unsplash fallback by category if no `image_url`)
  - Category fallback images for coffee / tea / juice
  - Name, category, price, description
  - "Add to Order" button → adds standard cup to cart
  - Hover: image zoom + shadow lift
- Loading spinner, empty state
- Only shows products where `is_available !== false`

### 3. Order Page (`/order`) — Multi-step Checkout

**3 steps**: `cart` → `details` → `done`

**Step 1: Cart**
- Left: product list with "Standard" and "Custom" buttons per product
  - Standard → adds to cart immediately
  - Custom → opens `CustomCupForm` inline
- Right: cart with `CartItem` components
  - Quantity +/- controls, remove button
  - Custom cup indicator (+charge)
  - Subtotal, custom charges, total, advance (30%)
  - "Continue to Details" button
- Toast on add: "{product} added to cart!"

**CustomCupForm**
- Name on cup (required), message (optional)
- Photo upload (FileReader → base64 preview; cloud upload shows "Coming Soon" dialog but local preview still works)
- Live cup preview: mockup with image + name + message + "CUPIFY ☕" watermark
- Adds custom cup item to cart with `custom_cup_charge`

**Step 2: Details**
- Name (required), email, phone
- Payment method: Cash / Card / Online Transfer (radio group)
- If cart contains a custom cup → consent checkboxes:
  - "I own the image rights" (required if custom)
  - "Allow marketing usage" (optional)
- Order summary: total, advance (30%), balance at pickup
- Back / Place Order buttons
- **On placement**:
  - Auto-generate `CUP-XXXXXX` (timestamp-based)
  - Save order to database
  - Send branded HTML email to customer (header, items table, totals)
  - Show `InvoiceModal`
  - Clear cart, move to "done" step

**Step 3: Done**
- "Order Placed! ☕📸" success message
- "View Invoice" + "New Order" buttons

**Order Context** (`orderContext.jsx`)
- Cart state in React Context
- `addToCart`: merges standard items; unique `cartId` (Date.now() + Math.random()) for custom cups
- `updateQuantity`, `removeFromCart`, `clearCart`
- Computed: `cartTotal`, `cartCount`

### 4. Track Page (`/track`) — Two tabs

**Tab 1: Track Order**
- Input: order number → search
- Result (`OrderResult`): order number, VIP badge, walk-in/online badge, date
  - **Status timeline**: 5 steps (Received → Designing → Printing → Ready → Delivered), each with icon + completed/current/pending state and connecting line
  - Cancelled state shows red badge
  - Items list with totals
  - "View Invoice" button

**Tab 2: Track Invoice**
- Flexible search: phone / email / name / order number
- Searches all 4 fields, deduplicates results
- Multiple matches → selectable list
- Selected order: card with order#, customer, items, total, "View Full Invoice" button
- Opens `InvoiceModal`

### 5. VIP Page (`/vip`)
- VIP branding, crown icon
- 3 perk cards: Instant Priority Queue, Premium Cup & Presentation, Full Payment — No Balance
- Order form: name (required), phone, drink select (dropdown with prices), quantity
  - VIP surcharge: Rs.100
  - Total = (drink × qty) + surcharge, paid in full, no balance
  - Consent checkboxes (VIP terms + marketing)
  - "Place VIP Order" button
- Order number format: `VIP-XXXXXX`
- `is_vip: true`, `advance_paid: total`, `balance_due: 0`

### 6. About Page (`/about`)
- Hero: founder photo + name "Syed Meesam Abbas Sherazi"
- Bio sections: About, Expertise & Vision
- Contact card: Email, Instagram (@meesam4079)
- Framer Motion entrance animations

### 7. Staff Page (`/staff`) — Roles: staff + admin

Header: "Staff Panel" + welcome message.

**7 Tabs** (horizontally scrollable on mobile):

#### Tab 1: Dashboard (`StaffDashboard`)
- 8 stat cards: New Orders, In Progress, Ready, Delivered, Refund Requests, Cancel Requests, Remarks Today, Total Active
- Today's summary card: orders today, pending approvals, remarks today

#### Tab 2: Orders (`StaffOrdersTab`) — Split Screen
**Left Panel**:
- Search bar (order#, name, phone, product name)
- Toggle filters: All / Walk-In / Online (with icons)
- Total record count
- Category sub-tabs: All / Coffee / Tea / Juice (with counts)
- Scrollable order list: avatar (initial, colored by walk-in/online), order#, walk-in badge, VIP badge, customer name, items summary, status badge (colored), time; click to select

**Right Panel** (when order selected):
- Header: order#, status badge, walk-in badge, VIP badge, customer name
- Status dropdown (workflow-constrained):
  - received → received, designing
  - designing → designing, printing
  - printing+ → all statuses
  - Cancel options: direct cancel (received), request cancel (in-progress)
- `OrderDetailPanel` embedded:
  - Details & Remarks tab: status badges, customer info, items + totals, payment, staff, notes, remarks (add + view)
  - Invoice tab: branded invoice preview + PDF download
- Empty state: "Select an order" prompt

#### Tab 3: By Date (`StaffDateOrdersTab`)
- Orders grouped by date, descending
- Collapsible date sections: date label (Today/Yesterday/full date), order count + daily total
- Expanded view: order#, status, VIP, walk-in, customer, phone, items, total, payment, time, assigned staff

#### Tab 4: Cancel / Refund (`CancelRefundTab`) — Two sub-tabs

**Direct Cancel** (orders with `received` status):
- List of received orders; click to expand
- Per-item +/- cancel quantity controls
- Mandatory reason textarea
- Actions:
  - Full cancel: all items cancelled → status set to `cancelled`
  - Partial cancel: update item quantities, recalculate subtotal/custom_charges/total, order stays active
  - Log to ActivityLog + create Remark

**Request Cancellation** (orders in designing/printing/ready):
- Same UI pattern
- Submits `RefundRequest` (type: cancellation, status: pending)
- Updates order status to `cancel_requested`
- Creates a summary Remark

#### Tab 5: Remarks (`RemarksTab`)
- Search orders (number or name) with autocomplete dropdown
- Add remark form (textarea)
- Remarks history: order#, customer, content, staff name, timestamp

#### Tab 6: Inquiry (`InquiryReportTab`) — Shared with Admin
- 4-field search: Phone, Order#, Name, Email
- Results list → click for detailed report:
  - Branded gradient-header report card
  - Customer details (name, phone, email, payment)
  - Order items with totals
  - Activity timeline: chronological log entries with role badges and connecting line
  - Staff remarks
- "Download Inquiry PDF": A5 format, branded, includes all sections

#### Tab 7: Walk-In (`WalkInForm`)
- Customer details card: name* (required), phone, email, payment method
- Product selection grid grouped by category; click to add, shows quantity badge
- Order summary card: items with +/- quantity/remove, line totals, grand total
- "Place Order & Generate Invoice" button
- On creation:
  - Auto-generate `CUP-XXXX` (sequential)
  - `walk_in: true`, `assigned_staff_id/name`, `advance_paid: total`, `balance_due: 0`
  - Log to ActivityLog
  - Show `InvoiceModal`

### 8. Admin Page (`/admin`) — Role: admin only

Header: "Admin Panel" + "Manage your Cupify Cafe".

**9 Tabs**:

#### Tab 1: Dashboard (`AdminDashboardTab`)
- Sales Analytics: 4 cards — Today's, Weekly, Monthly, Total Revenue
- Order Analytics: status count grid (6 statuses, colored badges)
- Staff Analytics: total staff, active staff, total users
- Financial Analytics: total revenue, pending refunds, refunded amount, outstanding orders
- Real-Time Activity Feed: most recent 20 logs, role badge, action, timestamp

#### Tab 2: Orders (`AdminOrdersTab`)
- Full order table: checkbox, order#, customer, items, total, status dropdown, staff dropdown, date
- Bulk actions: select all, bulk status change
- Click row → detail panel on right (`OrderDetailPanel`)
- Staff assignment dropdown (populated from staff users)
- VIP badges, cancel_requested badges

#### Tab 3: By Date (`AdminDateOrdersTab`)
- Same pattern as `StaffDateOrdersTab` with admin-level controls
- Collapsible date groups
- Click order → detail panel on right

#### Tab 4: Products (`AdminProductsTab`)
- Add/Edit/Delete products via dialog form
- Fields: name, category (coffee/tea/juice), price, custom_cup_charge, description, is_available toggle
- Product table with edit/delete actions
- Logs each action to ActivityLog

#### Tab 5: Staff (`AdminInviteStaffTab`)
- Invite form: email + role (staff/admin) → `base44.users.inviteUser()`
- Success/error message
- Staff list table: name, email, role, active toggle, join date, change-role dropdown
- Admin cannot modify their own account here

#### Tab 6: Refunds (`AdminRefundsTab`)
- Pending requests list (orange themed): order#, type badge (refund/cancellation), customer name, reason, requested-by name and role, requested date
- Each pending item has **Approve** / **Reject** actions:
  - Approve → sets `RefundRequest.status = approved`, records `reviewed_by_id/name`, optional `admin_note`; if type is cancellation, updates linked `Order.status` to `cancelled`; if refund, records refunded `amount` and logs it
  - Reject → sets `status = rejected`, records reviewer and `admin_note`, order status reverts to its prior in-progress state
  - Every decision writes an `ActivityLog` entry
- Resolved requests history section below (approved/rejected), filterable by type and date, shown in muted/green/red styling matching status

#### Tab 7: Reports (`AdminReportsTab`)
- Date-range picker (today / this week / this month / custom range)
- Summary cards: total orders, total revenue, average order value, custom-cup orders %, VIP orders %
- Revenue breakdown chart by category (coffee/tea/juice) and by payment method
- Top-selling products table (name, quantity sold, revenue)
- Staff performance table: orders handled per staff member, revenue attributed
- Export button: download report as PDF/CSV

#### Tab 8: Logs (`AdminLogsTab`)
- Full activity log table: timestamp, user name, role badge, action, entity type, entity id
- Filters: by role, by entity type, by date range
- Search box (user name or action text)
- Read-only, paginated/scrollable list, most recent first

#### Tab 9: Inquiry
- Reuses the shared `InquiryReportTab` component described under Staff Tab 6, with identical search-by-phone/order/name/email flow, activity timeline, remarks, and PDF export — available to admins as well.

---

## 🧾 Shared Components

- **`InvoiceModal`**: branded invoice dialog — header with logo/name, order#, date, customer info, items table, subtotal/custom charges/total/advance/balance, footer note ("Thank you for choosing Cupify Cafe"); supports print/PDF download.
- **`OrderDetailPanel`**: reusable detail view used by both Staff and Admin order tabs (Details & Remarks tab + Invoice tab).
- **`CartItem`**: quantity stepper, remove button, custom cup indicator with charge shown separately from base price.
- **`MenuCard`**: reusable card for menu display, also reused (in simplified form) in Walk-In product picker.

---

## ⚙️ Key Business Logic Rules

- Order numbers: `CUP-XXXXXX` for standard/online/walk-in orders (sequential or timestamp-based depending on flow), `VIP-XXXXXX` for VIP orders.
- Advance payment: standard online orders collect 30% advance, balance due at pickup; VIP and walk-in orders are paid in full at placement (`balance_due: 0`).
- Status workflow is strictly forward-moving except for cancellation paths: `received → designing → printing → ready → delivered`, with `cancelled` and `cancel_requested` as side-branches.
- Only `received`-status orders can be **directly** cancelled by staff; orders already in production can only have cancellation **requested**, which requires admin approval via the Refunds tab.
- Every state-changing action (status change, cancellation, refund decision, product edit, staff invite/role change) writes an entry to `ActivityLog` for full auditability, surfaced in the Admin Dashboard feed and the Logs tab.
- Custom cup orders require explicit consent (`consent_own_image`) before checkout can complete; marketing consent is optional and tracked separately.

---

## 🔌 Integrations

- **Base44 BaaS**: entities/database, built-in `User` auth entity, `base44.users.inviteUser()` for staff/admin invitations, transactional email sending (order confirmation), file storage for custom cup image uploads.
- **Google OAuth**: login provider alongside email/password.
- **PDF generation**: client-side invoice and inquiry-report PDF export (A5 format for inquiry reports).

---

## 🔐 Multi-Staff Login Management

The app must support **multiple staff members, each with their own separate login** — never a single shared login for all staff. This is required so every action can be traced to the exact person who did it.

- **Onboarding**: Admin invites each staff member individually from `AdminInviteStaffTab` (email + role). Each invited staff member sets their own password via the invite email link and logs in with their own credentials.
- **Attribution**: Every write action (status change, remark, cancellation, walk-in order, refund request) stores `staff_id` + `staff_name` pulled from the currently logged-in user's session — never hardcoded or shared.
- **Access control**: Admin can toggle any staff account **active/inactive** at any time from `AdminInviteStaffTab`. An inactive account is immediately blocked from logging in (checked on every login attempt and on session refresh, not just at invite time).
- **Role change**: Admin can change a staff member's role (staff ↔ admin) from the same tab; the change takes effect on the user's next request (role is re-checked from the database, not cached indefinitely in the session).
- **Own-account protection**: An admin cannot deactivate or demote their own account (prevents accidental lockout).
- **Session expiry**: Sessions expire after a period of inactivity (e.g. 8 hours) and require re-login — prevents a logged-in device sitting unattended indefinitely at the counter.

## 🔴 Real-Time Order Locking & Multi-Staff Visibility

To prevent two staff members from working on the same order at the same time without knowing it:

- **Soft lock on open**: When a staff member opens an order in `StaffOrdersTab` / `AdminOrdersTab`, the order record gets `locked_by_staff_id`, `locked_by_staff_name`, and `locked_at` fields set.
- **Live indicator**: If a second staff member opens (or is already viewing) the same order, they immediately see a banner: "⚠️ {staff_name} is currently viewing/editing this order" — via a **realtime subscription** on the `Order` entity (not manual polling), so the indicator appears instantly without needing a page refresh.
- **Auto-release**: The lock clears automatically when the staff member closes the order panel, navigates away, or after a short inactivity timeout (e.g. 2 minutes), so a lock never gets stuck.
- **Non-blocking**: The lock is informational, not a hard block — a second staff member can still act if needed (e.g. the first staff walked away), but they see the warning first so accidental double-handling (like two staff both approving a cancellation) is avoided.
- **Dashboard-level realtime**: `StaffDashboard` and both order-list panels (Staff + Admin) subscribe to realtime updates on the `Order` entity, so status changes made by one staff member appear on every other staff member's screen instantly, without a manual refresh.

## ✨ Suggested Additional Features

- 🔔 In-app notification/sound alert when a new order comes in (staff-facing)
- 📊 Staff performance leaderboard — orders handled per staff member, shown on Admin Dashboard
- 🕐 Shift/attendance tracking for staff (clock-in/clock-out log)
- 💬 Internal notes/chat thread between staff and admin per order (separate from customer-facing remarks)
- 📦 Inventory/stock tracking on products (quantity on hand, low-stock warning banner)
- ⭐ Post-delivery customer feedback/rating, shown in Admin Reports
- 🎁 Loyalty points system for repeat customers (based on `customer_email`/`customer_phone` history)
- 🖨️ Auto-print to a receipt printer when a walk-in order is placed

**Note**: SMS OTP and SMS status notifications are intentionally **not included** in this build — they require a paid SMS gateway API. Email is used for all verification and notification instead (registration OTP, order confirmation, status updates).

---

## 🧱 Tech Stack Summary

- React (function components + hooks) + Vite
- Tailwind CSS with CSS custom properties for theming (light/dark)
- shadcn/ui component library
- Framer Motion for animation
- React Router for routing, with a `ProtectedRoute` wrapper and role-based redirects
- React Context for cart state (`orderContext.jsx`)
- Base44 SDK for backend (database entities, auth, email, storage)
