import { o as __toESM } from "../_runtime.mjs";
import { t as cn } from "./utils-C_uf36nf.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { p as require_jsx_runtime } from "../_libs/@radix-ui/react-checkbox+[...].mjs";
import { t as Button } from "./button-D_PHfu3x.mjs";
import { a as CardTitle, i as CardHeader, n as CardContent, t as Card } from "./card-BqLLulKB.mjs";
import { m as when, u as money } from "./format-ydPugZ1g.mjs";
import { E as updateOrderStatus, S as saveProduct, T as setStaffRole, _ as lockOrder, a as dashboardStats, d as listLogs, f as listProducts, g as listStaffOrders, h as listStaff, l as inviteStaff, n as assignStaff, o as deleteProduct, p as listRefunds, r as bulkUpdateStatus, s as getMyProfile, w as setStaffActive, x as reviewRefund, y as reportRange } from "./api-DUpluZ3_.mjs";
import { i as useQueryClient, n as useQuery, t as useMutation } from "../_libs/tanstack__react-query.mjs";
import { t as Protected } from "./protected-CvCgsFxJ.mjs";
import { i as TabsTrigger, n as TabsContent, r as TabsList, t as Tabs } from "./tabs-DQHqT2d-.mjs";
import { n as StatusBadge, t as Badge } from "./status-badge-CypCGZWh.mjs";
import { a as SelectValue, i as SelectTrigger, n as SelectContent, r as SelectItem, t as Select } from "./select-DLjEeGji.mjs";
import { a as DialogTitle, i as DialogHeader, n as DialogContent, t as Dialog } from "./invoice-modal-DmA2m8xY.mjs";
import { t as Input } from "./input-C8FVBVyT.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { n as InquiryTab, r as OrderDetailPanel, t as DateOrdersTab } from "./inquiry-tab-Dp5kp2Qt.mjs";
import { t as Checkbox } from "./checkbox-CQmSRhXi.mjs";
import { t as Label } from "./label-2J_LU4QX.mjs";
import { n as SwitchThumb, t as Switch$1 } from "../_libs/radix-ui__react-switch.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/admin-DpvWxFJm.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var STATUSES = [
	"received",
	"designing",
	"printing",
	"ready",
	"delivered",
	"cancelled"
];
function AdminDashboardTab() {
	const stats = useQuery({
		queryKey: ["dash"],
		queryFn: () => dashboardStats(),
		refetchInterval: 5e3
	});
	const logs = useQuery({
		queryKey: ["logs"],
		queryFn: () => listLogs()
	});
	const d = stats.data;
	if (!d) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "text-sm text-muted-foreground",
		children: "Loading analytics…"
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid gap-3 sm:grid-cols-4",
				children: [
					["Today", money(d.todayRevenue)],
					["This week", money(d.weekRevenue)],
					["This month", money(d.monthRevenue)],
					["Total", money(d.totalRevenue)]
				].map(([l, v]) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardHeader, {
					className: "pb-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs uppercase tracking-wide text-muted-foreground",
						children: l
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardTitle, {
						className: "text-xl tabular-nums",
						children: v
					})]
				}) }, l))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex flex-wrap gap-2",
				children: STATUSES.map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-2 rounded-lg border border-border px-3 py-2 text-sm",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatusBadge, { status: s }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "tabular-nums",
						children: d.byStatus[s] ?? 0
					})]
				}, s))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-3 sm:grid-cols-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardTitle, {
					className: "text-base",
					children: "Staff"
				}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardContent, {
					className: "text-sm",
					children: [
						d.staffCount,
						" total · ",
						d.activeStaff,
						" active · ",
						d.userCount,
						" users"
					]
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardTitle, {
					className: "text-base",
					children: "Financial"
				}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardContent, {
					className: "text-sm",
					children: [
						"Pending refunds ",
						d.pendingRefunds,
						" (",
						money(d.pendingRefundAmount),
						") · Refunded ",
						money(d.refundedAmount),
						" · Outstanding ",
						d.outstanding
					]
				})] })]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardTitle, {
				className: "text-base",
				children: "Live activity"
			}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardContent, {
				className: "max-h-72 space-y-2 overflow-y-auto text-sm",
				children: (logs.data ?? []).slice(0, 20).map((l) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap items-center gap-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
							variant: "secondary",
							children: l.userRole
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: l.action }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-xs text-muted-foreground",
							children: when(l.createdAt)
						})
					]
				}, l.id))
			})] })
		]
	});
}
var ALL = [
	"received",
	"designing",
	"printing",
	"ready",
	"delivered",
	"cancelled",
	"cancel_requested"
];
function AdminOrdersTab() {
	const qc = useQueryClient();
	const orders = useQuery({
		queryKey: ["staff-orders"],
		queryFn: () => listStaffOrders(),
		refetchInterval: 4e3
	});
	const staff = useQuery({
		queryKey: ["staff"],
		queryFn: () => listStaff()
	});
	const [selected, setSelected] = (0, import_react.useState)(null);
	const [checked, setChecked] = (0, import_react.useState)([]);
	const [bulk, setBulk] = (0, import_react.useState)("received");
	const current = (orders.data ?? []).find((o) => o.id === selected);
	const bulkMut = useMutation({
		mutationFn: () => bulkUpdateStatus({ data: {
			ids: checked,
			status: bulk
		} }),
		onSuccess() {
			setChecked([]);
			qc.invalidateQueries({ queryKey: ["staff-orders"] });
			toast.success("Updated");
		}
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "grid gap-4 lg:grid-cols-[1fr_340px]",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "overflow-x-auto",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mb-3 flex flex-wrap items-center gap-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						size: "sm",
						variant: "outline",
						onClick: () => setChecked((orders.data ?? []).map((o) => o.id)),
						children: "Select all"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
						value: bulk,
						onValueChange: (v) => setBulk(v),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, {
							className: "w-40",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, {})
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectContent, { children: ALL.map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
							value: s,
							children: s
						}, s)) })]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						size: "sm",
						disabled: !checked.length || bulkMut.isPending,
						onClick: () => bulkMut.mutate(),
						children: "Apply"
					})
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
				className: "w-full min-w-[720px] text-left text-sm",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
					className: "border-b text-muted-foreground",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", { className: "py-2" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", { children: "Order" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", { children: "Customer" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", { children: "Items" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", { children: "Total" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", { children: "Status" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", { children: "Staff" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", { children: "Date" })
					]
				}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: (orders.data ?? []).map((o) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
					className: "cursor-pointer border-b border-border/60 hover:bg-secondary/40",
					onClick: () => {
						setSelected(o.id);
						lockOrder({ data: { id: o.id } });
					},
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
							className: "py-2",
							onClick: (e) => e.stopPropagation(),
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Checkbox, {
								checked: checked.includes(o.id),
								onCheckedChange: (v) => setChecked((c) => v === true ? [...c, o.id] : c.filter((id) => id !== o.id))
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
							className: "py-2 font-medium",
							children: [
								o.orderNumber,
								" ",
								o.isVip && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
									variant: "accent",
									children: "VIP"
								}),
								o.status === "cancel_requested" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
									variant: "destructive",
									children: "Cancel"
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", { children: o.customerName }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
							className: "max-w-[140px] truncate",
							children: o.items.map((i) => i.productName).join(", ")
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
							className: "tabular-nums",
							children: money(o.total)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
							onClick: (e) => e.stopPropagation(),
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
								value: o.status,
								onValueChange: (v) => updateOrderStatus({ data: {
									id: o.id,
									status: v
								} }).then(() => qc.invalidateQueries({ queryKey: ["staff-orders"] })),
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, {
									className: "h-8 w-36",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, {})
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectContent, { children: ALL.map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
									value: s,
									children: s
								}, s)) })]
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
							onClick: (e) => e.stopPropagation(),
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
								value: o.assignedStaffId ?? "",
								onValueChange: (v) => {
									const s = (staff.data ?? []).find((x) => x.userId === v);
									if (!s) return;
									assignStaff({ data: {
										orderId: o.id,
										staffId: s.userId,
										staffName: s.displayName
									} }).then(() => qc.invalidateQueries({ queryKey: ["staff-orders"] }));
								},
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, {
									className: "h-8 w-36",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, { placeholder: "Assign" })
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectContent, { children: (staff.data ?? []).map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
									value: s.userId,
									children: s.displayName || s.email
								}, s.userId)) })]
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
							className: "whitespace-nowrap text-xs text-muted-foreground",
							children: when(o.createdAt)
						})
					]
				}, o.id)) })]
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "rounded-xl border border-border bg-card p-4",
			children: current ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(OrderDetailPanel, { order: current }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "py-10 text-center text-sm text-muted-foreground",
				children: "Select a row"
			})
		})]
	});
}
var Switch = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Switch$1, {
	className: cn("peer inline-flex h-6 w-11 shrink-0 cursor-pointer items-center rounded-full border-2 border-transparent transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring disabled:cursor-not-allowed disabled:opacity-50 data-[state=checked]:bg-primary data-[state=unchecked]:bg-input", className),
	...props,
	ref,
	children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SwitchThumb, { className: "pointer-events-none block h-5 w-5 rounded-full bg-background shadow-lg ring-0 transition-transform data-[state=checked]:translate-x-5 data-[state=unchecked]:translate-x-0" })
}));
Switch.displayName = Switch$1.displayName;
function AdminProductsTab() {
	const qc = useQueryClient();
	const products = useQuery({
		queryKey: ["products-all"],
		queryFn: () => listProducts()
	});
	const [edit, setEdit] = (0, import_react.useState)(null);
	const save = useMutation({
		mutationFn: () => saveProduct({ data: {
			id: edit?.id,
			name: edit?.name ?? "",
			category: edit?.category ?? "coffee",
			price: Number(edit?.price ?? 0),
			description: edit?.description ?? "",
			imageUrl: edit?.imageUrl ?? "",
			isAvailable: edit?.isAvailable !== false,
			customCupCharge: Number(edit?.customCupCharge ?? 0)
		} }),
		onSuccess() {
			setEdit(null);
			qc.invalidateQueries({ queryKey: ["products-all"] });
			qc.invalidateQueries({ queryKey: ["products-available"] });
			toast.success("Saved");
		}
	});
	const del = useMutation({
		mutationFn: (id) => deleteProduct({ data: { id } }),
		onSuccess() {
			qc.invalidateQueries({ queryKey: ["products-all"] });
			toast.success("Deleted");
		}
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
			className: "mb-4",
			onClick: () => setEdit({
				name: "",
				category: "coffee",
				price: 0,
				customCupCharge: 80,
				isAvailable: true,
				description: "",
				imageUrl: ""
			}),
			children: "Add product"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "overflow-x-auto",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
				className: "w-full text-left text-sm",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
					className: "border-b text-muted-foreground",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
							className: "py-2",
							children: "Name"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", { children: "Category" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", { children: "Price" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", { children: "Custom" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", { children: "Available" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {})
					]
				}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: (products.data ?? []).map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
					className: "border-b border-border/60",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
							className: "py-2",
							children: p.name
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
							className: "capitalize",
							children: p.category
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
							className: "tabular-nums",
							children: money(p.price)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
							className: "tabular-nums",
							children: money(p.customCupCharge)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", { children: p.isAvailable ? "Yes" : "No" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
							className: "space-x-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								size: "sm",
								variant: "outline",
								onClick: () => setEdit(p),
								children: "Edit"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								size: "sm",
								variant: "destructive",
								onClick: () => del.mutate(p.id),
								children: "Delete"
							})]
						})
					]
				}, p.id)) })]
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
			open: Boolean(edit),
			onOpenChange: (o) => !o && setEdit(null),
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, { children: edit?.id ? "Edit product" : "New product" }) }), edit && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "space-y-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-1.5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Name" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							value: edit.name ?? "",
							onChange: (e) => setEdit({
								...edit,
								name: e.target.value
							})
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-1.5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Category" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
							value: edit.category,
							onValueChange: (v) => setEdit({
								...edit,
								category: v
							}),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, {}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SelectContent, { children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
									value: "coffee",
									children: "Coffee"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
									value: "tea",
									children: "Tea"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
									value: "juice",
									children: "Juice"
								})
							] })]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-1.5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Price" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							type: "number",
							value: edit.price ?? 0,
							onChange: (e) => setEdit({
								...edit,
								price: Number(e.target.value)
							})
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-1.5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Custom cup charge" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							type: "number",
							value: edit.customCupCharge ?? 0,
							onChange: (e) => setEdit({
								...edit,
								customCupCharge: Number(e.target.value)
							})
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-1.5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Description" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							value: edit.description ?? "",
							onChange: (e) => setEdit({
								...edit,
								description: e.target.value
							})
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "flex items-center gap-2 text-sm",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Switch, {
							checked: edit.isAvailable !== false,
							onCheckedChange: (v) => setEdit({
								...edit,
								isAvailable: v
							})
						}), "Available"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						className: "w-full",
						disabled: save.isPending,
						onClick: () => save.mutate(),
						children: "Save"
					})
				]
			})] })
		})
	] });
}
function AdminStaffTab() {
	const qc = useQueryClient();
	const me = useQuery({
		queryKey: ["me"],
		queryFn: () => getMyProfile()
	});
	const staff = useQuery({
		queryKey: ["staff"],
		queryFn: () => listStaff()
	});
	const [email, setEmail] = (0, import_react.useState)("");
	const [role, setRole] = (0, import_react.useState)("staff");
	const invite = useMutation({
		mutationFn: () => inviteStaff({ data: {
			email,
			role
		} }),
		onSuccess() {
			setEmail("");
			toast.success("Invite recorded — they get staff access on first sign-in");
			qc.invalidateQueries({ queryKey: ["staff"] });
		},
		onError(e) {
			toast.error(e instanceof Error ? e.message : "Failed");
		}
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-6",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
			className: "flex flex-wrap items-end gap-2",
			onSubmit: (e) => {
				e.preventDefault();
				invite.mutate();
			},
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "space-y-1.5",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Email" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						type: "email",
						value: email,
						onChange: (e) => setEmail(e.target.value),
						required: true
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
					value: role,
					onValueChange: (v) => setRole(v),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, {
						className: "w-32",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, {})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SelectContent, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
						value: "staff",
						children: "Staff"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
						value: "admin",
						children: "Admin"
					})] })]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					type: "submit",
					disabled: invite.isPending,
					children: "Invite"
				})
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "overflow-x-auto",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
				className: "w-full text-left text-sm",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
					className: "border-b text-muted-foreground",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
							className: "py-2",
							children: "Name"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", { children: "Email" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", { children: "Role" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", { children: "Active" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", { children: "Joined" })
					]
				}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: (staff.data ?? []).map((s) => {
					const mine = s.userId === me.data?.userId;
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
						className: "border-b border-border/60",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "py-2",
								children: s.displayName || "—"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", { children: s.email }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
								value: s.role,
								disabled: mine,
								onValueChange: (v) => setStaffRole({ data: {
									userId: s.userId,
									role: v
								} }).then(() => qc.invalidateQueries({ queryKey: ["staff"] })),
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, {
									className: "h-8 w-28",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, {})
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SelectContent, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
									value: "staff",
									children: "Staff"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
									value: "admin",
									children: "Admin"
								})] })]
							}) }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Switch, {
								checked: s.isActive,
								disabled: mine,
								onCheckedChange: (v) => setStaffActive({ data: {
									userId: s.userId,
									isActive: v
								} }).then(() => qc.invalidateQueries({ queryKey: ["staff"] }))
							}) }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "text-xs text-muted-foreground",
								children: when(s.createdAt)
							})
						]
					}, s.userId);
				}) })]
			})
		})]
	});
}
function AdminRefundsTab() {
	const qc = useQueryClient();
	const refunds = useQuery({
		queryKey: ["refunds"],
		queryFn: () => listRefunds()
	});
	const [note, setNote] = (0, import_react.useState)("");
	const [filter, setFilter] = (0, import_react.useState)("all");
	const pending = (refunds.data ?? []).filter((r) => r.status === "pending");
	const resolved = (refunds.data ?? []).filter((r) => r.status !== "pending" && (filter === "all" || r.requestType === filter));
	const mut = useMutation({
		mutationFn: (input) => reviewRefund({ data: {
			...input,
			note
		} }),
		onSuccess() {
			setNote("");
			qc.invalidateQueries({ queryKey: ["refunds"] });
			qc.invalidateQueries({ queryKey: ["staff-orders"] });
			toast.success("Recorded");
		},
		onError(e) {
			toast.error(e instanceof Error ? e.message : "Failed");
		}
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-8",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "space-y-3",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
					className: "font-display text-lg",
					children: "Pending"
				}),
				pending.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-muted-foreground",
					children: "No pending requests."
				}),
				pending.map((r) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "rounded-xl border border-accent/40 bg-accent/10 p-4 text-sm",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex flex-wrap items-center gap-2",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "font-medium",
									children: r.orderNumber
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, { children: r.requestType }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: r.customerName }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "tabular-nums",
									children: money(r.amount)
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2",
							children: r.reason
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-1 text-xs text-muted-foreground",
							children: [
								r.requestedByName,
								" · ",
								when(r.createdAt)
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							className: "mt-3",
							placeholder: "Admin note",
							value: note,
							onChange: (e) => setNote(e.target.value)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-2 flex gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								size: "sm",
								onClick: () => mut.mutate({
									id: r.id,
									approve: true
								}),
								children: "Approve"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								size: "sm",
								variant: "destructive",
								onClick: () => mut.mutate({
									id: r.id,
									approve: false
								}),
								children: "Reject"
							})]
						})
					]
				}, r.id))
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mb-3 flex items-center justify-between",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
				className: "font-display text-lg",
				children: "History"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tabs, {
				value: filter,
				onValueChange: (v) => setFilter(v),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TabsList, { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsTrigger, {
						value: "all",
						children: "All"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsTrigger, {
						value: "refund",
						children: "Refund"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsTrigger, {
						value: "cancellation",
						children: "Cancel"
					})
				] })
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "space-y-2",
			children: resolved.map((r) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "rounded-lg border border-border p-3 text-sm",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap gap-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "font-medium",
							children: r.orderNumber
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
							variant: r.status === "approved" ? "default" : "destructive",
							children: r.status
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
							variant: "secondary",
							children: r.requestType
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-xs text-muted-foreground",
					children: [
						r.reviewedByName,
						" · ",
						when(r.createdAt)
					]
				})]
			}, r.id))
		})] })]
	});
}
function iso(d) {
	return d.toISOString().slice(0, 10);
}
function AdminReportsTab() {
	const today = iso(/* @__PURE__ */ new Date());
	const [from, setFrom] = (0, import_react.useState)(today);
	const [to, setTo] = (0, import_react.useState)(today);
	const run = useMutation({ mutationFn: () => reportRange({ data: {
		from,
		to
	} }) });
	const d = run.data;
	const preset = (kind) => {
		const now = /* @__PURE__ */ new Date();
		if (kind === "today") {
			setFrom(today);
			setTo(today);
		} else if (kind === "week") {
			const s = new Date(now);
			s.setDate(now.getDate() - now.getDay());
			setFrom(iso(s));
			setTo(today);
		} else {
			setFrom(`${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, "0")}-01`);
			setTo(today);
		}
	};
	const csv = (0, import_react.useMemo)(() => {
		if (!d) return "";
		return [[
			"Product",
			"Qty",
			"Revenue"
		], ...d.top.map((p) => [
			p.name,
			String(p.qty),
			String(p.revenue)
		])].map((r) => r.join(",")).join("\n");
	}, [d]);
	function download() {
		const blob = new Blob([csv], { type: "text/csv" });
		const a = document.createElement("a");
		a.href = URL.createObjectURL(blob);
		a.download = `cupify-report-${from}-${to}.csv`;
		a.click();
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-4",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex flex-wrap items-end gap-2",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					size: "sm",
					variant: "outline",
					onClick: () => preset("today"),
					children: "Today"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					size: "sm",
					variant: "outline",
					onClick: () => preset("week"),
					children: "This week"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					size: "sm",
					variant: "outline",
					onClick: () => preset("month"),
					children: "This month"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					type: "date",
					className: "w-40",
					value: from,
					onChange: (e) => setFrom(e.target.value)
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					type: "date",
					className: "w-40",
					value: to,
					onChange: (e) => setTo(e.target.value)
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					onClick: () => run.mutate(),
					children: "Run"
				}),
				d && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "outline",
					onClick: download,
					children: "Export CSV"
				})
			]
		}), d && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid gap-3 sm:grid-cols-5",
				children: [
					["Orders", String(d.totalOrders)],
					["Revenue", money(d.revenue)],
					["Average", money(d.average)],
					["Custom cups", `${d.customPct.toFixed(0)}%`],
					["VIP", `${d.vipPct.toFixed(0)}%`]
				].map(([l, v]) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardHeader, {
					className: "pb-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs text-muted-foreground",
						children: l
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardTitle, {
						className: "text-lg tabular-nums",
						children: v
					})]
				}) }, l))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-4 md:grid-cols-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardTitle, {
					className: "text-base",
					children: "By category"
				}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardContent, {
					className: "space-y-1 text-sm",
					children: Object.entries(d.byCat).map(([k, v]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex justify-between capitalize",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: k }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "tabular-nums",
							children: money(v)
						})]
					}, k))
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardTitle, {
					className: "text-base",
					children: "By payment"
				}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardContent, {
					className: "space-y-1 text-sm",
					children: Object.entries(d.byPay).map(([k, v]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex justify-between capitalize",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: k }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "tabular-nums",
							children: money(v)
						})]
					}, k))
				})] })]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardTitle, {
				className: "text-base",
				children: "Top products"
			}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardContent, {
				className: "text-sm",
				children: d.top.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex justify-between py-1",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
						p.name,
						" × ",
						p.qty
					] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "tabular-nums",
						children: money(p.revenue)
					})]
				}, p.name))
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardTitle, {
				className: "text-base",
				children: "Staff"
			}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardContent, {
				className: "text-sm",
				children: [d.staff.map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex justify-between py-1",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
						s.name,
						" · ",
						s.orders,
						" orders"
					] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "tabular-nums",
						children: money(s.revenue)
					})]
				}, s.name)), d.staff.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-muted-foreground",
					children: "No assigned orders in range."
				})]
			})] })
		] })]
	});
}
function AdminLogsTab() {
	const logs = useQuery({
		queryKey: ["logs"],
		queryFn: () => listLogs()
	});
	const [q, setQ] = (0, import_react.useState)("");
	const [role, setRole] = (0, import_react.useState)("all");
	const [entity, setEntity] = (0, import_react.useState)("all");
	const rows = (0, import_react.useMemo)(() => {
		return (logs.data ?? []).filter((l) => {
			if (role !== "all" && l.userRole !== role) return false;
			if (entity !== "all" && l.entityType !== entity) return false;
			const s = q.trim().toLowerCase();
			if (s && !`${l.userName} ${l.action}`.toLowerCase().includes(s)) return false;
			return true;
		});
	}, [
		logs.data,
		q,
		role,
		entity
	]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-3",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex flex-wrap gap-2",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					placeholder: "Search user or action",
					value: q,
					onChange: (e) => setQ(e.target.value),
					className: "max-w-xs"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
					value: role,
					onValueChange: setRole,
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, {
						className: "w-32",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, {})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SelectContent, { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
							value: "all",
							children: "All roles"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
							value: "admin",
							children: "Admin"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
							value: "staff",
							children: "Staff"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
							value: "customer",
							children: "Customer"
						})
					] })]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
					value: entity,
					onValueChange: setEntity,
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, {
						className: "w-32",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, {})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SelectContent, { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
							value: "all",
							children: "All entities"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
							value: "order",
							children: "Order"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
							value: "product",
							children: "Product"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
							value: "user",
							children: "User"
						})
					] })]
				})
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "max-h-[70vh] overflow-y-auto",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
				className: "w-full text-left text-sm",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
					className: "border-b text-muted-foreground",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
							className: "py-2",
							children: "When"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", { children: "Who" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", { children: "Action" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", { children: "Entity" })
					]
				}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: rows.map((l) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
					className: "border-b border-border/50",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
							className: "py-2 whitespace-nowrap text-xs",
							children: when(l.createdAt)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", { children: [
							l.userName,
							" ",
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
								variant: "secondary",
								children: l.userRole
							})
						] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", { children: l.action }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
							className: "text-xs text-muted-foreground",
							children: [
								l.entityType,
								" ",
								l.entityId
							]
						})
					]
				}, l.id)) })]
			})
		})]
	});
}
function AdminRoute() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Protected, {
		roles: ["admin"],
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AdminPage, {})
	});
}
function AdminPage() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "mx-auto max-w-6xl px-4 py-8",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "font-display text-3xl font-semibold",
				children: "Admin panel"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 text-sm text-muted-foreground",
				children: "Manage your Cupify Cafe."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Tabs, {
				defaultValue: "dashboard",
				className: "mt-6",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TabsList, {
						className: "h-auto w-full flex-wrap justify-start overflow-x-auto",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsTrigger, {
								value: "dashboard",
								children: "Dashboard"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsTrigger, {
								value: "orders",
								children: "Orders"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsTrigger, {
								value: "date",
								children: "By date"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsTrigger, {
								value: "products",
								children: "Products"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsTrigger, {
								value: "staff",
								children: "Staff"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsTrigger, {
								value: "refunds",
								children: "Refunds"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsTrigger, {
								value: "reports",
								children: "Reports"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsTrigger, {
								value: "logs",
								children: "Logs"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsTrigger, {
								value: "inquiry",
								children: "Inquiry"
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsContent, {
						value: "dashboard",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AdminDashboardTab, {})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsContent, {
						value: "orders",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AdminOrdersTab, {})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsContent, {
						value: "date",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DateOrdersTab, { admin: true })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsContent, {
						value: "products",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AdminProductsTab, {})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsContent, {
						value: "staff",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AdminStaffTab, {})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsContent, {
						value: "refunds",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AdminRefundsTab, {})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsContent, {
						value: "reports",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AdminReportsTab, {})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsContent, {
						value: "logs",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AdminLogsTab, {})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsContent, {
						value: "inquiry",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(InquiryTab, {})
					})
				]
			})
		]
	});
}
//#endregion
export { AdminRoute as component };
