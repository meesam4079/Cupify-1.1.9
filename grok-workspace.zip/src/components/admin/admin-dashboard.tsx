import { useQuery } from "@tanstack/react-query";
import { dashboardStats, listLogs } from "@/lib/cupify/api";
import { money, when } from "@/lib/cupify/format";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { StatusBadge } from "@/components/shared/status-badge";
import type { OrderStatus } from "@/lib/cupify/types";

const STATUSES: OrderStatus[] = ["received", "designing", "printing", "ready", "delivered", "cancelled"];

export function AdminDashboardTab() {
  const stats = useQuery({ queryKey: ["dash"], queryFn: () => dashboardStats(), refetchInterval: 5000 });
  const logs = useQuery({ queryKey: ["logs"], queryFn: () => listLogs() });
  const d = stats.data;
  if (!d) return <p className="text-sm text-muted-foreground">Loading analytics…</p>;
  return (
    <div className="space-y-6">
      <div className="grid gap-3 sm:grid-cols-4">
        {[
          ["Today", money(d.todayRevenue)],
          ["This week", money(d.weekRevenue)],
          ["This month", money(d.monthRevenue)],
          ["Total", money(d.totalRevenue)],
        ].map(([l, v]) => (
          <Card key={l}>
            <CardHeader className="pb-2">
              <p className="text-xs uppercase tracking-wide text-muted-foreground">{l}</p>
              <CardTitle className="text-xl tabular-nums">{v}</CardTitle>
            </CardHeader>
          </Card>
        ))}
      </div>
      <div className="flex flex-wrap gap-2">
        {STATUSES.map((s) => (
          <div key={s} className="flex items-center gap-2 rounded-lg border border-border px-3 py-2 text-sm">
            <StatusBadge status={s} />
            <span className="tabular-nums">{d.byStatus[s] ?? 0}</span>
          </div>
        ))}
      </div>
      <div className="grid gap-3 sm:grid-cols-3">
        <Card>
          <CardHeader>
            <CardTitle className="text-base">Staff</CardTitle>
          </CardHeader>
          <CardContent className="text-sm">
            {d.staffCount} total · {d.activeStaff} active · {d.userCount} users
          </CardContent>
        </Card>
        <Card>
          <CardHeader>
            <CardTitle className="text-base">Financial</CardTitle>
          </CardHeader>
          <CardContent className="text-sm">
            Pending refunds {d.pendingRefunds} ({money(d.pendingRefundAmount)}) · Refunded {money(d.refundedAmount)} · Outstanding {d.outstanding}
          </CardContent>
        </Card>
      </div>
      <Card>
        <CardHeader>
          <CardTitle className="text-base">Live activity</CardTitle>
        </CardHeader>
        <CardContent className="max-h-72 space-y-2 overflow-y-auto text-sm">
          {(logs.data ?? []).slice(0, 20).map((l) => (
            <div key={l.id} className="flex flex-wrap items-center gap-2">
              <Badge variant="secondary">{l.userRole}</Badge>
              <span>{l.action}</span>
              <span className="text-xs text-muted-foreground">{when(l.createdAt)}</span>
            </div>
          ))}
        </CardContent>
      </Card>
    </div>
  );
}
