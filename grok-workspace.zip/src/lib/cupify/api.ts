import { createServerFn } from "@tanstack/react-start";
import { getSql } from "@/lib/db";
import { authMiddleware } from "@/lib/auth/middleware";
import type { Sql } from "@/lib/db";
import {
  ADVANCE_RATE,
  LOCK_MS,
  VIP_SURCHARGE,
  type Order,
  type OrderItem,
  type OrderStatus,
  type PaymentMethod,
  type PlaceOrderInput,
  type ProductCategory,
  type Profile,
  type UserRole,
} from "./types";
import { mapLog, mapOrder, mapProduct, mapProfile, mapRefund, mapRemark } from "./mappers";
import { cartTotals, padOrder } from "./format";

type AuthCtx = { userId: string };

async function authUser(sql: Sql, userId: string) {
  const rows = await sql.query<{ id: string; name: string; email: string }>(
    `select id, name, email from "user" where id = $1`,
    [userId],
  );
  return rows[0] ?? { id: userId, name: "Guest", email: "" };
}

async function ensureProfile(sql: Sql, userId: string): Promise<Profile> {
  const auth = await authUser(sql, userId);
  const existing = await sql.query<Record<string, unknown>>(
    `select * from profiles where user_id = $1`,
    [userId],
  );
  if (existing[0]) {
    const p = mapProfile(existing[0]);
    if ((!p.email && auth.email) || (!p.displayName && auth.name)) {
      await sql.query(
        `update profiles set email = coalesce(nullif(email, ''), $2), display_name = coalesce(nullif(display_name, ''), $3) where user_id = $1`,
        [userId, auth.email, auth.name],
      );
      return { ...p, email: p.email || auth.email, displayName: p.displayName || auth.name };
    }
    return p;
  }

  const email = (auth.email || "").toLowerCase();
  const invite = email
    ? await sql.query<Record<string, unknown>>(
        `select * from staff_invites where lower(email) = $1 limit 1`,
        [email],
      )
    : [];

  const admins = await sql.query<{ c: number }>(`select count(*)::int as c from profiles where role = 'admin'`);
  let role: UserRole = "user";
  if (invite[0]) role = (String(invite[0].role) as UserRole) || "staff";
  else if ((admins[0]?.c ?? 0) === 0) role = "admin";

  await sql.query(
    `insert into profiles (user_id, email, display_name, role, is_active)
     values ($1, $2, $3, $4, true)
     on conflict (user_id) do nothing`,
    [userId, auth.email, auth.name || "Guest", role],
  );
  if (invite[0]) {
    await sql.query(`delete from staff_invites where id = $1`, [invite[0].id]);
  }
  const created = await sql.query<Record<string, unknown>>(
    `select * from profiles where user_id = $1`,
    [userId],
  );
  return mapProfile(created[0] ?? { user_id: userId, email: auth.email, display_name: auth.name, role, is_active: true });
}

async function requireStaff(sql: Sql, userId: string) {
  const p = await ensureProfile(sql, userId);
  if (!p.isActive) throw new Error("Account deactivated");
  if (p.role !== "staff" && p.role !== "admin") throw new Error("Forbidden");
  return p;
}

async function requireAdmin(sql: Sql, userId: string) {
  const p = await ensureProfile(sql, userId);
  if (!p.isActive) throw new Error("Account deactivated");
  if (p.role !== "admin") throw new Error("Forbidden");
  return p;
}

async function log(sql: Sql, p: Profile, action: string, entityType: string, entityId: string) {
  await sql.query(
    `insert into activity_logs (user_name, user_role, action, entity_type, entity_id) values ($1,$2,$3,$4,$5)`,
    [p.displayName || p.email, p.role === "user" ? "customer" : p.role, action, entityType, entityId],
  );
}

async function nextNumber(sql: Sql, kind: "cup" | "vip") {
  await sql.query(`insert into counters (name, value) values ($1, 0) on conflict (name) do nothing`, [kind]);
  const rows = await sql.query<{ value: number }>(
    `update counters set value = value + 1 where name = $1 returning value`,
    [kind],
  );
  return padOrder(kind === "vip" ? "VIP" : "CUP", rows[0]?.value ?? 1);
}

function lockOpen(lockedAt: string | null) {
  if (!lockedAt) return true;
  const t = new Date(lockedAt).getTime();
  if (!Number.isFinite(t)) return true;
  return Date.now() - t > LOCK_MS;
}

export const getMyProfile = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .handler(async ({ context }: { context: AuthCtx }) => {
    const sql = await getSql();
    return ensureProfile(sql, context.userId);
  });

export const listProducts = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .handler(async ({ context }: { context: AuthCtx }) => {
    const sql = await getSql();
    await requireAdmin(sql, context.userId);
    const rows = await sql.query<Record<string, unknown>>(`select * from products order by category, name`);
    return rows.map(mapProduct);
  });

export const listAvailableProducts = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .handler(async () => {
    const sql = await getSql();
    const rows = await sql.query<Record<string, unknown>>(
      `select * from products where is_available = true order by category, name`,
    );
    return rows.map(mapProduct);
  });

export const placeOrder = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: PlaceOrderInput) => input)
  .handler(async ({ context, data }: { context: AuthCtx; data: PlaceOrderInput }) => {
    const sql = await getSql();
    const profile = await ensureProfile(sql, context.userId);
    if (!profile.isActive) throw new Error("Account deactivated");
    if (!data.items?.length) throw new Error("Cart is empty");
    if (!data.customerName?.trim()) throw new Error("Name is required");
    const hasCustom = data.items.some((i) => i.cupType === "custom");
    if (hasCustom && !data.consentOwnImage) throw new Error("Image rights consent is required for custom cups");

    const totals = cartTotals(data.items);
    const isVip = Boolean(data.isVip);
    const walkIn = Boolean(data.walkIn);
    const vipExtra = isVip ? VIP_SURCHARGE : 0;
    const total = totals.total + vipExtra;
    const customCharges = totals.customCharges + vipExtra;
    const paidInFull = isVip || walkIn;
    const advancePaid = paidInFull ? total : Math.round(total * ADVANCE_RATE);
    const balanceDue = total - advancePaid;
    const number = await nextNumber(sql, isVip ? "vip" : "cup");
    const assignedId = walkIn ? profile.userId : null;
    const assignedName = walkIn ? profile.displayName : null;

    const rows = await sql.query<Record<string, unknown>>(
      `insert into orders (
        user_id, order_number, customer_name, customer_email, customer_phone, items,
        subtotal, custom_charges, total, advance_paid, balance_due, is_vip, walk_in, status,
        consent_own_image, consent_marketing, assigned_staff_id, assigned_staff_name, payment_method, notes
      ) values ($1,$2,$3,$4,$5,$6::jsonb,$7,$8,$9,$10,$11,$12,$13,'received',$14,$15,$16,$17,$18,$19)
      returning *`,
      [
        walkIn ? null : context.userId,
        number,
        data.customerName.trim(),
        data.customerEmail?.trim() ?? "",
        data.customerPhone?.trim() ?? "",
        JSON.stringify(data.items),
        totals.subtotal,
        customCharges,
        total,
        advancePaid,
        balanceDue,
        isVip,
        walkIn,
        Boolean(data.consentOwnImage),
        Boolean(data.consentMarketing),
        assignedId,
        assignedName,
        data.paymentMethod ?? "cash",
        data.notes ?? "",
      ],
    );
    const order = mapOrder(rows[0]);
    await log(sql, profile, `Placed order ${order.orderNumber}`, "order", String(order.id));
    return order;
  });

export const listMyOrders = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .handler(async ({ context }: { context: AuthCtx }) => {
    const sql = await getSql();
    const rows = await sql.query<Record<string, unknown>>(
      `select * from orders where user_id = $1 order by created_at desc`,
      [context.userId],
    );
    return rows.map(mapOrder);
  });

export const getOrderByNumber = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: { orderNumber: string }) => input)
  .handler(async ({ data }: { data: { orderNumber: string } }) => {
    const sql = await getSql();
    const rows = await sql.query<Record<string, unknown>>(
      `select * from orders where lower(order_number) = lower($1) limit 1`,
      [data.orderNumber.trim()],
    );
    return rows[0] ? mapOrder(rows[0]) : null;
  });

export const searchInvoices = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: { q: string }) => input)
  .handler(async ({ context, data }: { context: AuthCtx; data: { q: string } }) => {
    const sql = await getSql();
    const profile = await ensureProfile(sql, context.userId);
    const q = `%${data.q.trim()}%`;
    const staff = profile.role === "staff" || profile.role === "admin";
    const rows = await sql.query<Record<string, unknown>>(
      staff
        ? `select * from orders
           where order_number ilike $1 or customer_name ilike $1 or customer_email ilike $1 or customer_phone ilike $1
           order by created_at desc limit 40`
        : `select * from orders
           where user_id = $2 and (order_number ilike $1 or customer_name ilike $1 or customer_email ilike $1 or customer_phone ilike $1)
           order by created_at desc limit 40`,
      staff ? [q] : [q, context.userId],
    );
    return rows.map(mapOrder);
  });

export const listStaffOrders = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .handler(async ({ context }: { context: AuthCtx }) => {
    const sql = await getSql();
    await requireStaff(sql, context.userId);
    const rows = await sql.query<Record<string, unknown>>(`select * from orders order by created_at desc`);
    return rows.map(mapOrder);
  });

export const updateOrderStatus = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: { id: number; status: OrderStatus }) => input)
  .handler(async ({ context, data }: { context: AuthCtx; data: { id: number; status: OrderStatus } }) => {
    const sql = await getSql();
    const staff = await requireStaff(sql, context.userId);
    const current = await sql.query<Record<string, unknown>>(`select * from orders where id = $1`, [data.id]);
    if (!current[0]) throw new Error("Order not found");
    const order = mapOrder(current[0]);
    await sql.query(
      `update orders set status = $2, previous_status = $3, updated_at = now() where id = $1`,
      [data.id, data.status, order.status],
    );
    await log(sql, staff, `Status ${order.orderNumber}: ${order.status} → ${data.status}`, "order", String(data.id));
    const next = await sql.query<Record<string, unknown>>(`select * from orders where id = $1`, [data.id]);
    return mapOrder(next[0]);
  });

export const bulkUpdateStatus = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: { ids: number[]; status: OrderStatus }) => input)
  .handler(async ({ context, data }: { context: AuthCtx; data: { ids: number[]; status: OrderStatus } }) => {
    const sql = await getSql();
    const staff = await requireAdmin(sql, context.userId);
    if (!data.ids.length) return { count: 0 };
    const placeholders = data.ids.map((_, i) => `$${i + 2}`).join(",");
    await sql.query(
      `update orders set previous_status = status, status = $1, updated_at = now() where id in (${placeholders})`,
      [data.status, ...data.ids],
    );
    await log(sql, staff, `Bulk status → ${data.status} (${data.ids.length})`, "order", data.ids.join(","));
    return { count: data.ids.length };
  });

export const assignStaff = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: { orderId: number; staffId: string; staffName: string }) => input)
  .handler(async ({ context, data }) => {
    const sql = await getSql();
    const admin = await requireAdmin(sql, context.userId);
    await sql.query(
      `update orders set assigned_staff_id = $2, assigned_staff_name = $3, updated_at = now() where id = $1`,
      [data.orderId, data.staffId, data.staffName],
    );
    await log(sql, admin, `Assigned order ${data.orderId} to ${data.staffName}`, "order", String(data.orderId));
    return { ok: true };
  });

export const lockOrder = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: { id: number | null }) => input)
  .handler(async ({ context, data }: { context: AuthCtx; data: { id: number | null } }) => {
    const sql = await getSql();
    const staff = await requireStaff(sql, context.userId);
    await sql.query(
      `update orders set locked_by_staff_id = null, locked_by_staff_name = null, locked_at = null
       where locked_by_staff_id = $1`,
      [staff.userId],
    );
    if (data.id) {
      await sql.query(
        `update orders set locked_by_staff_id = $2, locked_by_staff_name = $3, locked_at = now() where id = $1`,
        [data.id, staff.userId, staff.displayName],
      );
    }
    return { ok: true };
  });

export const addRemark = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: { orderId: number; content: string }) => input)
  .handler(async ({ context, data }) => {
    const sql = await getSql();
    const staff = await requireStaff(sql, context.userId);
    const orderRows = await sql.query<Record<string, unknown>>(`select * from orders where id = $1`, [data.orderId]);
    if (!orderRows[0]) throw new Error("Order not found");
    const order = mapOrder(orderRows[0]);
    const rows = await sql.query<Record<string, unknown>>(
      `insert into remarks (order_id, order_number, customer_name, staff_id, staff_name, content)
       values ($1,$2,$3,$4,$5,$6) returning *`,
      [order.id, order.orderNumber, order.customerName, staff.userId, staff.displayName, data.content.trim()],
    );
    await log(sql, staff, `Remark on ${order.orderNumber}`, "order", String(order.id));
    return mapRemark(rows[0]);
  });

export const listRemarks = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: { orderId?: number } = {}) => input)
  .handler(async ({ context, data }) => {
    const sql = await getSql();
    await requireStaff(sql, context.userId);
    const rows = data.orderId
      ? await sql.query<Record<string, unknown>>(`select * from remarks where order_id = $1 order by created_at desc`, [
          data.orderId,
        ])
      : await sql.query<Record<string, unknown>>(`select * from remarks order by created_at desc limit 80`);
    return rows.map(mapRemark);
  });

export const listLogs = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .handler(async ({ context }: { context: AuthCtx }) => {
    const sql = await getSql();
    await requireStaff(sql, context.userId);
    const rows = await sql.query<Record<string, unknown>>(`select * from activity_logs order by created_at desc limit 200`);
    return rows.map(mapLog);
  });

export const cancelItems = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: { orderId: number; quantities: Record<number, number>; reason: string; full: boolean }) => input)
  .handler(async ({ context, data }) => {
    const sql = await getSql();
    const staff = await requireStaff(sql, context.userId);
    const rows = await sql.query<Record<string, unknown>>(`select * from orders where id = $1`, [data.orderId]);
    if (!rows[0]) throw new Error("Order not found");
    const order = mapOrder(rows[0]);
    if (order.status !== "received") throw new Error("Only received orders can be cancelled directly");
    if (!data.reason.trim()) throw new Error("Reason is required");

    let nextItems: OrderItem[];
    let status: OrderStatus = order.status;
    if (data.full) {
      nextItems = order.items.map((i) => ({ ...i, quantity: 0 }));
      status = "cancelled";
    } else {
      nextItems = order.items
        .map((i, idx) => ({ ...i, quantity: Math.max(0, i.quantity - (data.quantities[idx] ?? 0)) }))
        .filter((i) => i.quantity > 0);
      if (!nextItems.length) status = "cancelled";
    }
    const totals = cartTotals(nextItems);
    await sql.query(
      `update orders set items = $2::jsonb, subtotal = $3, custom_charges = $4, total = $5,
        advance_paid = $6, balance_due = $7, status = $8, previous_status = $9, updated_at = now()
       where id = $1`,
      [
        order.id,
        JSON.stringify(nextItems),
        totals.subtotal,
        totals.customCharges,
        totals.total,
        status === "cancelled" ? 0 : Math.round(totals.total * ADVANCE_RATE),
        status === "cancelled" ? 0 : totals.total - Math.round(totals.total * ADVANCE_RATE),
        status,
        order.status,
      ],
    );
    await sql.query(
      `insert into remarks (order_id, order_number, customer_name, staff_id, staff_name, content)
       values ($1,$2,$3,$4,$5,$6)`,
      [order.id, order.orderNumber, order.customerName, staff.userId, staff.displayName, `Cancel: ${data.reason}`],
    );
    await log(sql, staff, `${data.full ? "Full" : "Partial"} cancel ${order.orderNumber}`, "order", String(order.id));
    return { ok: true };
  });

export const requestCancel = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: { orderId: number; reason: string }) => input)
  .handler(async ({ context, data }) => {
    const sql = await getSql();
    const staff = await requireStaff(sql, context.userId);
    const rows = await sql.query<Record<string, unknown>>(`select * from orders where id = $1`, [data.orderId]);
    if (!rows[0]) throw new Error("Order not found");
    const order = mapOrder(rows[0]);
    if (!["designing", "printing", "ready"].includes(order.status)) {
      throw new Error("This order cannot request cancellation");
    }
    await sql.query(
      `update orders set previous_status = status, status = 'cancel_requested', updated_at = now() where id = $1`,
      [order.id],
    );
    await sql.query(
      `insert into refund_requests (order_id, order_number, customer_name, request_type, reason, status, requested_by_id, requested_by_name, amount)
       values ($1,$2,$3,'cancellation',$4,'pending',$5,$6,$7)`,
      [order.id, order.orderNumber, order.customerName, data.reason, staff.userId, staff.displayName, order.advancePaid],
    );
    await sql.query(
      `insert into remarks (order_id, order_number, customer_name, staff_id, staff_name, content)
       values ($1,$2,$3,$4,$5,$6)`,
      [order.id, order.orderNumber, order.customerName, staff.userId, staff.displayName, `Cancel requested: ${data.reason}`],
    );
    await log(sql, staff, `Cancel requested ${order.orderNumber}`, "order", String(order.id));
    return { ok: true };
  });

export const listRefunds = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .handler(async ({ context }: { context: AuthCtx }) => {
    const sql = await getSql();
    await requireStaff(sql, context.userId);
    const rows = await sql.query<Record<string, unknown>>(`select * from refund_requests order by created_at desc`);
    return rows.map(mapRefund);
  });

export const reviewRefund = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: { id: number; approve: boolean; note?: string }) => input)
  .handler(async ({ context, data }) => {
    const sql = await getSql();
    const admin = await requireAdmin(sql, context.userId);
    const rows = await sql.query<Record<string, unknown>>(`select * from refund_requests where id = $1`, [data.id]);
    if (!rows[0]) throw new Error("Request not found");
    const req = mapRefund(rows[0]);
    const status = data.approve ? "approved" : "rejected";
    await sql.query(
      `update refund_requests set status = $2, reviewed_by_id = $3, reviewed_by_name = $4, admin_note = $5 where id = $1`,
      [req.id, status, admin.userId, admin.displayName, data.note ?? ""],
    );
    const orderRows = await sql.query<Record<string, unknown>>(`select * from orders where id = $1`, [req.orderId]);
    if (orderRows[0]) {
      const order = mapOrder(orderRows[0]);
      if (data.approve && req.requestType === "cancellation") {
        await sql.query(`update orders set status = 'cancelled', updated_at = now() where id = $1`, [order.id]);
      } else if (!data.approve) {
        const revert = order.previousStatus && order.previousStatus !== "cancel_requested" ? order.previousStatus : "designing";
        await sql.query(`update orders set status = $2, updated_at = now() where id = $1`, [order.id, revert]);
      }
    }
    await log(sql, admin, `${status} ${req.requestType} for ${req.orderNumber}`, "order", String(req.orderId));
    return { ok: true };
  });

export const saveProduct = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator(
    (input: {
      id?: number;
      name: string;
      category: ProductCategory;
      price: number;
      description: string;
      imageUrl: string;
      isAvailable: boolean;
      customCupCharge: number;
    }) => input,
  )
  .handler(async ({ context, data }) => {
    const sql = await getSql();
    const admin = await requireAdmin(sql, context.userId);
    if (data.id) {
      await sql.query(
        `update products set name=$2, category=$3, price=$4, description=$5, image_url=$6, is_available=$7, custom_cup_charge=$8 where id=$1`,
        [data.id, data.name, data.category, data.price, data.description, data.imageUrl, data.isAvailable, data.customCupCharge],
      );
      await log(sql, admin, `Updated product ${data.name}`, "product", String(data.id));
    } else {
      const rows = await sql.query<{ id: number }>(
        `insert into products (name, category, price, description, image_url, is_available, custom_cup_charge)
         values ($1,$2,$3,$4,$5,$6,$7) returning id`,
        [data.name, data.category, data.price, data.description, data.imageUrl, data.isAvailable, data.customCupCharge],
      );
      await log(sql, admin, `Added product ${data.name}`, "product", String(rows[0]?.id ?? ""));
    }
    return { ok: true };
  });

export const deleteProduct = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: { id: number }) => input)
  .handler(async ({ context, data }) => {
    const sql = await getSql();
    const admin = await requireAdmin(sql, context.userId);
    await sql.query(`delete from products where id = $1`, [data.id]);
    await log(sql, admin, `Deleted product ${data.id}`, "product", String(data.id));
    return { ok: true };
  });

export const listStaff = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .handler(async ({ context }: { context: AuthCtx }) => {
    const sql = await getSql();
    await requireStaff(sql, context.userId);
    const rows = await sql.query<Record<string, unknown>>(
      `select * from profiles where role in ('staff','admin') order by created_at`,
    );
    return rows.map(mapProfile);
  });

export const inviteStaff = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: { email: string; role: "staff" | "admin" }) => input)
  .handler(async ({ context, data }) => {
    const sql = await getSql();
    const admin = await requireAdmin(sql, context.userId);
    const email = data.email.trim().toLowerCase();
    const existing = await sql.query<Record<string, unknown>>(
      `select * from profiles where lower(email) = $1 limit 1`,
      [email],
    );
    if (existing[0]) {
      await sql.query(`update profiles set role = $2, is_active = true where user_id = $1`, [
        existing[0].user_id,
        data.role,
      ]);
    } else {
      const existingInvite = await sql.query<{ id: number }>(
        `select id from staff_invites where lower(email) = $1 limit 1`,
        [email],
      );
      if (existingInvite[0]) {
        await sql.query(`update staff_invites set role = $2 where id = $1`, [existingInvite[0].id, data.role]);
      } else {
        await sql.query(`insert into staff_invites (email, role) values ($1, $2)`, [email, data.role]);
      }
    }
    await log(sql, admin, `Invited ${email} as ${data.role}`, "user", email);
    return { ok: true };
  });

export const setStaffActive = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: { userId: string; isActive: boolean }) => input)
  .handler(async ({ context, data }) => {
    const sql = await getSql();
    const admin = await requireAdmin(sql, context.userId);
    if (data.userId === admin.userId) throw new Error("You cannot change your own account");
    await sql.query(`update profiles set is_active = $2 where user_id = $1`, [data.userId, data.isActive]);
    await log(sql, admin, `${data.isActive ? "Activated" : "Deactivated"} staff`, "user", data.userId);
    return { ok: true };
  });

export const setStaffRole = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: { userId: string; role: UserRole }) => input)
  .handler(async ({ context, data }) => {
    const sql = await getSql();
    const admin = await requireAdmin(sql, context.userId);
    if (data.userId === admin.userId) throw new Error("You cannot change your own role");
    await sql.query(`update profiles set role = $2 where user_id = $1`, [data.userId, data.role]);
    await log(sql, admin, `Role → ${data.role}`, "user", data.userId);
    return { ok: true };
  });

export const dashboardStats = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .handler(async ({ context }: { context: AuthCtx }) => {
    const sql = await getSql();
    await requireStaff(sql, context.userId);
    const counts = await sql.query<{ status: string; c: number }>(
      `select status, count(*)::int as c from orders group by status`,
    );
    const byStatus: Record<string, number> = {};
    for (const r of counts) byStatus[r.status] = r.c;
    const today = await sql.query<{ c: number; revenue: number }>(
      `select count(*)::int as c, coalesce(sum(total),0)::float8 as revenue
       from orders where created_at::date = current_date and status <> 'cancelled'`,
    );
    const week = await sql.query<{ revenue: number }>(
      `select coalesce(sum(total),0)::float8 as revenue
       from orders where created_at >= date_trunc('week', current_date) and status <> 'cancelled'`,
    );
    const month = await sql.query<{ revenue: number }>(
      `select coalesce(sum(total),0)::float8 as revenue
       from orders where created_at >= date_trunc('month', current_date) and status <> 'cancelled'`,
    );
    const all = await sql.query<{ revenue: number; c: number }>(
      `select coalesce(sum(total),0)::float8 as revenue, count(*)::int as c
       from orders where status <> 'cancelled'`,
    );
    const pendingRefunds = await sql.query<{ c: number; amount: number }>(
      `select count(*)::int as c, coalesce(sum(amount),0)::float8 as amount from refund_requests where status = 'pending'`,
    );
    const refunded = await sql.query<{ amount: number }>(
      `select coalesce(sum(amount),0)::float8 as amount from refund_requests where status = 'approved'`,
    );
    const remarksToday = await sql.query<{ c: number }>(
      `select count(*)::int as c from remarks where created_at::date = current_date`,
    );
    const people = await sql.query<{ staff: number; active: number; users: number }>(
      `select
         (select count(*)::int from profiles where role in ('staff','admin')) as staff,
         (select count(*)::int from profiles where role in ('staff','admin') and is_active = true) as active,
         (select count(*)::int from profiles) as users`,
    );
    const outstanding = await sql.query<{ c: number }>(
      `select count(*)::int as c from orders where balance_due > 0 and status not in ('cancelled','delivered')`,
    );
    return {
      byStatus,
      todayOrders: today[0]?.c ?? 0,
      todayRevenue: today[0]?.revenue ?? 0,
      weekRevenue: week[0]?.revenue ?? 0,
      monthRevenue: month[0]?.revenue ?? 0,
      totalRevenue: all[0]?.revenue ?? 0,
      totalOrders: all[0]?.c ?? 0,
      pendingRefunds: pendingRefunds[0]?.c ?? 0,
      pendingRefundAmount: pendingRefunds[0]?.amount ?? 0,
      refundedAmount: refunded[0]?.amount ?? 0,
      remarksToday: remarksToday[0]?.c ?? 0,
      staffCount: people[0]?.staff ?? 0,
      activeStaff: people[0]?.active ?? 0,
      userCount: people[0]?.users ?? 0,
      outstanding: outstanding[0]?.c ?? 0,
    };
  });

export const reportRange = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: { from: string; to: string }) => input)
  .handler(async ({ context, data }) => {
    const sql = await getSql();
    await requireAdmin(sql, context.userId);
    const orders = (
      await sql.query<Record<string, unknown>>(
        `select * from orders where created_at::date >= $1::date and created_at::date <= $2::date order by created_at`,
        [data.from, data.to],
      )
    ).map(mapOrder);
    const active = orders.filter((o) => o.status !== "cancelled");
    const revenue = active.reduce((s, o) => s + o.total, 0);
    const customPct = active.length ? (active.filter((o) => o.items.some((i) => i.cupType === "custom")).length / active.length) * 100 : 0;
    const vipPct = active.length ? (active.filter((o) => o.isVip).length / active.length) * 100 : 0;
    const byCat: Record<string, number> = { coffee: 0, tea: 0, juice: 0 };
    const byPay: Record<string, number> = { cash: 0, card: 0, online: 0 };
    const products = new Map<string, { qty: number; revenue: number }>();
    const staffMap = new Map<string, { name: string; orders: number; revenue: number }>();
    for (const o of active) {
      byPay[o.paymentMethod] = (byPay[o.paymentMethod] ?? 0) + o.total;
      for (const it of o.items) {
        const cat = it.category ?? "coffee";
        byCat[cat] = (byCat[cat] ?? 0) + it.price * it.quantity;
        const p = products.get(it.productName) ?? { qty: 0, revenue: 0 };
        p.qty += it.quantity;
        p.revenue += it.price * it.quantity;
        products.set(it.productName, p);
      }
      if (o.assignedStaffName) {
        const s = staffMap.get(o.assignedStaffId ?? o.assignedStaffName) ?? {
          name: o.assignedStaffName,
          orders: 0,
          revenue: 0,
        };
        s.orders += 1;
        s.revenue += o.total;
        staffMap.set(o.assignedStaffId ?? o.assignedStaffName, s);
      }
    }
    const top = [...products.entries()]
      .map(([name, v]) => ({ name, ...v }))
      .sort((a, b) => b.qty - a.qty)
      .slice(0, 8);
    return {
      totalOrders: active.length,
      revenue,
      average: active.length ? revenue / active.length : 0,
      customPct,
      vipPct,
      byCat,
      byPay,
      top,
      staff: [...staffMap.values()],
    };
  });

export { lockOpen };
