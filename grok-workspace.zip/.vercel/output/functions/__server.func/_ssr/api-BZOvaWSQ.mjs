import { i as TSS_SERVER_FUNCTION, r as createServerFn } from "./ssr.mjs";
import { c as getSql, f as padOrder, r as cartTotals, t as ADVANCE_RATE } from "./format-ydPugZ1g.mjs";
import { t as authMiddleware } from "./middleware-D--PixfV.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/api-BZOvaWSQ.js
var createServerRpc = (serverFnMeta, splitImportFn) => {
	const url = "/_serverFn/" + serverFnMeta.id;
	return Object.assign(splitImportFn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
function str(v, fallback = "") {
	return v == null ? fallback : String(v);
}
function num(v, fallback = 0) {
	const n = typeof v === "number" ? v : Number(v);
	return Number.isFinite(n) ? n : fallback;
}
function bool(v) {
	return v === true || v === "t" || v === "true" || v === 1;
}
function iso(v) {
	if (!v) return "";
	if (v instanceof Date) return v.toISOString();
	return String(v);
}
function items(v) {
	let raw = v;
	if (typeof raw === "string") try {
		raw = JSON.parse(raw);
	} catch {
		return [];
	}
	if (!Array.isArray(raw)) return [];
	return raw.map((it) => {
		const o = it ?? {};
		return {
			productId: str(o.productId ?? o.product_id),
			productName: str(o.productName ?? o.product_name),
			quantity: num(o.quantity, 1),
			price: num(o.price),
			cupType: str(o.cupType ?? o.cup_type, "standard"),
			category: o.category ? str(o.category) : void 0,
			customCupName: o.customCupName || o.custom_cup_name ? str(o.customCupName ?? o.custom_cup_name) : void 0,
			customCupMessage: o.customCupMessage || o.custom_cup_message ? str(o.customCupMessage ?? o.custom_cup_message) : void 0,
			customCupImageUrl: o.customCupImageUrl || o.custom_cup_image_url ? str(o.customCupImageUrl ?? o.custom_cup_image_url) : void 0,
			customCupCharge: o.customCupCharge != null || o.custom_cup_charge != null ? num(o.customCupCharge ?? o.custom_cup_charge) : void 0
		};
	});
}
function mapProfile(row) {
	return {
		userId: str(row.user_id),
		email: str(row.email),
		displayName: str(row.display_name),
		role: str(row.role, "user") || "user",
		isActive: bool(row.is_active),
		createdAt: iso(row.created_at)
	};
}
function mapProduct(row) {
	return {
		id: num(row.id),
		name: str(row.name),
		category: str(row.category),
		price: num(row.price),
		description: str(row.description),
		imageUrl: str(row.image_url),
		isAvailable: bool(row.is_available),
		customCupCharge: num(row.custom_cup_charge)
	};
}
function mapOrder(row) {
	return {
		id: num(row.id),
		userId: row.user_id ? str(row.user_id) : null,
		orderNumber: str(row.order_number),
		customerName: str(row.customer_name),
		customerEmail: str(row.customer_email),
		customerPhone: str(row.customer_phone),
		items: items(row.items),
		subtotal: num(row.subtotal),
		customCharges: num(row.custom_charges),
		total: num(row.total),
		advancePaid: num(row.advance_paid),
		balanceDue: num(row.balance_due),
		isVip: bool(row.is_vip),
		walkIn: bool(row.walk_in),
		status: str(row.status, "received"),
		consentOwnImage: bool(row.consent_own_image),
		consentMarketing: bool(row.consent_marketing),
		assignedStaffId: row.assigned_staff_id ? str(row.assigned_staff_id) : null,
		assignedStaffName: row.assigned_staff_name ? str(row.assigned_staff_name) : null,
		paymentMethod: str(row.payment_method, "cash"),
		notes: str(row.notes),
		lockedByStaffId: row.locked_by_staff_id ? str(row.locked_by_staff_id) : null,
		lockedByStaffName: row.locked_by_staff_name ? str(row.locked_by_staff_name) : null,
		lockedAt: row.locked_at ? iso(row.locked_at) : null,
		previousStatus: row.previous_status ? str(row.previous_status) : null,
		createdAt: iso(row.created_at),
		updatedAt: iso(row.updated_at)
	};
}
function mapRefund(row) {
	return {
		id: num(row.id),
		orderId: num(row.order_id),
		orderNumber: str(row.order_number),
		customerName: str(row.customer_name),
		requestType: str(row.request_type),
		reason: str(row.reason),
		status: str(row.status),
		requestedById: str(row.requested_by_id),
		requestedByName: str(row.requested_by_name),
		reviewedById: row.reviewed_by_id ? str(row.reviewed_by_id) : null,
		reviewedByName: row.reviewed_by_name ? str(row.reviewed_by_name) : null,
		adminNote: str(row.admin_note),
		amount: num(row.amount),
		createdAt: iso(row.created_at)
	};
}
function mapRemark(row) {
	return {
		id: num(row.id),
		orderId: num(row.order_id),
		orderNumber: str(row.order_number),
		customerName: str(row.customer_name),
		staffId: str(row.staff_id),
		staffName: str(row.staff_name),
		content: str(row.content),
		createdAt: iso(row.created_at)
	};
}
function mapLog(row) {
	return {
		id: num(row.id),
		userName: str(row.user_name),
		userRole: str(row.user_role),
		action: str(row.action),
		entityType: str(row.entity_type),
		entityId: str(row.entity_id),
		createdAt: iso(row.created_at)
	};
}
async function authUser(sql, userId) {
	return (await sql.query(`select id, name, email from "user" where id = $1`, [userId]))[0] ?? {
		id: userId,
		name: "Guest",
		email: ""
	};
}
async function ensureProfile(sql, userId) {
	const auth = await authUser(sql, userId);
	const existing = await sql.query(`select * from profiles where user_id = $1`, [userId]);
	if (existing[0]) {
		const p = mapProfile(existing[0]);
		if (!p.email && auth.email || !p.displayName && auth.name) {
			await sql.query(`update profiles set email = coalesce(nullif(email, ''), $2), display_name = coalesce(nullif(display_name, ''), $3) where user_id = $1`, [
				userId,
				auth.email,
				auth.name
			]);
			return {
				...p,
				email: p.email || auth.email,
				displayName: p.displayName || auth.name
			};
		}
		return p;
	}
	const email = (auth.email || "").toLowerCase();
	const invite = email ? await sql.query(`select * from staff_invites where lower(email) = $1 limit 1`, [email]) : [];
	const admins = await sql.query(`select count(*)::int as c from profiles where role = 'admin'`);
	let role = "user";
	if (invite[0]) role = String(invite[0].role) || "staff";
	else if ((admins[0]?.c ?? 0) === 0) role = "admin";
	await sql.query(`insert into profiles (user_id, email, display_name, role, is_active)
     values ($1, $2, $3, $4, true)
     on conflict (user_id) do nothing`, [
		userId,
		auth.email,
		auth.name || "Guest",
		role
	]);
	if (invite[0]) await sql.query(`delete from staff_invites where id = $1`, [invite[0].id]);
	return mapProfile((await sql.query(`select * from profiles where user_id = $1`, [userId]))[0] ?? {
		user_id: userId,
		email: auth.email,
		display_name: auth.name,
		role,
		is_active: true
	});
}
async function requireStaff(sql, userId) {
	const p = await ensureProfile(sql, userId);
	if (!p.isActive) throw new Error("Account deactivated");
	if (p.role !== "staff" && p.role !== "admin") throw new Error("Forbidden");
	return p;
}
async function requireAdmin(sql, userId) {
	const p = await ensureProfile(sql, userId);
	if (!p.isActive) throw new Error("Account deactivated");
	if (p.role !== "admin") throw new Error("Forbidden");
	return p;
}
async function log(sql, p, action, entityType, entityId) {
	await sql.query(`insert into activity_logs (user_name, user_role, action, entity_type, entity_id) values ($1,$2,$3,$4,$5)`, [
		p.displayName || p.email,
		p.role === "user" ? "customer" : p.role,
		action,
		entityType,
		entityId
	]);
}
async function nextNumber(sql, kind) {
	await sql.query(`insert into counters (name, value) values ($1, 0) on conflict (name) do nothing`, [kind]);
	const rows = await sql.query(`update counters set value = value + 1 where name = $1 returning value`, [kind]);
	return padOrder(kind === "vip" ? "VIP" : "CUP", rows[0]?.value ?? 1);
}
var getMyProfile_createServerFn_handler = createServerRpc({
	id: "471967d11a0c615c01c6f7adbc63ca213b4f295190e84cbfbfa43608e172effe",
	name: "getMyProfile",
	filename: "src/lib/cupify/api.ts"
}, (opts) => getMyProfile.__executeServer(opts));
var getMyProfile = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(getMyProfile_createServerFn_handler, async ({ context }) => {
	return ensureProfile(await getSql(), context.userId);
});
var listProducts_createServerFn_handler = createServerRpc({
	id: "0619e183e13466216945b4140e5cc022d2cece2ef2b1570c9674b23a941d88f2",
	name: "listProducts",
	filename: "src/lib/cupify/api.ts"
}, (opts) => listProducts.__executeServer(opts));
var listProducts = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(listProducts_createServerFn_handler, async ({ context }) => {
	const sql = await getSql();
	await requireAdmin(sql, context.userId);
	return (await sql.query(`select * from products order by category, name`)).map(mapProduct);
});
var listAvailableProducts_createServerFn_handler = createServerRpc({
	id: "7be86018d170a24a411c1683ff46d52fc70158b178367cdcfda96f4e271ba022",
	name: "listAvailableProducts",
	filename: "src/lib/cupify/api.ts"
}, (opts) => listAvailableProducts.__executeServer(opts));
var listAvailableProducts = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(listAvailableProducts_createServerFn_handler, async () => {
	return (await (await getSql()).query(`select * from products where is_available = true order by category, name`)).map(mapProduct);
});
var placeOrder_createServerFn_handler = createServerRpc({
	id: "dbb5a7b75cbf621da6b5051c6194e68649aa80c849ddd1d683716798c63f4518",
	name: "placeOrder",
	filename: "src/lib/cupify/api.ts"
}, (opts) => placeOrder.__executeServer(opts));
var placeOrder = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => input).handler(placeOrder_createServerFn_handler, async ({ context, data }) => {
	const sql = await getSql();
	const profile = await ensureProfile(sql, context.userId);
	if (!profile.isActive) throw new Error("Account deactivated");
	if (!data.items?.length) throw new Error("Cart is empty");
	if (!data.customerName?.trim()) throw new Error("Name is required");
	if (data.items.some((i) => i.cupType === "custom") && !data.consentOwnImage) throw new Error("Image rights consent is required for custom cups");
	const totals = cartTotals(data.items);
	const isVip = Boolean(data.isVip);
	const walkIn = Boolean(data.walkIn);
	const vipExtra = isVip ? 100 : 0;
	const total = totals.total + vipExtra;
	const customCharges = totals.customCharges + vipExtra;
	const advancePaid = isVip || walkIn ? total : Math.round(total * ADVANCE_RATE);
	const balanceDue = total - advancePaid;
	const number = await nextNumber(sql, isVip ? "vip" : "cup");
	const assignedId = walkIn ? profile.userId : null;
	const assignedName = walkIn ? profile.displayName : null;
	const order = mapOrder((await sql.query(`insert into orders (
        user_id, order_number, customer_name, customer_email, customer_phone, items,
        subtotal, custom_charges, total, advance_paid, balance_due, is_vip, walk_in, status,
        consent_own_image, consent_marketing, assigned_staff_id, assigned_staff_name, payment_method, notes
      ) values ($1,$2,$3,$4,$5,$6::jsonb,$7,$8,$9,$10,$11,$12,$13,'received',$14,$15,$16,$17,$18,$19)
      returning *`, [
		walkIn ? null : context.userId,
		number,
		data.customerName.trim(),
		data.customerEmail?.trim() ?? "",
		data.customerPhone?.trim() ?? "",
		JSON.stringify(data.items),
		totals.subtotal,
		customCharges,
		total,
		advancePaid,
		balanceDue,
		isVip,
		walkIn,
		Boolean(data.consentOwnImage),
		Boolean(data.consentMarketing),
		assignedId,
		assignedName,
		data.paymentMethod ?? "cash",
		data.notes ?? ""
	]))[0]);
	await log(sql, profile, `Placed order ${order.orderNumber}`, "order", String(order.id));
	return order;
});
var listMyOrders_createServerFn_handler = createServerRpc({
	id: "d681ab91e35e54104d93e345cea9ed26a8513c8e29c4f3767d482a2674a85b44",
	name: "listMyOrders",
	filename: "src/lib/cupify/api.ts"
}, (opts) => listMyOrders.__executeServer(opts));
var listMyOrders = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(listMyOrders_createServerFn_handler, async ({ context }) => {
	return (await (await getSql()).query(`select * from orders where user_id = $1 order by created_at desc`, [context.userId])).map(mapOrder);
});
var getOrderByNumber_createServerFn_handler = createServerRpc({
	id: "0d11d216dbdabce8cecfdc40a70a30fae0bb5af818633c04a93e3a79043fd669",
	name: "getOrderByNumber",
	filename: "src/lib/cupify/api.ts"
}, (opts) => getOrderByNumber.__executeServer(opts));
var getOrderByNumber = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => input).handler(getOrderByNumber_createServerFn_handler, async ({ data }) => {
	const rows = await (await getSql()).query(`select * from orders where lower(order_number) = lower($1) limit 1`, [data.orderNumber.trim()]);
	return rows[0] ? mapOrder(rows[0]) : null;
});
var searchInvoices_createServerFn_handler = createServerRpc({
	id: "29d735d08b3d3eefbc7ccd4baeab7a3156470b160c0e05767ac2b78a33c11df2",
	name: "searchInvoices",
	filename: "src/lib/cupify/api.ts"
}, (opts) => searchInvoices.__executeServer(opts));
var searchInvoices = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => input).handler(searchInvoices_createServerFn_handler, async ({ context, data }) => {
	const sql = await getSql();
	const profile = await ensureProfile(sql, context.userId);
	const q = `%${data.q.trim()}%`;
	const staff = profile.role === "staff" || profile.role === "admin";
	return (await sql.query(staff ? `select * from orders
           where order_number ilike $1 or customer_name ilike $1 or customer_email ilike $1 or customer_phone ilike $1
           order by created_at desc limit 40` : `select * from orders
           where user_id = $2 and (order_number ilike $1 or customer_name ilike $1 or customer_email ilike $1 or customer_phone ilike $1)
           order by created_at desc limit 40`, staff ? [q] : [q, context.userId])).map(mapOrder);
});
var listStaffOrders_createServerFn_handler = createServerRpc({
	id: "86bf7b248981a835e9dbc511484dc4a283f0fcdaf862ae6339839b612590e537",
	name: "listStaffOrders",
	filename: "src/lib/cupify/api.ts"
}, (opts) => listStaffOrders.__executeServer(opts));
var listStaffOrders = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(listStaffOrders_createServerFn_handler, async ({ context }) => {
	const sql = await getSql();
	await requireStaff(sql, context.userId);
	return (await sql.query(`select * from orders order by created_at desc`)).map(mapOrder);
});
var updateOrderStatus_createServerFn_handler = createServerRpc({
	id: "0811ad16fd6bb7c496b006a5ceff2ad844607f8d495caa8df6a35afb9d99bb72",
	name: "updateOrderStatus",
	filename: "src/lib/cupify/api.ts"
}, (opts) => updateOrderStatus.__executeServer(opts));
var updateOrderStatus = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => input).handler(updateOrderStatus_createServerFn_handler, async ({ context, data }) => {
	const sql = await getSql();
	const staff = await requireStaff(sql, context.userId);
	const current = await sql.query(`select * from orders where id = $1`, [data.id]);
	if (!current[0]) throw new Error("Order not found");
	const order = mapOrder(current[0]);
	await sql.query(`update orders set status = $2, previous_status = $3, updated_at = now() where id = $1`, [
		data.id,
		data.status,
		order.status
	]);
	await log(sql, staff, `Status ${order.orderNumber}: ${order.status} → ${data.status}`, "order", String(data.id));
	return mapOrder((await sql.query(`select * from orders where id = $1`, [data.id]))[0]);
});
var bulkUpdateStatus_createServerFn_handler = createServerRpc({
	id: "6e60ac7f7fe9b394d8a47ed509175462ad36fc76b2e2b3cd86d96bf66cab0b51",
	name: "bulkUpdateStatus",
	filename: "src/lib/cupify/api.ts"
}, (opts) => bulkUpdateStatus.__executeServer(opts));
var bulkUpdateStatus = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => input).handler(bulkUpdateStatus_createServerFn_handler, async ({ context, data }) => {
	const sql = await getSql();
	const staff = await requireAdmin(sql, context.userId);
	if (!data.ids.length) return { count: 0 };
	const placeholders = data.ids.map((_, i) => `$${i + 2}`).join(",");
	await sql.query(`update orders set previous_status = status, status = $1, updated_at = now() where id in (${placeholders})`, [data.status, ...data.ids]);
	await log(sql, staff, `Bulk status → ${data.status} (${data.ids.length})`, "order", data.ids.join(","));
	return { count: data.ids.length };
});
var assignStaff_createServerFn_handler = createServerRpc({
	id: "3807ab8427896db9d5d530a85d6f5deca6d0b12429a874d637b991075c225c31",
	name: "assignStaff",
	filename: "src/lib/cupify/api.ts"
}, (opts) => assignStaff.__executeServer(opts));
var assignStaff = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => input).handler(assignStaff_createServerFn_handler, async ({ context, data }) => {
	const sql = await getSql();
	const admin = await requireAdmin(sql, context.userId);
	await sql.query(`update orders set assigned_staff_id = $2, assigned_staff_name = $3, updated_at = now() where id = $1`, [
		data.orderId,
		data.staffId,
		data.staffName
	]);
	await log(sql, admin, `Assigned order ${data.orderId} to ${data.staffName}`, "order", String(data.orderId));
	return { ok: true };
});
var lockOrder_createServerFn_handler = createServerRpc({
	id: "0f588b8b99a2e6c38022c6c6dae4db56a1b3ef22b529b8f71395971b7d1c9645",
	name: "lockOrder",
	filename: "src/lib/cupify/api.ts"
}, (opts) => lockOrder.__executeServer(opts));
var lockOrder = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => input).handler(lockOrder_createServerFn_handler, async ({ context, data }) => {
	const sql = await getSql();
	const staff = await requireStaff(sql, context.userId);
	await sql.query(`update orders set locked_by_staff_id = null, locked_by_staff_name = null, locked_at = null
       where locked_by_staff_id = $1`, [staff.userId]);
	if (data.id) await sql.query(`update orders set locked_by_staff_id = $2, locked_by_staff_name = $3, locked_at = now() where id = $1`, [
		data.id,
		staff.userId,
		staff.displayName
	]);
	return { ok: true };
});
var addRemark_createServerFn_handler = createServerRpc({
	id: "0b129b796604615617434ed1ffe08ad4289e613727a21a71d91096bfebe7eb71",
	name: "addRemark",
	filename: "src/lib/cupify/api.ts"
}, (opts) => addRemark.__executeServer(opts));
var addRemark = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => input).handler(addRemark_createServerFn_handler, async ({ context, data }) => {
	const sql = await getSql();
	const staff = await requireStaff(sql, context.userId);
	const orderRows = await sql.query(`select * from orders where id = $1`, [data.orderId]);
	if (!orderRows[0]) throw new Error("Order not found");
	const order = mapOrder(orderRows[0]);
	const rows = await sql.query(`insert into remarks (order_id, order_number, customer_name, staff_id, staff_name, content)
       values ($1,$2,$3,$4,$5,$6) returning *`, [
		order.id,
		order.orderNumber,
		order.customerName,
		staff.userId,
		staff.displayName,
		data.content.trim()
	]);
	await log(sql, staff, `Remark on ${order.orderNumber}`, "order", String(order.id));
	return mapRemark(rows[0]);
});
var listRemarks_createServerFn_handler = createServerRpc({
	id: "7dd7cb273123f760385440569dcb6f2bac92d5bf46d16353e68b77085e86ac11",
	name: "listRemarks",
	filename: "src/lib/cupify/api.ts"
}, (opts) => listRemarks.__executeServer(opts));
var listRemarks = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input = {}) => input).handler(listRemarks_createServerFn_handler, async ({ context, data }) => {
	const sql = await getSql();
	await requireStaff(sql, context.userId);
	return (data.orderId ? await sql.query(`select * from remarks where order_id = $1 order by created_at desc`, [data.orderId]) : await sql.query(`select * from remarks order by created_at desc limit 80`)).map(mapRemark);
});
var listLogs_createServerFn_handler = createServerRpc({
	id: "38f39f5c92becb095ced1f693739ea35ca8936b69dc7edc75f9c448783ac520a",
	name: "listLogs",
	filename: "src/lib/cupify/api.ts"
}, (opts) => listLogs.__executeServer(opts));
var listLogs = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(listLogs_createServerFn_handler, async ({ context }) => {
	const sql = await getSql();
	await requireStaff(sql, context.userId);
	return (await sql.query(`select * from activity_logs order by created_at desc limit 200`)).map(mapLog);
});
var cancelItems_createServerFn_handler = createServerRpc({
	id: "abf50ce7e4b5f85ccade2964852ea530c7082b4859bb95030aa1e57c4c543bae",
	name: "cancelItems",
	filename: "src/lib/cupify/api.ts"
}, (opts) => cancelItems.__executeServer(opts));
var cancelItems = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => input).handler(cancelItems_createServerFn_handler, async ({ context, data }) => {
	const sql = await getSql();
	const staff = await requireStaff(sql, context.userId);
	const rows = await sql.query(`select * from orders where id = $1`, [data.orderId]);
	if (!rows[0]) throw new Error("Order not found");
	const order = mapOrder(rows[0]);
	if (order.status !== "received") throw new Error("Only received orders can be cancelled directly");
	if (!data.reason.trim()) throw new Error("Reason is required");
	let nextItems;
	let status = order.status;
	if (data.full) {
		nextItems = order.items.map((i) => ({
			...i,
			quantity: 0
		}));
		status = "cancelled";
	} else {
		nextItems = order.items.map((i, idx) => ({
			...i,
			quantity: Math.max(0, i.quantity - (data.quantities[idx] ?? 0))
		})).filter((i) => i.quantity > 0);
		if (!nextItems.length) status = "cancelled";
	}
	const totals = cartTotals(nextItems);
	await sql.query(`update orders set items = $2::jsonb, subtotal = $3, custom_charges = $4, total = $5,
        advance_paid = $6, balance_due = $7, status = $8, previous_status = $9, updated_at = now()
       where id = $1`, [
		order.id,
		JSON.stringify(nextItems),
		totals.subtotal,
		totals.customCharges,
		totals.total,
		status === "cancelled" ? 0 : Math.round(totals.total * ADVANCE_RATE),
		status === "cancelled" ? 0 : totals.total - Math.round(totals.total * ADVANCE_RATE),
		status,
		order.status
	]);
	await sql.query(`insert into remarks (order_id, order_number, customer_name, staff_id, staff_name, content)
       values ($1,$2,$3,$4,$5,$6)`, [
		order.id,
		order.orderNumber,
		order.customerName,
		staff.userId,
		staff.displayName,
		`Cancel: ${data.reason}`
	]);
	await log(sql, staff, `${data.full ? "Full" : "Partial"} cancel ${order.orderNumber}`, "order", String(order.id));
	return { ok: true };
});
var requestCancel_createServerFn_handler = createServerRpc({
	id: "4dc3a3351eae685f0ac16062083cd51d8479d77c595ab769b4d947aaf1ef8bf5",
	name: "requestCancel",
	filename: "src/lib/cupify/api.ts"
}, (opts) => requestCancel.__executeServer(opts));
var requestCancel = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => input).handler(requestCancel_createServerFn_handler, async ({ context, data }) => {
	const sql = await getSql();
	const staff = await requireStaff(sql, context.userId);
	const rows = await sql.query(`select * from orders where id = $1`, [data.orderId]);
	if (!rows[0]) throw new Error("Order not found");
	const order = mapOrder(rows[0]);
	if (![
		"designing",
		"printing",
		"ready"
	].includes(order.status)) throw new Error("This order cannot request cancellation");
	await sql.query(`update orders set previous_status = status, status = 'cancel_requested', updated_at = now() where id = $1`, [order.id]);
	await sql.query(`insert into refund_requests (order_id, order_number, customer_name, request_type, reason, status, requested_by_id, requested_by_name, amount)
       values ($1,$2,$3,'cancellation',$4,'pending',$5,$6,$7)`, [
		order.id,
		order.orderNumber,
		order.customerName,
		data.reason,
		staff.userId,
		staff.displayName,
		order.advancePaid
	]);
	await sql.query(`insert into remarks (order_id, order_number, customer_name, staff_id, staff_name, content)
       values ($1,$2,$3,$4,$5,$6)`, [
		order.id,
		order.orderNumber,
		order.customerName,
		staff.userId,
		staff.displayName,
		`Cancel requested: ${data.reason}`
	]);
	await log(sql, staff, `Cancel requested ${order.orderNumber}`, "order", String(order.id));
	return { ok: true };
});
var listRefunds_createServerFn_handler = createServerRpc({
	id: "9a2f5bf15db0fc62067b45414f1f7ccc19db6c7558281a2cac7f6183e0fafe33",
	name: "listRefunds",
	filename: "src/lib/cupify/api.ts"
}, (opts) => listRefunds.__executeServer(opts));
var listRefunds = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(listRefunds_createServerFn_handler, async ({ context }) => {
	const sql = await getSql();
	await requireStaff(sql, context.userId);
	return (await sql.query(`select * from refund_requests order by created_at desc`)).map(mapRefund);
});
var reviewRefund_createServerFn_handler = createServerRpc({
	id: "fc6c6b48f0cc995673e4ee156bc10646241ebe6d845c2fae40d61b18b0d05166",
	name: "reviewRefund",
	filename: "src/lib/cupify/api.ts"
}, (opts) => reviewRefund.__executeServer(opts));
var reviewRefund = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => input).handler(reviewRefund_createServerFn_handler, async ({ context, data }) => {
	const sql = await getSql();
	const admin = await requireAdmin(sql, context.userId);
	const rows = await sql.query(`select * from refund_requests where id = $1`, [data.id]);
	if (!rows[0]) throw new Error("Request not found");
	const req = mapRefund(rows[0]);
	const status = data.approve ? "approved" : "rejected";
	await sql.query(`update refund_requests set status = $2, reviewed_by_id = $3, reviewed_by_name = $4, admin_note = $5 where id = $1`, [
		req.id,
		status,
		admin.userId,
		admin.displayName,
		data.note ?? ""
	]);
	const orderRows = await sql.query(`select * from orders where id = $1`, [req.orderId]);
	if (orderRows[0]) {
		const order = mapOrder(orderRows[0]);
		if (data.approve && req.requestType === "cancellation") await sql.query(`update orders set status = 'cancelled', updated_at = now() where id = $1`, [order.id]);
		else if (!data.approve) {
			const revert = order.previousStatus && order.previousStatus !== "cancel_requested" ? order.previousStatus : "designing";
			await sql.query(`update orders set status = $2, updated_at = now() where id = $1`, [order.id, revert]);
		}
	}
	await log(sql, admin, `${status} ${req.requestType} for ${req.orderNumber}`, "order", String(req.orderId));
	return { ok: true };
});
var saveProduct_createServerFn_handler = createServerRpc({
	id: "0fa24aa86c329c53e05c078cfd0d98435fad4c148865143d4f592ba3eab88de8",
	name: "saveProduct",
	filename: "src/lib/cupify/api.ts"
}, (opts) => saveProduct.__executeServer(opts));
var saveProduct = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => input).handler(saveProduct_createServerFn_handler, async ({ context, data }) => {
	const sql = await getSql();
	const admin = await requireAdmin(sql, context.userId);
	if (data.id) {
		await sql.query(`update products set name=$2, category=$3, price=$4, description=$5, image_url=$6, is_available=$7, custom_cup_charge=$8 where id=$1`, [
			data.id,
			data.name,
			data.category,
			data.price,
			data.description,
			data.imageUrl,
			data.isAvailable,
			data.customCupCharge
		]);
		await log(sql, admin, `Updated product ${data.name}`, "product", String(data.id));
	} else {
		const rows = await sql.query(`insert into products (name, category, price, description, image_url, is_available, custom_cup_charge)
         values ($1,$2,$3,$4,$5,$6,$7) returning id`, [
			data.name,
			data.category,
			data.price,
			data.description,
			data.imageUrl,
			data.isAvailable,
			data.customCupCharge
		]);
		await log(sql, admin, `Added product ${data.name}`, "product", String(rows[0]?.id ?? ""));
	}
	return { ok: true };
});
var deleteProduct_createServerFn_handler = createServerRpc({
	id: "70ae99c4c540cc22c38e2469e6ead170a53c43b166e1d2f70485c8ed848e26b2",
	name: "deleteProduct",
	filename: "src/lib/cupify/api.ts"
}, (opts) => deleteProduct.__executeServer(opts));
var deleteProduct = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => input).handler(deleteProduct_createServerFn_handler, async ({ context, data }) => {
	const sql = await getSql();
	const admin = await requireAdmin(sql, context.userId);
	await sql.query(`delete from products where id = $1`, [data.id]);
	await log(sql, admin, `Deleted product ${data.id}`, "product", String(data.id));
	return { ok: true };
});
var listStaff_createServerFn_handler = createServerRpc({
	id: "ed47ce0f21bb82d1eff156e96b638fb3a0ef4c217df205c8f56b08d86da37f97",
	name: "listStaff",
	filename: "src/lib/cupify/api.ts"
}, (opts) => listStaff.__executeServer(opts));
var listStaff = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(listStaff_createServerFn_handler, async ({ context }) => {
	const sql = await getSql();
	await requireStaff(sql, context.userId);
	return (await sql.query(`select * from profiles where role in ('staff','admin') order by created_at`)).map(mapProfile);
});
var inviteStaff_createServerFn_handler = createServerRpc({
	id: "7b9c00ef903ccfeeddfb97c33e5fa46ae0e5c374f0f9d0dc04b13beb5f27a5fa",
	name: "inviteStaff",
	filename: "src/lib/cupify/api.ts"
}, (opts) => inviteStaff.__executeServer(opts));
var inviteStaff = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => input).handler(inviteStaff_createServerFn_handler, async ({ context, data }) => {
	const sql = await getSql();
	const admin = await requireAdmin(sql, context.userId);
	const email = data.email.trim().toLowerCase();
	const existing = await sql.query(`select * from profiles where lower(email) = $1 limit 1`, [email]);
	if (existing[0]) await sql.query(`update profiles set role = $2, is_active = true where user_id = $1`, [existing[0].user_id, data.role]);
	else {
		const existingInvite = await sql.query(`select id from staff_invites where lower(email) = $1 limit 1`, [email]);
		if (existingInvite[0]) await sql.query(`update staff_invites set role = $2 where id = $1`, [existingInvite[0].id, data.role]);
		else await sql.query(`insert into staff_invites (email, role) values ($1, $2)`, [email, data.role]);
	}
	await log(sql, admin, `Invited ${email} as ${data.role}`, "user", email);
	return { ok: true };
});
var setStaffActive_createServerFn_handler = createServerRpc({
	id: "33f0bd92d7264ea90db4acae87fe64eddee0c789ae1f6852a97fe2d8a026b847",
	name: "setStaffActive",
	filename: "src/lib/cupify/api.ts"
}, (opts) => setStaffActive.__executeServer(opts));
var setStaffActive = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => input).handler(setStaffActive_createServerFn_handler, async ({ context, data }) => {
	const sql = await getSql();
	const admin = await requireAdmin(sql, context.userId);
	if (data.userId === admin.userId) throw new Error("You cannot change your own account");
	await sql.query(`update profiles set is_active = $2 where user_id = $1`, [data.userId, data.isActive]);
	await log(sql, admin, `${data.isActive ? "Activated" : "Deactivated"} staff`, "user", data.userId);
	return { ok: true };
});
var setStaffRole_createServerFn_handler = createServerRpc({
	id: "faf0cc43d429a0cbbe840190a34d3c67aab31cd0a6dc73bf3f230b3dff7e5293",
	name: "setStaffRole",
	filename: "src/lib/cupify/api.ts"
}, (opts) => setStaffRole.__executeServer(opts));
var setStaffRole = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => input).handler(setStaffRole_createServerFn_handler, async ({ context, data }) => {
	const sql = await getSql();
	const admin = await requireAdmin(sql, context.userId);
	if (data.userId === admin.userId) throw new Error("You cannot change your own role");
	await sql.query(`update profiles set role = $2 where user_id = $1`, [data.userId, data.role]);
	await log(sql, admin, `Role → ${data.role}`, "user", data.userId);
	return { ok: true };
});
var dashboardStats_createServerFn_handler = createServerRpc({
	id: "a91bc2d1fae35bcca2421de50d25474f1f2130891693f691a00169c5ae47883f",
	name: "dashboardStats",
	filename: "src/lib/cupify/api.ts"
}, (opts) => dashboardStats.__executeServer(opts));
var dashboardStats = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(dashboardStats_createServerFn_handler, async ({ context }) => {
	const sql = await getSql();
	await requireStaff(sql, context.userId);
	const counts = await sql.query(`select status, count(*)::int as c from orders group by status`);
	const byStatus = {};
	for (const r of counts) byStatus[r.status] = r.c;
	const today = await sql.query(`select count(*)::int as c, coalesce(sum(total),0)::float8 as revenue
       from orders where created_at::date = current_date and status <> 'cancelled'`);
	const week = await sql.query(`select coalesce(sum(total),0)::float8 as revenue
       from orders where created_at >= date_trunc('week', current_date) and status <> 'cancelled'`);
	const month = await sql.query(`select coalesce(sum(total),0)::float8 as revenue
       from orders where created_at >= date_trunc('month', current_date) and status <> 'cancelled'`);
	const all = await sql.query(`select coalesce(sum(total),0)::float8 as revenue, count(*)::int as c
       from orders where status <> 'cancelled'`);
	const pendingRefunds = await sql.query(`select count(*)::int as c, coalesce(sum(amount),0)::float8 as amount from refund_requests where status = 'pending'`);
	const refunded = await sql.query(`select coalesce(sum(amount),0)::float8 as amount from refund_requests where status = 'approved'`);
	const remarksToday = await sql.query(`select count(*)::int as c from remarks where created_at::date = current_date`);
	const people = await sql.query(`select
         (select count(*)::int from profiles where role in ('staff','admin')) as staff,
         (select count(*)::int from profiles where role in ('staff','admin') and is_active = true) as active,
         (select count(*)::int from profiles) as users`);
	const outstanding = await sql.query(`select count(*)::int as c from orders where balance_due > 0 and status not in ('cancelled','delivered')`);
	return {
		byStatus,
		todayOrders: today[0]?.c ?? 0,
		todayRevenue: today[0]?.revenue ?? 0,
		weekRevenue: week[0]?.revenue ?? 0,
		monthRevenue: month[0]?.revenue ?? 0,
		totalRevenue: all[0]?.revenue ?? 0,
		totalOrders: all[0]?.c ?? 0,
		pendingRefunds: pendingRefunds[0]?.c ?? 0,
		pendingRefundAmount: pendingRefunds[0]?.amount ?? 0,
		refundedAmount: refunded[0]?.amount ?? 0,
		remarksToday: remarksToday[0]?.c ?? 0,
		staffCount: people[0]?.staff ?? 0,
		activeStaff: people[0]?.active ?? 0,
		userCount: people[0]?.users ?? 0,
		outstanding: outstanding[0]?.c ?? 0
	};
});
var reportRange_createServerFn_handler = createServerRpc({
	id: "03970b6038322cbfe86c8a64ec7427a912ed06440add1b49e4b4cfc0a0835306",
	name: "reportRange",
	filename: "src/lib/cupify/api.ts"
}, (opts) => reportRange.__executeServer(opts));
var reportRange = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => input).handler(reportRange_createServerFn_handler, async ({ context, data }) => {
	const sql = await getSql();
	await requireAdmin(sql, context.userId);
	const active = (await sql.query(`select * from orders where created_at::date >= $1::date and created_at::date <= $2::date order by created_at`, [data.from, data.to])).map(mapOrder).filter((o) => o.status !== "cancelled");
	const revenue = active.reduce((s, o) => s + o.total, 0);
	const customPct = active.length ? active.filter((o) => o.items.some((i) => i.cupType === "custom")).length / active.length * 100 : 0;
	const vipPct = active.length ? active.filter((o) => o.isVip).length / active.length * 100 : 0;
	const byCat = {
		coffee: 0,
		tea: 0,
		juice: 0
	};
	const byPay = {
		cash: 0,
		card: 0,
		online: 0
	};
	const products = /* @__PURE__ */ new Map();
	const staffMap = /* @__PURE__ */ new Map();
	for (const o of active) {
		byPay[o.paymentMethod] = (byPay[o.paymentMethod] ?? 0) + o.total;
		for (const it of o.items) {
			const cat = it.category ?? "coffee";
			byCat[cat] = (byCat[cat] ?? 0) + it.price * it.quantity;
			const p = products.get(it.productName) ?? {
				qty: 0,
				revenue: 0
			};
			p.qty += it.quantity;
			p.revenue += it.price * it.quantity;
			products.set(it.productName, p);
		}
		if (o.assignedStaffName) {
			const s = staffMap.get(o.assignedStaffId ?? o.assignedStaffName) ?? {
				name: o.assignedStaffName,
				orders: 0,
				revenue: 0
			};
			s.orders += 1;
			s.revenue += o.total;
			staffMap.set(o.assignedStaffId ?? o.assignedStaffName, s);
		}
	}
	const top = [...products.entries()].map(([name, v]) => ({
		name,
		...v
	})).sort((a, b) => b.qty - a.qty).slice(0, 8);
	return {
		totalOrders: active.length,
		revenue,
		average: active.length ? revenue / active.length : 0,
		customPct,
		vipPct,
		byCat,
		byPay,
		top,
		staff: [...staffMap.values()]
	};
});
//#endregion
export { addRemark_createServerFn_handler, assignStaff_createServerFn_handler, bulkUpdateStatus_createServerFn_handler, cancelItems_createServerFn_handler, dashboardStats_createServerFn_handler, deleteProduct_createServerFn_handler, getMyProfile_createServerFn_handler, getOrderByNumber_createServerFn_handler, inviteStaff_createServerFn_handler, listAvailableProducts_createServerFn_handler, listLogs_createServerFn_handler, listMyOrders_createServerFn_handler, listProducts_createServerFn_handler, listRefunds_createServerFn_handler, listRemarks_createServerFn_handler, listStaffOrders_createServerFn_handler, listStaff_createServerFn_handler, lockOrder_createServerFn_handler, placeOrder_createServerFn_handler, reportRange_createServerFn_handler, requestCancel_createServerFn_handler, reviewRefund_createServerFn_handler, saveProduct_createServerFn_handler, searchInvoices_createServerFn_handler, setStaffActive_createServerFn_handler, setStaffRole_createServerFn_handler, updateOrderStatus_createServerFn_handler };
