import { Badge } from "@/components/ui/badge";
import { statusLabel } from "@/lib/cupify/format";
import type { OrderStatus } from "@/lib/cupify/types";

const tone: Record<OrderStatus, "default" | "secondary" | "accent" | "destructive" | "outline"> = {
  received: "secondary",
  designing: "outline",
  printing: "default",
  ready: "accent",
  delivered: "default",
  cancelled: "destructive",
  cancel_requested: "destructive",
};

export function StatusBadge({ status }: { status: OrderStatus }) {
  return <Badge variant={tone[status]}>{statusLabel(status)}</Badge>;
}
