import { a as getServerFnById, i as TSS_SERVER_FUNCTION, r as createServerFn } from "./ssr.mjs";
import { t as authMiddleware } from "./middleware-D--PixfV.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/api-DUpluZ3_.js
var createSsrRpc = (functionId) => {
	const url = "/_serverFn/" + functionId;
	const serverFnMeta = { id: functionId };
	const fn = async (...args) => {
		return (await getServerFnById(functionId, { origin: "server" }))(...args);
	};
	return Object.assign(fn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
var getMyProfile = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(createSsrRpc("471967d11a0c615c01c6f7adbc63ca213b4f295190e84cbfbfa43608e172effe"));
var listProducts = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(createSsrRpc("0619e183e13466216945b4140e5cc022d2cece2ef2b1570c9674b23a941d88f2"));
var listAvailableProducts = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(createSsrRpc("7be86018d170a24a411c1683ff46d52fc70158b178367cdcfda96f4e271ba022"));
var placeOrder = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => input).handler(createSsrRpc("dbb5a7b75cbf621da6b5051c6194e68649aa80c849ddd1d683716798c63f4518"));
createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(createSsrRpc("d681ab91e35e54104d93e345cea9ed26a8513c8e29c4f3767d482a2674a85b44"));
var getOrderByNumber = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => input).handler(createSsrRpc("0d11d216dbdabce8cecfdc40a70a30fae0bb5af818633c04a93e3a79043fd669"));
var searchInvoices = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => input).handler(createSsrRpc("29d735d08b3d3eefbc7ccd4baeab7a3156470b160c0e05767ac2b78a33c11df2"));
var listStaffOrders = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(createSsrRpc("86bf7b248981a835e9dbc511484dc4a283f0fcdaf862ae6339839b612590e537"));
var updateOrderStatus = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => input).handler(createSsrRpc("0811ad16fd6bb7c496b006a5ceff2ad844607f8d495caa8df6a35afb9d99bb72"));
var bulkUpdateStatus = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => input).handler(createSsrRpc("6e60ac7f7fe9b394d8a47ed509175462ad36fc76b2e2b3cd86d96bf66cab0b51"));
var assignStaff = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => input).handler(createSsrRpc("3807ab8427896db9d5d530a85d6f5deca6d0b12429a874d637b991075c225c31"));
var lockOrder = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => input).handler(createSsrRpc("0f588b8b99a2e6c38022c6c6dae4db56a1b3ef22b529b8f71395971b7d1c9645"));
var addRemark = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => input).handler(createSsrRpc("0b129b796604615617434ed1ffe08ad4289e613727a21a71d91096bfebe7eb71"));
var listRemarks = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input = {}) => input).handler(createSsrRpc("7dd7cb273123f760385440569dcb6f2bac92d5bf46d16353e68b77085e86ac11"));
var listLogs = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(createSsrRpc("38f39f5c92becb095ced1f693739ea35ca8936b69dc7edc75f9c448783ac520a"));
var cancelItems = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => input).handler(createSsrRpc("abf50ce7e4b5f85ccade2964852ea530c7082b4859bb95030aa1e57c4c543bae"));
var requestCancel = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => input).handler(createSsrRpc("4dc3a3351eae685f0ac16062083cd51d8479d77c595ab769b4d947aaf1ef8bf5"));
var listRefunds = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(createSsrRpc("9a2f5bf15db0fc62067b45414f1f7ccc19db6c7558281a2cac7f6183e0fafe33"));
var reviewRefund = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => input).handler(createSsrRpc("fc6c6b48f0cc995673e4ee156bc10646241ebe6d845c2fae40d61b18b0d05166"));
var saveProduct = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => input).handler(createSsrRpc("0fa24aa86c329c53e05c078cfd0d98435fad4c148865143d4f592ba3eab88de8"));
var deleteProduct = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => input).handler(createSsrRpc("70ae99c4c540cc22c38e2469e6ead170a53c43b166e1d2f70485c8ed848e26b2"));
var listStaff = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(createSsrRpc("ed47ce0f21bb82d1eff156e96b638fb3a0ef4c217df205c8f56b08d86da37f97"));
var inviteStaff = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => input).handler(createSsrRpc("7b9c00ef903ccfeeddfb97c33e5fa46ae0e5c374f0f9d0dc04b13beb5f27a5fa"));
var setStaffActive = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => input).handler(createSsrRpc("33f0bd92d7264ea90db4acae87fe64eddee0c789ae1f6852a97fe2d8a026b847"));
var setStaffRole = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => input).handler(createSsrRpc("faf0cc43d429a0cbbe840190a34d3c67aab31cd0a6dc73bf3f230b3dff7e5293"));
var dashboardStats = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(createSsrRpc("a91bc2d1fae35bcca2421de50d25474f1f2130891693f691a00169c5ae47883f"));
var reportRange = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => input).handler(createSsrRpc("03970b6038322cbfe86c8a64ec7427a912ed06440add1b49e4b4cfc0a0835306"));
//#endregion
export { searchInvoices as C, updateOrderStatus as E, saveProduct as S, setStaffRole as T, lockOrder as _, dashboardStats as a, requestCancel as b, getOrderByNumber as c, listLogs as d, listProducts as f, listStaffOrders as g, listStaff as h, cancelItems as i, inviteStaff as l, listRemarks as m, assignStaff as n, deleteProduct as o, listRefunds as p, bulkUpdateStatus as r, getMyProfile as s, addRemark as t, listAvailableProducts as u, placeOrder as v, setStaffActive as w, reviewRefund as x, reportRange as y };
