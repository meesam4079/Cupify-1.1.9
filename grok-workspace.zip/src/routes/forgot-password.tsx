import { createFileRoute, Link } from "@tanstack/react-router";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { CupifyWordmark } from "@/components/brand/logo";

export const Route = createFileRoute("/forgot-password")({ component: ForgotPage });

function ForgotPage() {
  return (
    <main className="grid min-h-screen place-items-center bg-background px-4 paper-grain">
      <Card className="w-full max-w-md animate-rise">
        <CardHeader className="items-center text-center">
          <CupifyWordmark />
          <CardTitle className="pt-2">Reset password</CardTitle>
          <CardDescription>
            Password reset email isn’t enabled on this cafe yet. Sign in with Google or X, or create a new email account.
          </CardDescription>
        </CardHeader>
        <CardContent>
          <Button asChild className="w-full">
            <Link to="/login">Back to sign in</Link>
          </Button>
        </CardContent>
      </Card>
    </main>
  );
}
