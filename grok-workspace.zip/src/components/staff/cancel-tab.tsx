import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useState } from "react";
import { toast } from "sonner";
import { cancelItems, listStaffOrders, requestCancel } from "@/lib/cupify/api";
import { money } from "@/lib/cupify/format";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import type { Order } from "@/lib/cupify/types";

export function CancelRefundTab() {
  const qc = useQueryClient();
  const orders = useQuery({ queryKey: ["staff-orders"], queryFn: () => listStaffOrders() });
  const received = (orders.data ?? []).filter((o) => o.status === "received");
  const inprod = (orders.data ?? []).filter((o) => ["designing", "printing", "ready"].includes(o.status));

  return (
    <Tabs defaultValue="direct">
      <TabsList>
        <TabsTrigger value="direct">Direct cancel</TabsTrigger>
        <TabsTrigger value="request">Request cancellation</TabsTrigger>
      </TabsList>
      <TabsContent value="direct">
        <CancelList
          orders={received}
          onSubmit={(o, qty, reason, full) =>
            cancelItems({ data: { orderId: o.id, quantities: qty, reason, full } }).then(() => {
              toast.success("Updated");
              void qc.invalidateQueries({ queryKey: ["staff-orders"] });
            })
          }
        />
      </TabsContent>
      <TabsContent value="request">
        <CancelList
          orders={inprod}
          requestOnly
          onSubmit={(o, _qty, reason) =>
            requestCancel({ data: { orderId: o.id, reason } }).then(() => {
              toast.success("Request sent");
              void qc.invalidateQueries({ queryKey: ["staff-orders"] });
            })
          }
        />
      </TabsContent>
    </Tabs>
  );
}

function CancelList({
  orders,
  onSubmit,
  requestOnly,
}: {
  orders: Order[];
  requestOnly?: boolean;
  onSubmit: (o: Order, qty: Record<number, number>, reason: string, full: boolean) => Promise<unknown>;
}) {
  const [open, setOpen] = useState<number | null>(null);
  return (
    <div className="space-y-3">
      {orders.length === 0 && <p className="text-sm text-muted-foreground">No matching orders.</p>}
      {orders.map((o) => (
        <div key={o.id} className="rounded-xl border border-border bg-card p-4">
          <button type="button" className="flex w-full items-center justify-between text-left" onClick={() => setOpen(open === o.id ? null : o.id)}>
            <span className="font-medium">
              {o.orderNumber} · {o.customerName}
            </span>
            <span className="text-sm tabular-nums">{money(o.total)}</span>
          </button>
          {open === o.id && <CancelForm order={o} requestOnly={requestOnly} onSubmit={onSubmit} />}
        </div>
      ))}
    </div>
  );
}

function CancelForm({
  order,
  requestOnly,
  onSubmit,
}: {
  order: Order;
  requestOnly?: boolean;
  onSubmit: (o: Order, qty: Record<number, number>, reason: string, full: boolean) => Promise<unknown>;
}) {
  const [qty, setQty] = useState<Record<number, number>>({});
  const [reason, setReason] = useState("");
  const mut = useMutation({
    mutationFn: (full: boolean) => onSubmit(order, qty, reason, full),
    onError(e) {
      toast.error(e instanceof Error ? e.message : "Failed");
    },
  });
  return (
    <div className="mt-3 space-y-3">
      {!requestOnly &&
        order.items.map((it, i) => (
          <div key={i} className="flex items-center justify-between text-sm">
            <span>
              {it.productName} ({it.quantity})
            </span>
            <input
              type="number"
              min={0}
              max={it.quantity}
              className="h-9 w-20 rounded-md border border-input bg-card px-2 text-sm"
              value={qty[i] ?? 0}
              onChange={(e) => setQty({ ...qty, [i]: Number(e.target.value) })}
            />
          </div>
        ))}
      <Textarea placeholder="Reason (required)" value={reason} onChange={(e) => setReason(e.target.value)} />
      <div className="flex gap-2">
        {!requestOnly && (
          <>
            <Button variant="outline" disabled={!reason.trim() || mut.isPending} onClick={() => mut.mutate(false)}>
              Partial cancel
            </Button>
            <Button variant="destructive" disabled={!reason.trim() || mut.isPending} onClick={() => mut.mutate(true)}>
              Full cancel
            </Button>
          </>
        )}
        {requestOnly && (
          <Button disabled={!reason.trim() || mut.isPending} onClick={() => mut.mutate(false)}>
            Request cancellation
          </Button>
        )}
      </div>
    </div>
  );
}
