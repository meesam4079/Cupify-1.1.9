import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useMemo, useState } from "react";
import { toast } from "sonner";
import { addRemark, listRemarks, listStaffOrders } from "@/lib/cupify/api";
import { when } from "@/lib/cupify/format";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";

export function RemarksTab() {
  const qc = useQueryClient();
  const orders = useQuery({ queryKey: ["staff-orders"], queryFn: () => listStaffOrders() });
  const remarks = useQuery({ queryKey: ["remarks-all"], queryFn: () => listRemarks({ data: {} }) });
  const [q, setQ] = useState("");
  const [picked, setPicked] = useState<number | null>(null);
  const [content, setContent] = useState("");

  const matches = useMemo(() => {
    const s = q.trim().toLowerCase();
    if (!s) return [];
    return (orders.data ?? []).filter((o) => o.orderNumber.toLowerCase().includes(s) || o.customerName.toLowerCase().includes(s)).slice(0, 8);
  }, [orders.data, q]);

  const mut = useMutation({
    mutationFn: () => addRemark({ data: { orderId: picked!, content } }),
    onSuccess() {
      setContent("");
      toast.success("Saved");
      void qc.invalidateQueries({ queryKey: ["remarks-all"] });
    },
  });

  return (
    <div className="grid gap-6 lg:grid-cols-2">
      <div className="space-y-3">
        <Input placeholder="Search order number or name" value={q} onChange={(e) => setQ(e.target.value)} />
        {matches.map((o) => (
          <button
            key={o.id}
            type="button"
            onClick={() => {
              setPicked(o.id);
              setQ(o.orderNumber);
            }}
            className="block w-full rounded-md border border-border px-3 py-2 text-left text-sm hover:bg-secondary"
          >
            {o.orderNumber} · {o.customerName}
          </button>
        ))}
        <Textarea value={content} onChange={(e) => setContent(e.target.value)} placeholder="Remark" />
        <Button disabled={!picked || !content.trim() || mut.isPending} onClick={() => mut.mutate()}>
          Add remark
        </Button>
      </div>
      <div className="max-h-[70vh] space-y-2 overflow-y-auto">
        {(remarks.data ?? []).map((r) => (
          <div key={r.id} className="rounded-lg border border-border bg-card p-3 text-sm">
            <p className="font-medium">
              {r.orderNumber} · {r.customerName}
            </p>
            <p className="mt-1">{r.content}</p>
            <p className="mt-1 text-xs text-muted-foreground">
              {r.staffName} · {when(r.createdAt)}
            </p>
          </div>
        ))}
      </div>
    </div>
  );
}
