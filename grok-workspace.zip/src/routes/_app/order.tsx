import { createFileRoute } from "@tanstack/react-router";
import { useMutation, useQuery } from "@tanstack/react-query";
import { useState } from "react";
import { toast } from "sonner";
import { listAvailableProducts, placeOrder } from "@/lib/cupify/api";
import { useCart } from "@/lib/cupify/cart-context";
import { money } from "@/lib/cupify/format";
import { useCurrentUser } from "@/lib/auth/use-current-user";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Checkbox } from "@/components/ui/checkbox";
import { CartItemRow } from "@/components/order/cart-item";
import { CustomCupForm } from "@/components/order/custom-cup-form";
import { InvoiceModal } from "@/components/invoice/invoice-modal";
import type { Order, PaymentMethod, Product } from "@/lib/cupify/types";

export const Route = createFileRoute("/_app/order")({ component: OrderPage });

function OrderPage() {
  const products = useQuery({ queryKey: ["products-available"], queryFn: () => listAvailableProducts() });
  const cart = useCart();
  const user = useCurrentUser();
  const [step, setStep] = useState<"cart" | "details" | "done">("cart");
  const [customFor, setCustomFor] = useState<Product | null>(null);
  const [name, setName] = useState(user?.displayName ?? "");
  const [email, setEmail] = useState(user?.primaryEmail ?? "");
  const [phone, setPhone] = useState("");
  const [pay, setPay] = useState<PaymentMethod>("cash");
  const [own, setOwn] = useState(false);
  const [mkt, setMkt] = useState(false);
  const [placed, setPlaced] = useState<Order | null>(null);
  const [invoice, setInvoice] = useState(false);

  const place = useMutation({
    mutationFn: () =>
      placeOrder({
        data: {
          customerName: name,
          customerEmail: email,
          customerPhone: phone,
          items: cart.items,
          paymentMethod: pay,
          consentOwnImage: own,
          consentMarketing: mkt,
        },
      }),
    onSuccess(order) {
      setPlaced(order);
      cart.clear();
      setStep("done");
      setInvoice(true);
      toast.success("Order placed");
    },
    onError(err) {
      toast.error(err instanceof Error ? err.message : "Could not place order");
    },
  });

  const hasCustom = cart.items.some((i) => i.cupType === "custom");

  return (
    <main className="mx-auto max-w-6xl px-4 py-10">
      <h1 className="font-display text-3xl font-semibold">Order</h1>
      <p className="mt-1 text-sm text-muted-foreground">Cart → details → invoice. 30% advance, balance at pickup.</p>

      {step === "cart" && (
        <div className="mt-6 grid gap-6 lg:grid-cols-[1fr_360px]">
          <div className="space-y-4">
            {customFor && (
              <CustomCupForm
                product={customFor}
                onClose={() => setCustomFor(null)}
                onAdd={(extra) => {
                  cart.addCustom(customFor, extra);
                  toast.success(`${customFor.name} added to cart`);
                  setCustomFor(null);
                }}
              />
            )}
            <div className="grid gap-3 sm:grid-cols-2">
              {(products.data ?? []).map((p) => (
                <Card key={p.id}>
                  <CardHeader className="p-4 pb-2">
                    <CardTitle className="text-base">{p.name}</CardTitle>
                    <p className="text-sm text-muted-foreground">{money(p.price)}</p>
                  </CardHeader>
                  <CardContent className="flex gap-2 p-4 pt-0">
                    <Button
                      size="sm"
                      className="flex-1"
                      onClick={() => {
                        cart.addStandard(p);
                        toast.success(`${p.name} added to cart`);
                      }}
                    >
                      Standard
                    </Button>
                    <Button size="sm" variant="outline" className="flex-1" onClick={() => setCustomFor(p)}>
                      Custom
                    </Button>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
          <Card className="h-fit">
            <CardHeader>
              <CardTitle>Cart</CardTitle>
            </CardHeader>
            <CardContent>
              {cart.items.length === 0 ? (
                <p className="text-sm text-muted-foreground">Empty — add a drink to begin.</p>
              ) : (
                <>
                  {cart.items.map((i) => (
                    <CartItemRow key={i.cartId} item={i} onQty={(n) => cart.updateQuantity(i.cartId, n)} onRemove={() => cart.remove(i.cartId)} />
                  ))}
                  <div className="mt-4 space-y-1 text-sm">
                    <div className="flex justify-between">
                      <span>Subtotal</span>
                      <span className="tabular-nums">{money(cart.totals.subtotal)}</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Custom charges</span>
                      <span className="tabular-nums">{money(cart.totals.customCharges)}</span>
                    </div>
                    <div className="flex justify-between font-medium">
                      <span>Total</span>
                      <span className="tabular-nums">{money(cart.totals.total)}</span>
                    </div>
                    <div className="flex justify-between text-muted-foreground">
                      <span>Advance (30%)</span>
                      <span className="tabular-nums">{money(cart.totals.advancePaid)}</span>
                    </div>
                  </div>
                  <Button className="mt-4 w-full" onClick={() => setStep("details")}>
                    Continue to details
                  </Button>
                </>
              )}
            </CardContent>
          </Card>
        </div>
      )}

      {step === "details" && (
        <Card className="mx-auto mt-6 max-w-lg">
          <CardHeader>
            <CardTitle>Your details</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-1.5">
              <Label htmlFor="n">Name</Label>
              <Input id="n" value={name} onChange={(e) => setName(e.target.value)} required />
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="e">Email</Label>
              <Input id="e" type="email" value={email} onChange={(e) => setEmail(e.target.value)} />
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="p">Phone</Label>
              <Input id="p" value={phone} onChange={(e) => setPhone(e.target.value)} />
            </div>
            <div className="space-y-2">
              <Label>Payment</Label>
              <RadioGroup value={pay} onValueChange={(v) => setPay(v as PaymentMethod)}>
                {(["cash", "card", "online"] as const).map((m) => (
                  <label key={m} className="flex items-center gap-2 text-sm capitalize">
                    <RadioGroupItem value={m} /> {m === "online" ? "Online transfer" : m}
                  </label>
                ))}
              </RadioGroup>
            </div>
            {hasCustom && (
              <div className="space-y-2">
                <label className="flex items-start gap-2 text-sm">
                  <Checkbox checked={own} onCheckedChange={(v) => setOwn(v === true)} />I own the image rights
                </label>
                <label className="flex items-start gap-2 text-sm">
                  <Checkbox checked={mkt} onCheckedChange={(v) => setMkt(v === true)} />
                  Allow marketing usage
                </label>
              </div>
            )}
            <div className="rounded-lg bg-secondary p-3 text-sm">
              <div className="flex justify-between">
                <span>Total</span>
                <span className="tabular-nums">{money(cart.totals.total)}</span>
              </div>
              <div className="flex justify-between text-muted-foreground">
                <span>Advance now</span>
                <span className="tabular-nums">{money(cart.totals.advancePaid)}</span>
              </div>
              <div className="flex justify-between text-muted-foreground">
                <span>Balance at pickup</span>
                <span className="tabular-nums">{money(cart.totals.balanceDue)}</span>
              </div>
            </div>
            <div className="flex gap-2">
              <Button variant="outline" className="flex-1" onClick={() => setStep("cart")}>
                Back
              </Button>
              <Button className="flex-1" disabled={place.isPending || !name.trim() || (hasCustom && !own)} onClick={() => place.mutate()}>
                {place.isPending ? "Placing…" : "Place order"}
              </Button>
            </div>
          </CardContent>
        </Card>
      )}

      {step === "done" && placed && (
        <div className="mx-auto mt-10 max-w-md space-y-4 text-center">
          <h2 className="font-display text-3xl font-semibold">Order placed</h2>
          <p className="text-muted-foreground">
            {placed.orderNumber} is on the board. We’ll have it when the timeline says ready.
          </p>
          <div className="flex justify-center gap-2">
            <Button onClick={() => setInvoice(true)}>View invoice</Button>
            <Button
              variant="outline"
              onClick={() => {
                setPlaced(null);
                setStep("cart");
              }}
            >
              New order
            </Button>
          </div>
        </div>
      )}

      <InvoiceModal order={placed} open={invoice} onOpenChange={setInvoice} />
    </main>
  );
}
