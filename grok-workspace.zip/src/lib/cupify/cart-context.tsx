import { createContext, useContext, useMemo, useState, type ReactNode } from "react";
import type { CartLine, OrderItem, Product } from "./types";
import { cartTotals } from "./format";

type CartCtx = {
  items: CartLine[];
  addStandard: (product: Product) => void;
  addCustom: (product: Product, extra: Pick<OrderItem, "customCupName" | "customCupMessage" | "customCupImageUrl">) => void;
  updateQuantity: (cartId: string, qty: number) => void;
  remove: (cartId: string) => void;
  clear: () => void;
  count: number;
  totals: ReturnType<typeof cartTotals>;
};

const Ctx = createContext<CartCtx | null>(null);

function toLine(product: Product, cupType: OrderItem["cupType"], extra?: Partial<OrderItem>): CartLine {
  return {
    cartId: `${Date.now()}-${Math.random().toString(36).slice(2, 8)}`,
    productId: String(product.id),
    productName: product.name,
    quantity: 1,
    price: product.price,
    cupType,
    category: product.category,
    customCupCharge: cupType === "custom" ? product.customCupCharge : 0,
    ...extra,
  };
}

export function CartProvider({ children }: { children: ReactNode }) {
  const [items, setItems] = useState<CartLine[]>([]);

  const value = useMemo<CartCtx>(() => {
    const totals = cartTotals(items);
    return {
      items,
      addStandard(product) {
        setItems((prev) => {
          const existing = prev.find((i) => i.productId === String(product.id) && i.cupType === "standard");
          if (existing) {
            return prev.map((i) => (i.cartId === existing.cartId ? { ...i, quantity: i.quantity + 1 } : i));
          }
          return [...prev, toLine(product, "standard")];
        });
      },
      addCustom(product, extra) {
        setItems((prev) => [...prev, toLine(product, "custom", extra)]);
      },
      updateQuantity(cartId, qty) {
        setItems((prev) =>
          qty <= 0 ? prev.filter((i) => i.cartId !== cartId) : prev.map((i) => (i.cartId === cartId ? { ...i, quantity: qty } : i)),
        );
      },
      remove(cartId) {
        setItems((prev) => prev.filter((i) => i.cartId !== cartId));
      },
      clear() {
        setItems([]);
      },
      count: items.reduce((n, i) => n + i.quantity, 0),
      totals,
    };
  }, [items]);

  return <Ctx.Provider value={value}>{children}</Ctx.Provider>;
}

export function useCart() {
  const ctx = useContext(Ctx);
  if (!ctx) throw new Error("useCart must be used inside CartProvider");
  return ctx;
}
