import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useState } from "react";
import { toast } from "sonner";
import { getMyProfile, inviteStaff, listStaff, setStaffActive, setStaffRole } from "@/lib/cupify/api";
import { when } from "@/lib/cupify/format";
import type { UserRole } from "@/lib/cupify/types";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

export function AdminStaffTab() {
  const qc = useQueryClient();
  const me = useQuery({ queryKey: ["me"], queryFn: () => getMyProfile() });
  const staff = useQuery({ queryKey: ["staff"], queryFn: () => listStaff() });
  const [email, setEmail] = useState("");
  const [role, setRole] = useState<"staff" | "admin">("staff");

  const invite = useMutation({
    mutationFn: () => inviteStaff({ data: { email, role } }),
    onSuccess() {
      setEmail("");
      toast.success("Invite recorded — they get staff access on first sign-in");
      void qc.invalidateQueries({ queryKey: ["staff"] });
    },
    onError(e) {
      toast.error(e instanceof Error ? e.message : "Failed");
    },
  });

  return (
    <div className="space-y-6">
      <form
        className="flex flex-wrap items-end gap-2"
        onSubmit={(e) => {
          e.preventDefault();
          invite.mutate();
        }}
      >
        <div className="space-y-1.5">
          <Label>Email</Label>
          <Input type="email" value={email} onChange={(e) => setEmail(e.target.value)} required />
        </div>
        <Select value={role} onValueChange={(v) => setRole(v as "staff" | "admin")}>
          <SelectTrigger className="w-32">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="staff">Staff</SelectItem>
            <SelectItem value="admin">Admin</SelectItem>
          </SelectContent>
        </Select>
        <Button type="submit" disabled={invite.isPending}>
          Invite
        </Button>
      </form>
      <div className="overflow-x-auto">
        <table className="w-full text-left text-sm">
          <thead>
            <tr className="border-b text-muted-foreground">
              <th className="py-2">Name</th>
              <th>Email</th>
              <th>Role</th>
              <th>Active</th>
              <th>Joined</th>
            </tr>
          </thead>
          <tbody>
            {(staff.data ?? []).map((s) => {
              const mine = s.userId === me.data?.userId;
              return (
                <tr key={s.userId} className="border-b border-border/60">
                  <td className="py-2">{s.displayName || "—"}</td>
                  <td>{s.email}</td>
                  <td>
                    <Select
                      value={s.role}
                      disabled={mine}
                      onValueChange={(v) =>
                        setStaffRole({ data: { userId: s.userId, role: v as UserRole } }).then(() => qc.invalidateQueries({ queryKey: ["staff"] }))
                      }
                    >
                      <SelectTrigger className="h-8 w-28">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="staff">Staff</SelectItem>
                        <SelectItem value="admin">Admin</SelectItem>
                      </SelectContent>
                    </Select>
                  </td>
                  <td>
                    <Switch
                      checked={s.isActive}
                      disabled={mine}
                      onCheckedChange={(v) =>
                        setStaffActive({ data: { userId: s.userId, isActive: v } }).then(() => qc.invalidateQueries({ queryKey: ["staff"] }))
                      }
                    />
                  </td>
                  <td className="text-xs text-muted-foreground">{when(s.createdAt)}</td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </div>
  );
}
