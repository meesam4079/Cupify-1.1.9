import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { CupifyWordmark } from "@/components/brand/logo";
import { money, when, lineTotal } from "@/lib/cupify/format";
import type { Order } from "@/lib/cupify/types";

export function InvoiceModal({ order, open, onOpenChange }: { order: Order | null; open: boolean; onOpenChange: (v: boolean) => void }) {
  if (!order) return null;
  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-h-[90vh] max-w-lg overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Invoice</DialogTitle>
        </DialogHeader>
        <div className="invoice-sheet space-y-4">
          <div className="flex items-start justify-between">
            <CupifyWordmark />
            <div className="text-right text-sm">
              <p className="font-medium">{order.orderNumber}</p>
              <p className="text-muted-foreground">{when(order.createdAt)}</p>
            </div>
          </div>
          <div className="text-sm">
            <p className="font-medium">{order.customerName}</p>
            <p className="text-muted-foreground">{order.customerEmail}</p>
            <p className="text-muted-foreground">{order.customerPhone}</p>
          </div>
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b text-left text-muted-foreground">
                <th className="py-2 font-medium">Item</th>
                <th className="py-2 font-medium">Qty</th>
                <th className="py-2 text-right font-medium">Amount</th>
              </tr>
            </thead>
            <tbody>
              {order.items.map((it, i) => (
                <tr key={i} className="border-b border-border/50">
                  <td className="py-2">
                    {it.productName}
                    {it.cupType === "custom" ? ` · ${it.customCupName ?? "custom"}` : ""}
                  </td>
                  <td className="py-2 tabular-nums">{it.quantity}</td>
                  <td className="py-2 text-right tabular-nums">{money(lineTotal(it))}</td>
                </tr>
              ))}
            </tbody>
          </table>
          <div className="space-y-1 text-sm">
            <Row label="Subtotal" value={money(order.subtotal)} />
            <Row label="Custom charges" value={money(order.customCharges)} />
            <Row label="Total" value={money(order.total)} bold />
            <Row label="Advance paid" value={money(order.advancePaid)} />
            <Row label="Balance due" value={money(order.balanceDue)} />
          </div>
          <p className="text-center text-xs text-muted-foreground">Thank you for choosing Cupify Cafe.</p>
          <Button className="no-print w-full" onClick={() => window.print()}>
            Print / save PDF
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}

function Row({ label, value, bold }: { label: string; value: string; bold?: boolean }) {
  return (
    <div className={`flex justify-between ${bold ? "font-medium" : ""}`}>
      <span>{label}</span>
      <span className="tabular-nums">{value}</span>
    </div>
  );
}
