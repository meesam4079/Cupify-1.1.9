import * as React from "react";
import * as SelectRoot from "@radix-ui/react-select";
import { Check, ChevronDown } from "lucide-react";
import { cn } from "@/lib/utils";

const Select = SelectRoot.Root;
const SelectGroup = SelectRoot.Group;
const SelectValue = SelectRoot.Value;

const SelectTrigger = React.forwardRef<
  React.ElementRef<typeof SelectRoot.Trigger>,
  React.ComponentPropsWithoutRef<typeof SelectRoot.Trigger>
>(({ className, children, ...props }, ref) => (
  <SelectRoot.Trigger
    ref={ref}
    className={cn(
      "flex h-10 w-full items-center justify-between rounded-md border border-input bg-card px-3 py-2 text-sm shadow-sm focus:outline-none focus:ring-2 focus:ring-ring/50 disabled:cursor-not-allowed disabled:opacity-50",
      className,
    )}
    {...props}
  >
    {children}
    <SelectRoot.Icon asChild>
      <ChevronDown className="h-4 w-4 opacity-60" />
    </SelectRoot.Icon>
  </SelectRoot.Trigger>
));
SelectTrigger.displayName = SelectRoot.Trigger.displayName;

const SelectContent = React.forwardRef<
  React.ElementRef<typeof SelectRoot.Content>,
  React.ComponentPropsWithoutRef<typeof SelectRoot.Content>
>(({ className, children, position = "popper", ...props }, ref) => (
  <SelectRoot.Portal>
    <SelectRoot.Content
      ref={ref}
      position={position}
      className={cn(
        "relative z-50 min-w-[8rem] overflow-hidden rounded-md border border-border bg-popover text-popover-foreground shadow-md",
        className,
      )}
      {...props}
    >
      <SelectRoot.Viewport className="p-1">{children}</SelectRoot.Viewport>
    </SelectRoot.Content>
  </SelectRoot.Portal>
));
SelectContent.displayName = SelectRoot.Content.displayName;

const SelectItem = React.forwardRef<
  React.ElementRef<typeof SelectRoot.Item>,
  React.ComponentPropsWithoutRef<typeof SelectRoot.Item>
>(({ className, children, ...props }, ref) => (
  <SelectRoot.Item
    ref={ref}
    className={cn(
      "relative flex w-full cursor-pointer select-none items-center rounded-sm py-1.5 pl-8 pr-2 text-sm outline-none focus:bg-secondary data-[disabled]:pointer-events-none data-[disabled]:opacity-50",
      className,
    )}
    {...props}
  >
    <span className="absolute left-2 flex h-3.5 w-3.5 items-center justify-center">
      <SelectRoot.ItemIndicator>
        <Check className="h-4 w-4" />
      </SelectRoot.ItemIndicator>
    </span>
    <SelectRoot.ItemText>{children}</SelectRoot.ItemText>
  </SelectRoot.Item>
));
SelectItem.displayName = SelectRoot.Item.displayName;

export { Select, SelectGroup, SelectValue, SelectTrigger, SelectContent, SelectItem };
